# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import inspect
import time
import yaml
import azure
from azure.cosmos import CosmosClient, PartitionKey, exceptions
from hdm.core.dao.db_dao import DBDAO
from hdm.core.utils.project_config import ProjectConfig


class CosmosDB(DBDAO):

    def _get_connection(self):

        connection = None
        connection_invalid = True
        connection_attempt_count = 0

        timeout = self._timeout
        timeout_factor = self._timeout_factor
        max_attempts = self._max_attempts

        with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
            conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()][self._connection_name]

        # print(conn_conf)
        connection_config = self._get_connection_config(config=conn_conf)

        while connection_attempt_count < max_attempts:
            connection = self._connect_by_client(connection_config)

            # If your connection is valid, then set it so and break from while loop
            if self._test_connection(connection):
                connection_invalid = False
                break

            # Otherwise, you must put program to sleep, wait for next time to obtain connection and carry on.
            connection_attempt_count += 1
            if connection_invalid < max_attempts:
                time.sleep(timeout)
                connection = self._connect_by_client(connection_config)
                timeout *= timeout_factor

        if connection_invalid:
            raise ConnectionError('Unable to connection to Azure Cosmosdb. Please try again.')

        return connection

    def _get_connection_config(self, config: dict) -> dict:
        return dict(account_endpoint=config['account_endpoint'],
                    account_key=config['account_key'],
                    database=config['database'])

    def _connect_by_client(self, config: dict):
        return CosmosClient(url=config['account_endpoint'], credential=config['account_key']).get_database_client(config['database'])

    def _test_connection(self, connection) -> bool:
        """
        Validate that the connection is valid to azure cosmosdb database
        Returns: True if connection is valid and container exists, False otherwise
        """
        result = False
        if connection:
            try:
                # Try to connect to azure cosmosdb database
                # print(inspect.getmembers(connection))
                result = bool(connection.read())
            except Exception:
                return False

        if not self._test_container_existence(connection):
            result = False

        return result

    def _test_container_existence(self, connection) -> bool:
        """
        check if cosmosdb container exists

        Returns: True if container is exists, False otherwise

        """

        if not connection:
            return False

        # Note: exceptions.CosmosResourceNotFoundError not able to catch, so creating creating container first
        # TODO: need to revisit
        '''
        try:
            result = bool(connection.get_container_client(ProjectConfig.state_manager_table_name()))
        except exceptions.CosmosResourceNotFoundError:
            self._create_container(connection)
            result = True
        except exceptions.CosmosHttpResponseError:
            raise
        return result
        '''

        try:
            self._create_container(connection)
            result = True
        except exceptions.CosmosResourceExistsError:
            result = bool(connection.get_container_client(ProjectConfig.state_manager_table_name()))
        except exceptions.CosmosHttpResponseError:
            raise
        return result

    def _create_container(self, connection):
        """
        creates a cosmos db container

        Returns:

        """
        connection.create_container(id=ProjectConfig.state_manager_table_name(),
                                    partition_key=PartitionKey(path=ProjectConfig.state_manager_partition_key_cosmosdb()))

    def _create_engine(self):
        pass

    def _validate_configuration(self) -> bool:
        with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
            conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()][self._connection_name]

        required_keys = ['account_endpoint', 'account_key', 'database']
        is_valid = all([key in conn_conf.keys() for key in required_keys])
        return is_valid
