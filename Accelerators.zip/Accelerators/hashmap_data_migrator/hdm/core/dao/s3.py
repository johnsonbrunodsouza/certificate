# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# import inspect
import boto3
import yaml

from hdm.core.dao.object_store_dao import ObjectStoreDAO
from hdm.core.utils.project_config import ProjectConfig


class S3(ObjectStoreDAO):
    """
    S3 Resource
    Expected environment variables:
    HOME: User home having the file specified in PROFILE_FILE
    HDM_ENV: environment for dev/stage/testing.Should match the one in PROFILE_FILE
    PROFILE_FILE: YAML file having configurations based on environments
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._bucket = None

    def _get_connection(self):
        """
        Gets a S3 Session based on env variables.
        Connection is made using credentials specified in .aws/ or as per the profile values specified in:
            aws_access_key_id
            aws_secret_access_key
            region_name
        """
        with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
            conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()][self._connection_name]

        self._bucket = conn_conf['bucket_name']

        connection = boto3.session.Session(aws_access_key_id=conn_conf['aws_access_key_id'],
                                           aws_secret_access_key=conn_conf['aws_secret_access_key'],
                                           region_name=conn_conf['region_name'])

        if not self._test_connection(connection):
            raise ConnectionError('Unable to connect to AWS S3 storage. Please check configuration key values in profile.yml or try again.')
        return connection

    def _test_connection(self, connection) -> bool:
        """
        Validate that the connection is valid to s3 storage account
        Returns: True if connection is valid and bucket exists, False otherwise
        """
        result = False
        if connection:
            try:
                # Try to connect to gcp storage account
                # print(inspect.getmembers(connection))
                result = bool(connection.region_name)
            except Exception:
                return False

        if not self._test_bucket_existence(connection):
            result = False

        return result

    def _test_bucket_existence(self, connection) -> bool:
        """
        check if blob container exists

        Returns: True if bucket exists, False otherwise

        """
        if not connection:
            return False

        try:
            # Throws exception if container not available
            return bool(connection.resource('s3').Bucket(self._bucket))

        except boto3.core.exceptions.ResourceNotFoundError:
            self._create_bucket(connection)
            return True

    def _create_bucket(self, connection):
        """
        creates a bucket

        Returns:

        """
        connection.resource('s3').create_bucket(self._bucket)

    def _validate_configuration(self) -> bool:
        with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
            conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()][self._connection_name]

        required_keys = ['aws_access_key_id', 'aws_secret_access_key', 'region_name', 'url', 'bucket_name']
        is_valid = all([key in conn_conf.keys() for key in required_keys])
        return is_valid
