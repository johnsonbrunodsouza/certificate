class QueryTemplates:

    get_current_state_template = '''
    SELECT * FROM  {{table_name}} as c
    WHERE c.job_id='{{job_id}}'
    {% if entity %}
            and c.source_entity='{{entity}}'
        {% if entity_filter %}
            and c.source_filter='{{entity_filter}}'
        {% endif %}
    {% endif %}
    '''

    get_last_record_template = '''
    SELECT * FROM {{table_name}} as c
    WHERE 
        c.manifest_name='{{manifest_name}}' 
        and c.source_entity='{{entity}}' 
    ORDER BY c.updated_on desc
    '''

    get_processing_history_template = '''
    SELECT distinct c.source_entity
    FROM {{table_name}}  as c
    WHERE c.source_name='{{source_name}}' 
        and c.manifest_name='{{manifest_name}}'
    '''

    netezza_source_template = '''
    {% if checksum_function == 'hash'%}
    SELECT * , {{checksum_function}}('{{checksum_column}}',0) as ck_sum 
    {% elif checksum_function == 'hash8' %}
    SELECT * , {{checksum_function}}('{{checksum_column}}') as ck_sum 
    {% else %}
    SELECT * , CAST(random()* 100000 AS INT) as ck_sum 
    {% endif %}
    FROM {{table_name}}
    {% if watermark_flag %}
        WHERE 
            {{watermark_column}} > {{watermark_offset}}
            {% if last_record_pulled_flag %}
                AND {{watermark_column}}  > {{last_record_pulled}} 
            {% endif %}
        ORDER BY {{watermark_column}}
    {% endif %}
    {% if query_limit %}
        LIMIT {{query_limit}}
    {% endif %}
    '''

    netezza_get_columns_template = '''
    SELECT COLUMN_NAME, DATA_TYPE
    FROM INFORMATION_SCHEMA.COLUMNS  
    WHERE
    TABLE_SCHEMA ||'.'||TABLE_NAME  = '{{table_name}}'
    '''

    netezza_generate_external_table_template = '''
    CREATE EXTERNAL TABLE {{external_table_name}}({{cols}})
    USING ( DATAOBJECT ('{{unload_file}}')  DELIMITER ','
    REMOTESOURCE '{{driver_type}}' INCLUDEHEADER);
    '''

    netezza_external_source_template = '''
    INSERT INTO {{external_table_name}}  
    {% if checksum_function == 'hash'%}
    SELECT * , {{checksum_function}}('{{checksum_column}}',0) as ck_sum 
    {% elif checksum_function == 'hash8' %}
    SELECT * , {{checksum_function}}('{{checksum_column}}') as ck_sum 
    {% else %}
    SELECT * , CAST(random()* 100000 AS INT) as ck_sum 
    {% endif %}
    FROM {{table_name}}
    {% if watermark_flag %}
        WHERE 
            {{watermark_column}} > {{watermark_offset}}
            {% if last_record_pulled_flag %}
                AND {{watermark_column}}  > {{last_record_pulled}} 
            {% endif %}
        ORDER BY {{watermark_column}}
    {% endif %}
    {% if query_limit %}
        LIMIT {{query_limit}}
    {% endif %}
    '''

    # oracle_source_template = '''
    #     {% if checksum_function == 'standard_hash'%}
    #     SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}},'SHA256') as ck_sum 
    #     {% elif checksum_function == 'ora_hash' %}
    #     SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}}) as ck_sum 
    #     {% else %}
    #     SELECT {{table_name}}.* , dbms_random.value(100000000000, 999999999999) as ck_sum 
    #     {% endif %}
    #     FROM {{table_name}}
    #     {% if watermark_flag %}
    #         WHERE 
    #             {{watermark_column}} > {{watermark_offset}}
    #             {% if last_record_pulled_flag %}
    #                 AND {{watermark_column}}  > {{last_record_pulled}}
    #             {% endif %}
    #         ORDER BY {{watermark_column}}
    #     {% endif %}
    #     {% if query_limit %}
    #          FETCH NEXT {{query_limit}} ROWS ONLY
    #     {% endif %}
    #     '''

    oracle_source_template = '''
        {% if checksum_function == 'standard_hash'%}
        SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}},'SHA256') as ck_sum 
        {% elif checksum_function == 'ora_hash' %}
        SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}}) as ck_sum 
        {% else %}
        SELECT {{table_name}}.*  
        {% endif %}
        FROM {{table_name}}
        {% if watermark_flag %}
            WHERE 
                {{watermark_column}} > {{watermark_offset}}
                {% if last_record_pulled_flag %}
                    AND {{watermark_column}}  > {{last_record_pulled}}
                {% endif %}
            ORDER BY {{watermark_column}}
        {% endif %}
        {% if query_limit %}
             FETCH NEXT {{query_limit}} ROWS ONLY
        {% endif %}
        '''

    hive_source_template = '''
    {% if checksum_function == 'md5'%}
    SELECT * , {{checksum_function}}({{checksum_column}}) as ck_sum 
    {% else %}
    SELECT * 
    {% endif %}
    FROM {{table_name}}
    {% if watermark_flag %}
        WHERE 
            {{watermark_column}} > {{watermark_offset}}
            {% if last_record_pulled_flag %}
                AND {{watermark_column}}  > {{last_record_pulled}} 
            {% endif %}
        ORDER BY {{watermark_column}}
    {% endif %}
    {% if query_limit %}
        LIMIT {{query_limit}}
    {% endif %}
    '''

    teradata_source_template = '''
        {% if checksum_function == 'standard_hash'%}
        SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}},'SHA256') as ck_sum 
        {% elif checksum_function == 'crc32' %}
        SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}}) as ck_sum 
        {% else %}
        SELECT {{table_name}}.* 
        {% endif %}
        FROM {{table_name}}
        {% if watermark_flag %}
            WHERE 
                {% if watermark_offset_flag %}
                {{watermark_column}} >= {{watermark_offset}}
                {% endif %}
                {% if last_record_pulled_flag %}
                    {% if watermark_offset_flag %}
                        AND {{watermark_column}}  > '{{last_record_pulled}}'
                    {% else %}
                        {{watermark_column}}  > '{{last_record_pulled}}'
                    {% endif %}
                {% endif %}
            ORDER BY {{watermark_column}}
        {% endif %}
        {% if query_limit %}
             limit {{query_limit}}
        {% endif %}
        '''
    
    teradata_schema_template = '''
        SELECT 
             C.ColumnName,
             case
                WHEN ColumnType = 'I1' THEN 'BYTEINT'
                WHEN ColumnType = 'I2' THEN 'SMALLINT'
                WHEN ColumnType = 'I8' THEN 'BIGINT'
                WHEN ColumnType = 'I' THEN 'INTEGER'
                WHEN ColumnType = 'D' THEN 'DECIMAL' || '(' || TO_CHAR(C.DecimalTotalDigits) || ',' || TO_CHAR(C.DecimalFractionalDigits) || ')'
                WHEN ColumnType = 'F' THEN 'FLOAT'
                WHEN ColumnType = 'N' THEN 'NUMBER'
                WHEN ColumnType = 'CF' THEN 'CHAR' || '(' || TO_CHAR(C.ColumnLength) || ')'
                WHEN ColumnType = 'CV' THEN 'VARCHAR' || '(' || TO_CHAR(C.ColumnLength) || ')'
                WHEN ColumnType = 'DA' THEN 'DATE'
                WHEN ColumnType = 'AT' THEN 'TIME'
                WHEN ColumnType = 'TS' THEN 'TIMESTAMP'
                WHEN ColumnType = 'BO' THEN 'BLOB'
                WHEN ColumnType = 'CO' THEN 'CLOB'
                WHEN ColumnType = 'BF' THEN 'BYTE'
                WHEN ColumnType = 'BV' THEN 'VARBYTE' || '(' || TO_CHAR(C.ColumnLength) || ')'
                WHEN ColumnType in ('A1','AN') THEN 'ARRAY'
                WHEN ColumnType = 'JN' THEN 'JSON'
                WHEN ColumnType = 'XM' THEN 'XML'
            end as ColumnDataType
        FROM  DBC.ColumnsV C
        INNER JOIN DBC.TablesV T
            ON C.TableName = T.TableName
            AND C.DatabaseName = T.DatabaseName
            AND T.TableKind = 'T'
        where T.DatabaseName = '{{database_name}}'
        and T.TableName = '{{table_name}}'
        order by C.ColumnId;
    '''