# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os
import time
from io import StringIO
import boto3
import pandas as pd

from hdm.core.dao.s3 import S3
from hdm.core.sink.sink import Sink
from hdm.core.utils.generic_functions import GenericFunctions
from hdm.core.utils.project_config import ProjectConfig


class S3Sink(Sink):
    """
    S3 Source
    Expected protocol for configuration:
    connection: Connection choice to connect to different profiles.
    bucket_name: Bucket name to scan for loading files into dataframes
    """
    def __init__(self, **kwargs):
        """
        Construct an instance of the S3Source.
        Args:
            **kwargs:
                connection: connection name to connect to a specific profile
                bucket_name: bucket name to used for storing the object passed in the dataframe.
                object_name: name of the created object
        """
        super().__init__(**kwargs)
        self.__bucket_name = kwargs.get('bucket_name')
        self.__env = kwargs['env']
        self.__s3_dao = S3(connection=self.__env, bucket=self.__bucket_name)
        self.__file_format = kwargs.get('file_format', 'csv')

    def produce(self, **kwargs) -> None:
        self._run(**kwargs)

    def _set_data(self, **kwargs) -> dict:
        """
        Creates CSV files for the passed dataframe.
        Args:
            **kwargs:
                data_frame: dataframe required to be written to S3 bucket
        """
        df = kwargs['data_frame']
        table_name: str = kwargs.get("table_name")

        self._entity = kwargs.get('file_name', f"{ProjectConfig.file_prefix()}_{str(time.time_ns())}.csv")
        self._entity_filter = os.path.join(self._sink_name, GenericFunctions.table_to_folder(table_name))

        # Create a connection to S3

        # Make sure that the bucket exists and create it if it does not exist.
        s3: boto3.session.Session = self.__s3_dao.connection.resource('s3')
        self.__putFile(df, s3, os.path.join(self._sink_name, GenericFunctions.table_to_folder(table_name), self._entity))

        return dict(record_count=df.shape[0])

    def __putFile(self, df: pd.DataFrame, s3: boto3.session.Session.resource, to_upload_object) -> dict:
        if self.__file_format.lower() == 'csv':
            with StringIO() as buf:
                # buffer = StringIO()
                df.to_csv(buf, sep=',', index=False)
                self._logger.debug("Buffer len: %d", len(buf.getvalue()))
                to_upload_object = to_upload_object.replace("\\", "/")
                # Create the object in S3
                self._logger.debug("Creating object %s in %s", self._entity, self.__bucket_name)
                s3.Object(self.__bucket_name, to_upload_object).put(Body=buf.getvalue())
