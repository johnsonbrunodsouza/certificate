# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import time

from hdm.core.sink.sink import Sink
from hdm.core.dao.snowflake import Snowflake
from pandas import DataFrame
import os
from tempfile import TemporaryDirectory
import pandas as pd

# pandas_tools in the snowflake python connector has bugs prevent it from being used, so have to upload to stages and
# copy into tables manually
# TODO : check and Remove this. not needed anymore
from hdm.core.utils.generic_functions import GenericFunctions
from hdm.core.utils.project_config import ProjectConfig


class SnowflakeInternalStageSink(Sink):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__env = kwargs['env']
        self.__snowflake_dao = Snowflake(connection=self.__env)
        self.__file_format = kwargs.get('file_format', 'csv')
        self.__dest_path = os.path.abspath(kwargs.get('directory'))
        self.__stage_name = kwargs.get('stage_name')

    def produce(self, **kwargs) -> None:
        self._run(**kwargs)

    def _set_data(self, **kwargs) -> dict:
        df = kwargs['data_frame']
        table_name: str = kwargs.get("table_name")

        self._entity = kwargs.get('file_name', f"{ProjectConfig.file_prefix()}_{str(time.time_ns())}.csv")
        self._entity_filter = os.path.join(self._sink_name, GenericFunctions.table_to_folder(table_name))

        destination_directory = os.path.join(self.__dest_path, self._sink_name, GenericFunctions.table_to_folder(table_name))
        if not os.path.exists(destination_directory):
            os.makedirs(destination_directory)
        file_path = os.path.abspath(os.path.join(destination_directory, self._entity))

        self.__putFile(df, file_path, table_name)
        return dict(record_count=df.shape[0])

    def __putFile(self, df: pd.DataFrame, file_path, table_name) -> dict:
        if self.__file_format.lower() == 'csv':
            self.__create_temp_file(df, file_path)
            self._logger.info("Putting file: %s", file_path)
            with self.__snowflake_dao.connection as conn:
                cursor = conn.cursor()

                # create stage
                create_stage_sql = f"CREATE STAGE IF NOT EXISTS {self.__stage_name} "
                cursor.execute(create_stage_sql)

                # run put command
                upload_sql = f"PUT file://{file_path} @{self.__stage_name}/{self._sink_name}/{GenericFunctions.table_to_folder(table_name)} OVERWRITE = TRUE"
                cursor.execute(upload_sql)

    def __create_temp_file(self, df: DataFrame, file_path: str):
        # csv file created has issues with timetz column types, removed for now
        df.to_csv(file_path, index=False)
