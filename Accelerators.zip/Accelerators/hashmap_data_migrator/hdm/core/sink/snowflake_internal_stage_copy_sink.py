# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from sqlalchemy import false
from hdm.core.dao.snowflake import Snowflake
from hdm.core.dao.snowflake_internal_stage_copy import SnowflakeInternalStageCopy
from hdm.core.sink.snowflake_copy_sink import SnowflakeCopySink
import datetime


class SnowflakeInternalStageCopySink(SnowflakeCopySink):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._dao = Snowflake(connection=kwargs['env'])

    def _generate_query_for_table_creation_for_cdc(self, table_name):
        currenttimestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
        getddl = f"select GET_DDL('table', '{table_name}');"
        cdctable = f"{table_name}_CDC_{currenttimestamp}"
        getddl = getddl.replace(table_name, cdctable)
        return getddl

    def _generate_query_for_merge(self, table_name, cdc_table):
        columnlist = []
        primarykeys = []
        with self._dao.connection as conn:
            mergecursor = conn.cursor()
            mergecursor.execute('show columns in table ' + table_name + ' ;')
            
            for column in mergecursor:
                columnlist.append(column[2])
            mergecursor.execute('show primary keys in ' + table_name + ' ;')
            
            for primarykey in mergecursor:
                primarykeys.append(primarykey[4])            
                
        primarykeymatch = ""
        updatelist = ""
        insertlistcolumns = ""
        insertlistvalues = ""
        columnnumber = 1
        for column in columnlist:
            if column in primarykeys:
                primarykeymatch = f"{primarykeymatch} {table_name}.{column} = {cdc_table}.{column} AND "
                columnnumber = columnnumber + 1                    
            else:                                     
                updatelist = f"{updatelist} {table_name}.{column} = {cdc_table}.{column},"
                insertlistcolumns = f"{insertlistcolumns} {column},"
                insertlistvalues = f"{insertlistvalues} {cdc_table}.{column},"
                columnnumber = columnnumber + 1
                
        primarykeymatch = primarykeymatch[0:-4]
        updatelist = updatelist[0:-1]
        insertlistcolumns = insertlistcolumns[0:-1]
        insertlistvalues = insertlistvalues[0:-1]

        mergequery =  f"MERGE INTO {table_name} " \
                      f"USING {cdc_table} " \
                      f"ON {primarykeymatch} " \
                      f"WHEN MATCHED THEN UPDATE SET {updatelist} " \
                      f"WHEN NOT MATCHED THEN INSERT ( {insertlistcolumns} ) VALUES ( {insertlistvalues} )" 
        return mergequery

    def _generate_query(self, file_name, table_name) -> None:        
        text = f"'.*{file_name}.*'"
        self._query = f"COPY INTO {table_name} " \
                    f"FROM @{self._stage_name} " \
                    f"FILE_FORMAT = (TYPE = {self._file_format} SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\"') " \
                    f"PATTERN = {text} " \
                    f"PURGE = TRUE "
        