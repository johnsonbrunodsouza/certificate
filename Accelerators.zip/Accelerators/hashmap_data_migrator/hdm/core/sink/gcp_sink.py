# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os
import time
from google.cloud.storage import Blob
import pandas as pd

from hdm.core.dao.gcp import GCP
from hdm.core.sink.sink import Sink
from hdm.core.utils.generic_functions import GenericFunctions
from hdm.core.utils.project_config import ProjectConfig


class GCPSink(Sink):
    """
    S3 Source
    Expected protocol for configuration:
    connection: Connection choice to connect to different profiles.
    bucket_name: Bucket name to scan for loading files into dataframes
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.__bucket_name = kwargs.get('bucket_name')
        self.__env = kwargs['env']
        self.__gcp_dao = GCP(connection=self.__env, bucket=self.__bucket_name)
        self.__file_format = kwargs.get('file_format', 'csv')

    def produce(self, **kwargs) -> None:
        self._run(**kwargs)

    def _set_data(self, **kwargs) -> dict:
        """
        Creates CSV files for the passed dataframe.
        Args:
            **kwargs:
                data_frame: dataframe required to be written to S3 bucket
        """
        df = kwargs['data_frame']
        table_name: str = kwargs.get("table_name")

        self._entity = kwargs.get('file_name', f"{ProjectConfig.file_prefix()}_{str(time.time_ns())}.csv")
        self._entity_filter = os.path.join(self._sink_name, GenericFunctions.table_to_folder(table_name))

        # Create a connection to gcp storage

        # Make sure that the bucket exists and create it if it does not exist.
        gcp = self.__gcp_dao.connection
        self.__putFile(df, gcp, os.path.join(self._sink_name, GenericFunctions.table_to_folder(table_name), self._entity))

        return dict(record_count=df.shape[0])

    def __putFile(self, df: pd.DataFrame, gcp, to_upload_object) -> dict:
        if self.__file_format.lower() == 'csv':
            to_upload_object = to_upload_object.replace("\\", "/")
            gcp.get_bucket(self.__bucket_name).blob(to_upload_object).upload_from_string(df.to_csv(index=False), 'text/csv')
            # blob = Blob(to_upload_object, self.__bucket)
            # blob.upload_from_string(df.to_csv(index=False), 'self.__file_format')
            return dict(record_count=df.shape[0])