# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json

import pandas as pd
import enum

from jinjasql import JinjaSql

from hdm.core.dao.netezza_jdbc import NetezzaJDBC
from hdm.core.dao.netezza_odbc import NetezzaODBC
from hdm.core.query_templates.query_templates import QueryTemplates
from hdm.core.source.rdbms_source import RDBMSSource
from hdm.core.utils.project_config import ProjectConfig


class HashFunction(enum.Enum):
    HASH8 = "hash8"
    HASH4 = "hash4"
    HASH = "hash"


class NetezzaSource(RDBMSSource):

    def consume(self, **kwargs) -> dict:
        self._logger.info("Retrieving data from %s", self.__table)
        yield self._run(**kwargs)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__connection_choice = kwargs['env']
        self.__table = kwargs['table_name']
        self.__watermark = kwargs.get('watermark', [])
        self.__driver_type = kwargs.get('driver_type')
        self._entity = self.__table
        self._entity_filter = kwargs.get('watermark', None)
        self.__checksum = kwargs.get('checksum', [])
        self.__query = ""

    def _get_data(self, **kwargs) -> dict:
        self.__build_query()
        try:
            with NetezzaJDBC(connection=self.__connection_choice).connection as conn:
                df = pd.read_sql(self.__query, conn)
                return {'data_frame': df,
                        'record_count': df.shape[0],
                        'source_type': 'database',
                        'table_name': self.__table}
        except Exception:
            try:
                with NetezzaODBC(connection=self.__connection_choice).connection as conn:
                    df = pd.read_sql(self.__query, conn)
                    return {'data_frame': df,
                            'record_count': df.shape[0],
                            'source_type': 'database',
                            'table_name': self.__table}
            except Exception:
                raise ValueError("Unable to connect to Netezza source. Please check if source is up. Check the configuration: %s" % self.__connection_choice)

    def __build_query(self) -> None:
        """
        builds query.
        Default is no check_sum column
        checksum_methods:
        default method: generates random numbers as checksum value
        hash method:
            ** Important: Hash function needs IBM Netezza SQL Extensions toolkit installed
            checksum_method : hash
            hash_column  is the column to be hashed
            hash_function supported are :
                hash4 (returns the 32 bit checksum hash of the input data.)
                hash8 (returns the 64 bit hash of the input data)
                hash (returns hashed input data)
            ** Important: hash() function is much slower to calculate than hash4() and hash8()

        Returns: none

        """
        _checksum_flag, _query_limit, _watermark_flag, _last_record_pulled_flag, _last_record_pulled, _checksum_function, \
            _checksum_column, _watermark_column, _watermark_offset = (None,) * 9

        # Checksum
        if self.__checksum and self.__checksum['function'] and self.__checksum['column']:
            _checksum_flag = 'hash8' if self.__checksum['function'].lower() == HashFunction.HASH8.value else 'hash'
            _checksum_function = self.__checksum['function'].lower()
            _checksum_column = self.__checksum['column'].lower()

        # Watermark
        if self.__watermark and self.__watermark['column'] and self.__watermark['offset']:
            _watermark_flag, _watermark_column, _watermark_offset = True, self.__watermark['column'], self.__watermark['offset']

            if self._last_record_pulled:
                for key_value in self._last_record_pulled.split(','):
                    if self.__watermark['column'] == key_value.split(":")[0]:
                        _last_record_pulled_flag, _last_record_pulled = True, key_value.split(":")[1]
                        break

        # Query_limit
        if ProjectConfig.query_limit():
            _query_limit = ProjectConfig.query_limit()

        query_template = QueryTemplates.netezza_source_template
        params = {
            'table_name': self.__table,
            'watermark_flag': _watermark_flag,
            'watermark_column': _watermark_column,
            'watermark_offset': _watermark_offset,
            'checksum_function': _checksum_function,
            'checksum_column': _checksum_column,
            'last_record_pulled_flag': _last_record_pulled_flag,
            'last_record_pulled': _last_record_pulled,
            'query_limit': _query_limit
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        self.__query = query % bind_params

    """
    # per discussion , considering only 1 watermark column and greater than relationship
    @classmethod
    def _generate_watermarked_where_clause(self, watermark: dict, last_data_pulled, split_column) -> str:
        relation = watermark['relation']
        if relation == 'eq':
            where_clause = f"WHERE {watermark['column']} = {watermark['offset']}"
        elif relation == 'gt':
            where_clause = f"WHERE {watermark['column']} > {watermark['offset']}"
        elif relation == 'gte':
            where_clause = f"WHERE {watermark['column']} >= {watermark['offset']}"
        elif relation == 'lt':
            where_clause = f"WHERE {watermark['column']} < {watermark['offset']}"
        elif relation == 'lte':
            where_clause = f"WHERE {watermark['column']} lte {watermark['offset']}"
        else:
            raise ValueError(f'relation "{relation}" is not a valid relationship')

        if last_data_pulled:
            res = last_data_pulled.split(',')
            for val in res:
                arr = val.split(":")
                if split_column == arr[0]:
                    where_clause += f" AND {split_column} > {arr[1]}"

        return where_clause
    """
    """
    @classmethod
    def _generate_watermarked_order_clause(self, watermark: dict) -> str:
        order_clause = f"ORDER BY {watermark['column']}"
        return order_clause
    """
