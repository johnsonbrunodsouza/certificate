# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os

import pandas as pd

from hdm.core.dao.azure_blob import AzureBLOB
from hdm.core.dao.snowflake import Snowflake
from hdm.core.source.source import Source
from hdm.core.utils.generic_functions import GenericFunctions
from hdm.core.utils.project_config import ProjectConfig


class SnowflakeInternalStageSource(Source):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__env = kwargs['env']
        self.__snowflake_dao = Snowflake(connection=self.__env)
        self.__file_format = kwargs.get('file_format', 'csv')
        self.__stage_name = kwargs.get('stage_name')
        self.__dest_path = os.path.abspath(kwargs.get('directory'))

    def consume(self, **kwargs) -> dict:
        with self.__snowflake_dao.connection as conn:
            cursor = conn.cursor()

            # run list command
            list_sql = f"LIST @{self.__stage_name}"
            cursor.execute(list_sql)
            result = cursor.fetchall()

            for record in result:
                file_path = record[0].replace('.gz', '')
                try:
                    self._entity = file_path.split(self._source_name + "/")[1].split("/")[1]
                except IndexError:
                    raise Exception(f"Invalid source name {self._source_name}. The name should match the previous stage sink name. please check manifest YMAL file.")
                self._entity_filter = None

                kwargs['file'] = self._entity
                kwargs['table_name'] = GenericFunctions.folder_to_table(file_path.split(self._source_name + "/")[1].split("/")[0])

                try:
                    self._correlation_id_in = file_path.split(self._source_name + "/")[1].split("/")[1].split(f'{ProjectConfig.file_prefix()}_', 1)[1][0:-4]
                except Exception:
                    self._correlation_id_in = None

                # Assuming files available in the temporary snowflake local fs folder. if not download files first
                destination_directory = os.path.join(self.__dest_path, self._source_name, GenericFunctions.table_to_folder(kwargs['table_name']))
                if not os.path.exists(destination_directory):
                    os.makedirs(destination_directory)
                    # run get command - download files
                    # TODO: test code
                    get_sql = f"GET @{record[0]} file://{destination_directory}"
                    cursor.execute(get_sql)

                kwargs['path'] = destination_directory

                yield self._run(**kwargs)

    def _get_data(self, **kwargs) -> dict:
        file = kwargs['file']
        path = kwargs['path']
        table_name = kwargs['table_name']

        file_url = os.path.abspath(os.path.join(path, file))
        df = self.__process_file(file_url)

        return {'data_frame': df,
                'file_name': file,
                'record_count': df.shape[0],
                'table_name': table_name}

    def __process_file(self, filename: str) -> pd.DataFrame:
        """
        Return Dataframe for a file.
        Args:
            filename: Filename to be loaded to a dataframe
        """
        df = None
        if self.__file_format.lower() == 'csv':
            df = pd.read_csv(filename)
        return df
