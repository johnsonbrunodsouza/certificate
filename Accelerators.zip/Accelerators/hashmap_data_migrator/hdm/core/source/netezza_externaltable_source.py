# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import csv
import os
import time
import uuid

import jaydebeapi as connector
import enum

from jinjasql import JinjaSql

from hdm.core.dao.netezza_jdbc import NetezzaJDBC
from hdm.core.dao.netezza_odbc import NetezzaODBC
from hdm.core.query_templates.query_templates import QueryTemplates
from hdm.core.source.source import Source
from hdm.core.utils.generic_functions import GenericFunctions
from hdm.core.utils.project_config import ProjectConfig
import pandas as pd


class HashFunction(enum.Enum):
    HASH8 = "hash8"
    HASH4 = "hash4"
    HASH = "hash"


class NetezzaExternalTableSource(Source):
    """
    Used when Netezza external table is used for data offload.
        - get column names and type from data table
        - create external table using column names
    Note: before each run if external table exist it is dropped and created.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__dest_path = os.path.abspath(kwargs.get('directory'))
        if not os.path.exists(self.__dest_path):
            raise NotADirectoryError("Unable to create Sink landing at %s" % self.__dest_path)
        # TODO - More file types for later
        self.__chunk = kwargs.get('chunk', None)
        self.__checksum = kwargs.get('checksum_method', None)
        self.__file_format = kwargs.get('file_format', 'csv')
        self.__connection_choice = kwargs['env']
        self.__table = kwargs['table_name']
        self.__watermark = kwargs.get('watermark', [])
        self.__unload_file_name = ""
        self.__external_table_name = f"{self.__table}_{ProjectConfig.file_prefix().upper()}_EXT"
        self.__drop_query = f"DROP TABLE {self.__external_table_name} IF EXISTS;"
        self.__query = ""
        self._entity = self.__table
        self._entity_filter = self.__watermark
        self._correlation_id_out = uuid.uuid4().hex
        if self.__file_format == 'csv':
            self.__unload_file_name = kwargs.get("file_name", f"{ProjectConfig.file_prefix()}"
                                                              f"_{self._correlation_id_out}.csv")
        else:
            raise NotImplementedError("Unknown output type: %s" % self.__file_format)
        self._sink_entity = self.__unload_file_name

        file_path = os.path.abspath(os.path.join(self.__dest_path, self._sink_name, GenericFunctions.table_to_folder(self.__table)))
        if not os.path.exists(file_path):
            os.makedirs(file_path)
        self.__unload_file = os.path.abspath(os.path.join(file_path, self.__unload_file_name))
        self.__driver_type = ""
        self.__external_table_query = ""

    def consume(self, **kwargs) -> dict:
        yield self._run(**kwargs)

    def _get_data(self, **kwargs) -> dict:
        self.__build_query()
        print(self.__connection_choice)
        try:
            with NetezzaJDBC(connection=self.__connection_choice).connection as conn:
                self.__driver_type = 'JDBC' if isinstance(conn, connector.Connection) else 'ODBC'
                self.__generate_ext_table_by_columns(conn)

                cursor = conn.cursor()
                cursor.execute(self.__drop_query)
                cursor.execute(self.__external_table_query)
                cursor.execute(self.__query)
                df = pd.read_csv(self.__unload_file)
                return {'data_frame': df,
                        'record_count': df.shape[0],
                        'source_type': 'database'}
        except Exception:
            try:
                with NetezzaODBC(connection=self.__connection_choice).connection as conn:
                    self.__driver_type = 'JDBC' if isinstance(conn, connector.Connection) else 'ODBC'
                    self.__generate_ext_table_by_columns(conn)

                    cursor = conn.cursor()
                    cursor.execute(self.__drop_query)
                    cursor.execute(self.__external_table_query)
                    cursor.execute(self.__query)
                    df = pd.read_csv(self.__unload_file)
                    return {'data_frame': df,
                            'record_count': df.shape[0],
                            'source_type': 'database'}
            except Exception:
                raise ValueError("Unable to connect to Netezza External Table source. Please check if source is up. Check the configuration: %s" % self.__connection_choice)

    def __build_query(self) -> None:
        """
        builds query.
        Default is no check_sum column
        checksum_methods:
        default method: generates random numbers as checksum value
        hash method:
            ** Important: Hash function needs IBM Netezza SQL Extensions toolkit installed
            checksum_method : hash
            hash_column  is the column to be hashed
            hash_function supported are :
                hash4 (returns the 32 bit checksum hash of the input data.)
                hash8 (returns the 64 bit hash of the input data)
                hash (returns hashed input data)
            ** Important: hash() function is much slower to calculate than hash4() and hash8()

        Returns: none

        """
        _checksum_flag, _query_limit, _watermark_flag, _last_record_pulled_flag, _last_record_pulled, _checksum_function, \
            _checksum_column, _watermark_column, _watermark_offset = (None,) * 9

        # Checksum
        if self.__checksum and self.__checksum['function'] and self.__checksum['column']:
            _checksum_flag = 'hash8' if self.__checksum['function'].lower() == HashFunction.HASH8.value else 'hash'
            _checksum_function = self.__checksum['function'].lower()
            _checksum_column = self.__checksum['column'].lower()

        # Watermark
        if self.__watermark and self.__watermark['column'] and self.__watermark['offset']:
            _watermark_flag, _watermark_column, _watermark_offset = True, self.__watermark['column'], self.__watermark['offset']

            if self._last_record_pulled:
                for key_value in self._last_record_pulled.split(','):
                    if self.__watermark['column'] == key_value.split(":")[0]:
                        _last_record_pulled_flag, _last_record_pulled = True, key_value.split(":")[1]
                        break

        # Query_limit
        if ProjectConfig.query_limit():
            _query_limit = ProjectConfig.query_limit()

        query_template = QueryTemplates.netezza_external_source_template
        params = {
            'table_name': self.__table,
            'external_table_name': self.__external_table_name,
            'watermark_flag': _watermark_flag,
            'watermark_column': _watermark_column,
            'watermark_offset': _watermark_offset,
            'checksum_function': _checksum_function,
            'checksum_column': _checksum_column,
            'last_record_pulled_flag': _last_record_pulled_flag,
            'last_record_pulled': _last_record_pulled,
            'query_limit': _query_limit
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        self.__query = query % bind_params

    def __generate_ext_table_by_columns(self, conn) -> None:
        cursor = conn.cursor()
        # Get columns from source table
        query_template = QueryTemplates.netezza_get_columns_template
        params = {
            'table_name': self.__table
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        qry = query % bind_params

        cursor.execute(qry)
        result = cursor.fetchall()
        cols = ""
        for row in result:
            cols += "," + row[0] + ' ' + row[1]
        cols += "," + "CK_SUM INTEGER"

        # Generate external_table_query using the columns
        query_template = QueryTemplates.netezza_generate_external_table_template
        params = {
            'external_table_name': self.__external_table_name,
            'unload_file': self.__unload_file,
            'driver_type': self.__driver_type,
            'cols': cols[1:]
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        self.__external_table_query = query % bind_params

    """
    # per discussion , considering only 1 watermark column and greater than relationship
    @classmethod
    def _generate_watermarked_where_clause(self, watermark: dict) -> str:
        relation = watermark['relation']
        if relation == 'eq':
            where_clause = f"WHERE {watermark['column']} = {watermark['offset']}"
        elif relation == 'gt':
            where_clause = f"WHERE {watermark['column']} > {watermark['offset']}"
        elif relation == 'gte':
            where_clause = f"WHERE {watermark['column']} >= {watermark['offset']}"
        elif relation == 'lt':
            where_clause = f"WHERE {watermark['column']} < {watermark['offset']}"
        elif relation == 'lte':
            where_clause = f"WHERE {watermark['column']} lte {watermark['offset']}"
        else:
            raise ValueError(f'relation "{relation}" is not a valid relationship')
        return where_clause
    """
    """
    @classmethod
    def _generate_watermarked_order_clause(self, watermark: dict) -> str:
        order_clause = f"ORDER BY {watermark['column']}"
        return order_clause
    """
