# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json
import os
import pandas as pd
import enum
import datetime
from jinjasql import JinjaSql
import subprocess
import yaml

from hdm.core.dao.teradata import Teradata
from hdm.core.dao.mysql import MySQL
from hdm.core.query_templates.query_templates import QueryTemplates
from hdm.core.source.rdbms_source import RDBMSSource
from hdm.core.utils.project_config import ProjectConfig
from hdm.core.utils.generic_functions import GenericFunctions


class HashFunction(enum.Enum):
    STANDARD_HASH = "CRC32"


class TeradataSource(RDBMSSource):

    def consume(self, **kwargs) -> dict:
        self._logger.info("Retrieving data from %s", self.__table)
        yield self._run(**kwargs)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__connection_choice = kwargs['env']
        self.__table = kwargs['table_name']
        self.__watermark = kwargs.get('watermark', [])
        self.__driver_type = kwargs.get('driver_type')
        self._entity = self.__table
        self._entity_filter = kwargs.get('watermark', None)
        self.__checksum = kwargs.get('checksum', [])
        self.__tpt_path = kwargs.get('directory')
        self.__query = ""
        self.__current_timestamp = datetime.datetime.now()        
        self.__directory = os.path.join(self.__tpt_path, self._source_name, GenericFunctions.table_to_folder(self.__table))
        self.__destination_directory = os.path.join(self.__tpt_path, self._sink_name, GenericFunctions.table_to_folder(self.__table))

    def _get_data(self, **kwargs) -> dict:
        self.__build_query()
        #self.__get_data_with_tpt()
        try:
            #with Teradata(connection=self.__connection_choice).connection as conn:
            with MySQL(connection=self.__connection_choice).connection as conn:
                df = pd.read_sql(self.__query, conn)
            #df = pd.read_csv(os.path.join(self.__destination_directory, self.__table +"_delimited.csv"))
                return {'data_frame': df,
                        'record_count': df.shape[0],
                        'source_type': 'database',
                        'table_name': self.__table}
        except Exception:
            raise ValueError("Unable to connect to Teradata source. Please check if source is up. Check the configuration: %s" % self.__connection_choice)    

    def __build_query_for_tpt_schema(self, **kwargs):
        query_template = QueryTemplates.teradata_schema_template
        params = {
            'table_name': self.__table,
            'database_name': self.__table.split('.')[0]
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        query = query % bind_params
        return query

    def __build_tpt_script(self) -> None:
        try:   
            with Teradata(connection=self.__connection_choice).connection as conn:            
                df = pd.read_sql(self.__build_query_for_tpt_schema(), conn)
                
            schema = ""
            for index, row in df.iterrows():
                schema = schema + f"    {row['ColumnName']} {row['ColumnDataType']}, \n"
        except Exception:
            raise ValueError("Unable to connect to Teradata source. Please check if source is up. Check the configuration: %s" % self.__connection_choice)        
        
        try:
            if not os.path.isdir(self.__directory):
                os.makedirs(self.__directory)
            
            with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
                conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()][self.__connection_choice]
                user = conn_conf['user']
                pwd = conn_conf['password']
                host = conn_conf['host']

            tptscript = f"DEFINE JOB EXPORT_{self.__table} \n" \
                        "DESCRIPTION 'Exports {self.__table} data to a formatted file using EXPORT' \n" \
                        "( \n" \
                        "   DEFINE OPERATOR Consumer_File_Detail \n" \
                        "   DESCRIPTION 'Defining a consumer operator for storing retrieved data to a file' \n" \
                        "   TYPE DATACONNECTOR CONSUMER \n" \
                        "   SCHEMA * \n" \
                        "   ATTRIBUTES \n" \
                        "   ( \n" \
                        "       VARCHAR DirectoryPath='{self.__destination_directory}', \n" \
                        "       VARCHAR FileName='{self.__table}_delimited.csv', \n" \
                        "       VARCHAR FORMAT= 'DELIMITED', \n" \
                        "       VARCHAR OpenMode='Write', \n" \
                        "       VARCHAR TextDelimiter=',', \n" \
                        "       VARCHAR QuotedData='Optional' \n" \
                        "   ); \n" \
                        "   DEFINE SCHEMA Define_{self.__table}_Schema \n" \
                        "   DESCRIPTION 'Defining a Schema to describe the structure of the output file' \n" \
                        "   ( \n" \
                        "   {schema[:-3]} \n" \
                        "   ); \n" \
                        "   DEFINE OPERATOR Producer_Query_Detail \n" \
                        "   TYPE EXPORT \n" \
                        "   SCHEMA Define_{self.__table}_Schema \n" \
                        "   ATTRIBUTES \n" \
                        "   ( \n" \
                        "       VARCHAR UserName='{user}', \n" \
                        "       VARCHAR UserPassword='{pwd}', \n" \
                        "       VARCHAR SelectStmt ='{self.__query};' \n" \
                        "       VARCHAR Tdpid='{host}', \n" \
                        "       INTEGER MaxSessions=6, \n" \
                        "       INTEGER minsessions=2, \n" \
                        "       INTEGER TenacityHours=2, \n" \
                        "   ); \n" \
                        "   APPLY \n" \
                        "   TO OPERATOR( Consumer_File_Detail ) \n" \
                        "   SELECT * FROM OPERATOR( Producer_Query_Detail[2] ); \n" \
                        ");"
            
            
            with open(os.path.join(self.__directory, self.__table + self.__current_timestamp.replace(' ','_') + ".tpt"), 'w') as f:
                f.write(tptscript)

        except Exception:
            raise ValueError("Unable to write TPT script. Please check for errors...")        
        
    def __get_data_with_tpt(self, **kwargs):
        self.__build_tpt_script()
        try:
            subprocess.run(["tbuild","-f", os.path.join(self.__directory, self.__table + self.__current_timestamp.replace(' ','_') + ".tpt")], check=True)
        except Exception as e:
            raise ValueError("Error in running TPT script: " + str(e))


    def __build_query(self) -> None:
        """
        builds query.
        checksum_methods:
        default method: generates random numbers as checksum value
        Returns: none

        """
        _checksum_flag, _query_limit, _watermark_flag, _last_record_pulled_flag, _last_record_pulled, _checksum_function, \
            _checksum_column, _watermark_column, _watermark_offset, _watermark_offset_flag = (None,) * 10

        # Checksum
        if self.__checksum and self.__checksum['function'] and self.__checksum['column']:
            _checksum_flag = 'CRC32' if self.__checksum['function'].lower() == HashFunction.STANDARD_HASH.value else ''
            _checksum_function = self.__checksum['function'].lower()
            _checksum_column = self.__checksum['column'].lower()

        # Watermark
        if self.__watermark and self.__watermark['column']:
            _watermark_flag, _watermark_column = True, self.__watermark['column']

            if self.__watermark['offset'] and self.__watermark['offset'] != "":
                _watermark_offset_flag, _watermark_offset = True, self.__watermark['offset']

            if self._last_record_pulled:
                for key_value in self._last_record_pulled.split(','):
                    if self.__watermark['column'] == key_value.split("~#$")[0]:
                        _last_record_pulled_flag, _last_record_pulled = True, key_value.split("~#$")[1]
                        break

        # Query_limit
        if ProjectConfig.query_limit():
            _query_limit = ProjectConfig.query_limit()

        query_template = QueryTemplates.teradata_source_template
        params = {
            'table_name': self.__table,
            'watermark_flag': _watermark_flag,
            'watermark_column': _watermark_column,
            'watermark_offset_flag': _watermark_offset_flag,
            'watermark_offset': _watermark_offset,
            'checksum_function': _checksum_function,
            'checksum_column': _checksum_column,
            'last_record_pulled_flag': _last_record_pulled_flag,
            'last_record_pulled': _last_record_pulled,
            'query_limit': _query_limit
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        self.__query = query % bind_params
