# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from io import BytesIO
import pandas as pd

from hdm.core.dao.gcp import GCP
from hdm.core.source.source import Source
from hdm.core.utils.project_config import ProjectConfig
from hdm.core.utils.generic_functions import GenericFunctions


class GCPSource(Source):
    """
    GCP Source

    Expected protocol for configuration:
    connection: Connection choice to connect to different profiles.
    bucket_name: Bucket name to scan for loading files into dataframes
    """

    def __init__(self, **kwargs):
        """
        Construct an instance of the S3Source.
        Args:
            **kwargs:
                connection: connection name to connect to a specific profile
                bucket_name: bucket name used for scanning various files to be loaded to dataframes.
        Raises:
            RuntimeError: If bucket_name is null
        """
        # Connections are lazy - they are only created when being used
        super().__init__(**kwargs)

        self.__bucket_name = kwargs.get('bucket_name')
        self.__env = kwargs['env']

        self.__gcp_dao = GCP(connection=self.__env)
        self.__bucket = None
        self.__file_format = kwargs.get('file_format', 'csv')

    def consume(self, **kwargs) -> dict:
        """
        Yields a dataframe for each object from a gcp storage bucket
        Args:
            **kwargs
        """
        gcp = self.__gcp_dao.connection
        bucket = gcp.get_bucket(self.__bucket_name)

        # load the blobs along with last modified date as key in a dictionary for sorting.
        # currently there is no other way to sort blobs.
        blob_dict = dict()
        for blob_prop in list(gcp.list_blobs(bucket)):
            blob_dict[blob_prop.updated] = blob_prop

        for key in sorted(blob_dict):
            obj = blob_dict[key]
            if str(obj.name).rsplit('.')[-1] == 'csv':
                kwargs['obj'] = obj
                try:
                    self._entity = str(obj.name).split(self._source_name + "/")[1].split("/")[1]
                except IndexError:
                    raise Exception(f"Invalid source name {self._source_name}. The name should match the previous stage sink name. please check manifest YMAL file.")

                self._entity_filter = None

                kwargs['file'] = self._entity
                kwargs['table_name'] = GenericFunctions.folder_to_table(str(obj.name).split(self._source_name + "/")[1].split("/")[0])
                try:
                    self._correlation_id_in = str(obj.name).split(self._source_name + "/")[1].split("/")[1].split(f'{ProjectConfig.file_prefix()}_', 1)[1][0:-4]
                except Exception:
                    self._correlation_id_in = None

                yield self._run(**kwargs)

    def _get_data(self, **kwargs) -> dict:
        obj = kwargs['obj']
        file = kwargs['file']
        table_name = kwargs['table_name']

        df = pd.read_csv(BytesIO(obj.download_as_bytes()), encoding='utf8')
        return {'data_frame': df,
                'file_name': file,
                'record_count': df.shape[0],
                'table_name': table_name}
