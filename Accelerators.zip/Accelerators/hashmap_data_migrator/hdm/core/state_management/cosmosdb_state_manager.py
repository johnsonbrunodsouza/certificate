# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from jinjasql import JinjaSql
import pandas as pd

from hdm.core.state_management.state_manager import StateManager
from hdm.core.utils.project_config import ProjectConfig


class CosmosDBStateManager(StateManager):

    def __init__(self, **kwargs):
        kwargs['dao'] = 'cosmosdb'
        kwargs['format_date'] = False
        super().__init__(**kwargs)

    def _get_metadata_information(self) -> None:
        self._container = self._conn.connection.get_container_client('state_manager')
        self._table_name = ProjectConfig.state_manager_table_name()

    def _execute_query(self, query_template, params):
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        str_query = query % bind_params

        try:
            for item in self._container.query_items(
                    query=str_query, enable_cross_partition_query=True):

                df = pd.DataFrame([item])
                return df
        except Exception as e:
            return pd.DataFrame()

    def _run_query(self, query, state) -> dict:
        state['id'] = self._job_id
        state['sourcing_start_time'] = str(state['sourcing_start_time'])
        state['sourcing_end_time'] = str(state['sourcing_end_time'])
        state['sinking_start_time'] = str(state['sinking_start_time'])
        state['sinking_end_time'] = str(state['sinking_end_time'])
        state['source_name'] = self._source.name
        state['source_type'] = self._source.type
        state['sink_name'] = self._sink.name
        state['sink_type'] = self._sink.type
        state['manifest_name'] = self._manifest_name
        state['run_id'] = self._run_id
        state['job_id'] = self._job_id
        state['source_entity'] = state['entity']
        state['source_filter'] = state['entity_filter']
        state['row_count'] = state['record_count']
        self._container.upsert_item(state)

        return super()._generate_return_values(state)
