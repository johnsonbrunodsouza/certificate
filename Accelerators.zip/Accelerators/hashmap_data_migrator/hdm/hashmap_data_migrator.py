# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import logging.config
import click
import sys
sys.path.append('C:/NTTDATA/Accelerators/hashmap_data_migrator')
from hdm.core.utils.parse_config import ParseConfig
from hdm.migration_driver import MigrationDriver

default_log_settings = "/core/logs/log_settings.yml"


@click.command()
@click.option('-m', '--manifest', type=str, help='path of manifest to run')
@click.option('-l', '--log_settings', type=str, default=default_log_settings, help="log settings path")
@click.option('-e', '--env', default="prod", type=str, help="environment to take connection information from in hdm_profiles.yml")
@click.option('-s', '--data_staging', type=str, help="path where data files will be staged locally")
def run(manifest, log_settings, env, data_staging):
    os.environ['HDM_ENV'] = 'dev'#env 
    if log_settings == default_log_settings:
        log_settings = os.path.abspath(os.path.dirname(__file__) + default_log_settings)

    log_setting_values = ParseConfig.parse(config_path=log_settings)
    logging.config.dictConfig(log_setting_values)

    #####
    home = 'C:/NTTDATA/Accelerators/hashmap_data_migrator'
    manifest = f'{home}/test_manifest.yaml'
    # data_staging = f'{home}/staging'
    #####


    os.environ['HDM_MANIFEST'] = manifest
    # os.environ['HDM_DATA_STAGING'] = data_staging

    director = MigrationDriver()
    director.run()

run()
