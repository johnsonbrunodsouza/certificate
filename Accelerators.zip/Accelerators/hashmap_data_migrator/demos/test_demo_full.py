import os
from hdm.core.utils.parse_config import ParseConfig
from hdm.migration_driver import MigrationDriver
import logging.config
from datetime import datetime
from hdm.core.utils.project_config import ProjectConfig

os.environ['HDM_ENV'] = 'dev'
os.environ['HOME'] = 'C:/Users/xxx'  # available path of profile folder/file .hashmap_data_migrator\hdm_profile.yml
os.environ['HDM_MANIFEST'] = './manifests/manual_example_hive_source_sf_stage.yml'
os.environ['HDM_DATA_STAGING'] = 'D:/Work/temp/Input'  # available path to store files in local file system

if __name__ == "__main__":
    log_settings = ParseConfig.parse(config_path='C:/Users/xxx/PycharmProjects/hashmap_data_migrator/hdm/core/logs/log_settings.yml')
    logging.config.dictConfig(log_settings)

    # print(f'Number of records: {ProjectConfig.query_limit()}')

    dt_string = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    print("HDM Start date and time =", dt_string)

    director = MigrationDriver()
    director.run()

    # dd/mm/YY H:M:S
    dt_string = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    print("HDM End date and time =", dt_string)
