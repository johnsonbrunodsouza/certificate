# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from numpy import NaN
import pandas as pd
import re
import numpy as np

from hdc.core.map.mapper import Mapper


class TeradataToSnowflake(Mapper):

    data_type_map = {
        "BYTEINT": "BYTEINT",
        #"SMALLINT": "SMALLINT",
        "SMALLINT": "(.?(SMALLINT|INTERVAL DAY|INTERVAL HOUR|INTERVAL YEAR|INTERVAL MONTH|INTERVAL SECOND).?)",
        "INTEGER": "INTEGER",
        "BIGINT": "BIGINT",
        "DECIMAL": "DECIMAL",
        "FLOAT": "FLOAT",
        "NUMERIC": "NUMERIC",
        "NUMBER": "NUMBER",
        "CHAR": "CHAR",        
        "VARCHAR": "(.?(VARCHAR|LONG VARCHAR|CLOB|TIME WITH TIMEZONE|PERIOD\(TIMESTAMP\)|PERIOD\(DATE\)|PERIOD\(TIMESTAMP WITH TIME ZONE\)|PERIOD\(TIME\)|PERIOD\(TIME WITH TIME ZONE\)|INTERVAL DAY TO HOUR|INTERVAL DAY TO MINUTE|INTERVAL DAY TO SECOND|INTERVAL YEAR TO MONTH|INTERVAL MINUTE TO SECOND|INTERVAL HOUR TO MINUTE|INTERVAL HOUR TO SECOND).?)",
        "CHAR VARYING": "CHAR VARYING",
        "REAL": "REAL",        
        "DATE": "DATE",
        "TIME": "TIME",
        "TIMESTAMP_NTZ": "TIMESTAMP",
        "TIMESTAMP_TZ": "TIMESTAMP WITH TIME ZONE",
        "BINARY": "(.?^(BLOB|BYTE)$.?)",
        "VARBINARY": "(.?(VARBYTE|GRAPHIC).?)",
        "ARRAY": "ARRAY",
        "VARIANT": "(.?(JSON|XML).?)"
    }

    default_values_mapping = {
        "Current TimeStamp(0)" : "CURRENT_TIMESTAMP",
        "Date" : "CURRENT_DATE",
        "Time" : "CURRENT_TIME",
        "Current_User" : "CURRENT_USER",
        "USERNAME" : "CURRENT_USER",
        "Current Time(0)" : "CURRENT_TIME",
        "Current Date" : "CURRENT_DATE",
        "Current TimeStamp(6)" : "CURRENT_TIMESTAMP",
        "User" : "CURRENT_USER",
        "Current Time(6)" : "CURRENT_TIME"
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def map_assets(self, df_catalog_list: list) -> list:
        df_catalog = df_catalog_list[0]
        df_summary = df_catalog_list[1]
        unique_databases = df_catalog['DATABASE_NAME'].unique()

        # DDL for all unique databases
        sql_ddl_list = self.__map_databases(unique_databases)
        #sql_ddl_list = []
        # DDL for all schemas under each unique database
        for db in unique_databases:
            db_filter = df_catalog['DATABASE_NAME'] == db
            sql_ddl_list.extend(self.__map_schemas(db, df_catalog[db_filter]['SCHEMA_NAME'].unique()))

        # DDL for all tables under each unique database and schema
        sqllist, df = self.__map_tables(df_catalog, df_summary)
        sql_ddl_list.extend(sqllist)
        # sqllist = self.__map_views(df_catalog)
        # sql_ddl_list.extend(sqllist)

        if self._conf.get("report", False):
            self._build_report(df)
        
        return sql_ddl_list

    @staticmethod
    def __map_databases(databases) -> list:
        return [f'CREATE DATABASE IF NOT EXISTS "{db.upper()}"' for db in databases]

    @staticmethod
    def __map_schemas(database, schemas) -> list:
        return [f'CREATE SCHEMA IF NOT EXISTS "{database.upper()}"."{schema.upper()}"' for schema in schemas]

    @staticmethod
    def __map_data_types(src_data_type: pd.Series) -> pd.Series:
        keep = "|".join(TeradataToSnowflake.data_type_map.values())
        discard = f"(?!{keep})"
        supported_data_types = src_data_type.str.match(keep)
        unsupported_data_types = src_data_type.str.match(discard)
        target_data_type = src_data_type[supported_data_types]
        for target_type, source_type in TeradataToSnowflake.data_type_map.items():
            target_data_type = target_data_type.str.replace(source_type, target_type, case=False)

        return pd.concat([
            target_data_type,
            src_data_type[unsupported_data_types].str.replace('.*', '-', regex=True)
        ])

    @staticmethod
    def __map_null_clause(src_null_clause: pd.Series) -> pd.Series:
        return src_null_clause.map(lambda not_null: "NOT NULL" if not_null == 'N' else "") 
    
    @staticmethod
    def __map_default_values(src_default_clause: pd.Series) -> pd.Series:
        return src_default_clause.map(lambda defaultvalue: f" DEFAULT {TeradataToSnowflake.default_values_mapping.get(defaultvalue, defaultvalue)} " if defaultvalue != None else "")
    
    @staticmethod
    def __map_comments(src_comment_string: pd.Series) -> pd.Series:
        return src_comment_string.map(lambda comment: f" COMMENT '{comment}'" if comment != None else "")

    def __map_views(self, df: pd.DataFrame) -> list:
        sql_ddl = []
        df_catalog = df.loc[df['ObjectType'] == 'V'] 
        for view in df_catalog['ViewDefinition']:
            sql_ddl.append(re.sub('.*REPLACE VIEW','CREATE OR REPLACE VIEW ',re.sub('LOCKING.* ACCESS', '', view, re.MULTILINE), re.MULTILINE))

        return sql_ddl

    def __map_tables(self, df: pd.DataFrame, df_primarykeys: pd.DataFrame) -> list:
        sql_ddl = []

        df['COLUMN_TYPE'] = df['COLUMN_TYPE'].apply(lambda x: x.upper()) #MRD making the data types upper case
        df["COLUMN_NAME"] = df['COLUMN_NAME'].apply(lambda x: '"' + x + '"')
        df['TARGET_COLUMN_TYPE'] = self.__map_data_types(df['COLUMN_TYPE'])
        df['TARGET_DEFAULT_VALUE'] = self.__map_default_values(df['DEFAULT_VALUE'])
        df['TARGET_COMMENTS_VALUE'] = self.__map_comments(df['COMMENT_STRING'])
        df["TARGET_COLUMN_TYPE"] = df[["TARGET_COLUMN_TYPE", "COLUMN_SIZE"]].apply(lambda x: ''.join(x), axis=1)
        df['TARGET_COLUMN_TYPE'] = df['TARGET_COLUMN_TYPE'].apply(lambda x: x.upper())
        df["TARGET_COLUMN_TYPE"] = df[["TARGET_COLUMN_TYPE", "TARGET_DEFAULT_VALUE"]].apply(lambda x: ''.join(x), axis=1)
        df["TARGET_COLUMN_TYPE"] = df[["TARGET_COLUMN_TYPE", "TARGET_COMMENTS_VALUE"]].apply(lambda x: ''.join(x), axis=1)
        df['TARGET_NOT_NULL'] = self.__map_null_clause(df['NOT_NULL'])
        df['COLUMN_DESC'] = df['COLUMN_NAME'] \
                                    + ' ' \
                                    + df['TARGET_COLUMN_TYPE'] \
                                    + ' ' \
                                    + df['TARGET_NOT_NULL']

        df_table_group = df[
            ['DATABASE_NAME', 'SCHEMA_NAME', 'TABLE_NAME', 'TARGET_COLUMN_TYPE', 'COLUMN_DESC']].groupby(
            ['DATABASE_NAME', 'SCHEMA_NAME', 'TABLE_NAME'])
        
        create_or_replace_not_exists = ""
        if self._conf.get("recreate", True):
            create_or_replace_not_exists = "CREATE OR REPLACE TABLE"
        else:
            create_or_replace_not_exists = "CREATE TABLE IF NOT EXISTS"


        for name, group in df_table_group:
            #sql_ddl.append(f"CREATE OR REPLACE TABLE {'.'.join(name).upper()} "
            primarykey = ""
            query = ""
            tablename = name[2]
            databasename = name[0]
            schemaname = name[1]
            # if len(df_primarykeys[df_primarykeys['TABLE_NAME'] == tablename]) > 0:                                         
            #     primarykey = df_primarykeys[df_primarykeys['TABLE_NAME'] == tablename]['COLUMN_NAME'].iloc[0]
            
            if len(df_primarykeys[(df_primarykeys['TableName'] == tablename) & (df_primarykeys['DatabaseName'] == databasename) & (df_primarykeys['SchemaName'] == schemaname)]['PrimaryKey'].iloc[0]) > 0:                                         
                #primarykey = df_primarykeys[df_primarykeys['TableName'] == tablename]['COLUMN_NAME'].iloc[0]
                primarykey = df_primarykeys[(df_primarykeys['TableName'] == tablename) & (df_primarykeys['DatabaseName'] == databasename) & (df_primarykeys['SchemaName'] == schemaname)]['PrimaryKey'].iloc[0]

            query = f"{create_or_replace_not_exists} {'.'.join(name).upper()} " \
                    f"(" \
                    f"{','.join(list(group[~group['TARGET_COLUMN_TYPE'].str.contains('-')]['COLUMN_DESC']))}"
            
            if not primarykey:
                query = query + f")"
            else:
                primarykey = ','.join(['"' + elem.strip() + '"' for elem in primarykey.split(',')])
                query = query + f", PRIMARY KEY ({primarykey}))"

            sql_ddl.append(query)        
        return sql_ddl, df
