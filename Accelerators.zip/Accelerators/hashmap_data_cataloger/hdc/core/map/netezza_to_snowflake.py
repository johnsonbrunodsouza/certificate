# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pandas as pd

from hdc.core.map.mapper import Mapper


class NetezzaToSnowflake(Mapper):
    data_type_map = {        
        "VARCHAR": "(.?(CHARACTER VARYING|VARCHAR|CHAR|NCHAR|NVARCHAR|INTERVAL.*).?)",
        "TIMESTAMP_TZ": "TIME WITH TIME ZONE",
        "TIMESTAMP": "TIMESTAMP",
        "BOOLEAN": "(.?(BOOLEAN|BOOL).?)",
        "DATE": "DATE",
        "DOUBLE PRECISION": "DOUBLE PRECISION",
        "TIME": "TIME",
        "NUMBER": "(.?(DECIMAL|NUMERIC|INTEGER|BYTEINT|SMALLINT|BIGINT).?)",
        "FLOAT": "(.?(REAL|DOUBLE|FLOAT).?)",        
        "VARIANT": "(.?(XML|SPATIAL|VARBINARY|ST_ GEOMETRY).?)"
    }

    default_values_mapping = {}

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def map_assets(self, df_catalog_list) -> list:
        df_catalog = df_catalog_list[0]
        df_summary = df_catalog_list[1]
        unique_databases = df_catalog['DATABASE_NAME'].unique()

        # DDL for all unique databases
        sql_ddl_list = self.__map_databases(unique_databases)

        # DDL for all schemas under each unique database
        for db in unique_databases:
            db_filter = df_catalog['DATABASE_NAME'] == db
            sql_ddl_list.extend(self.__map_schemas(db, df_catalog[db_filter]['SCHEMA_NAME'].unique()))

        # DDL for all tables under each unique database and schema
        #sql_ddl_list.extend(self.__map_tables(df_catalog))
        sqllist, df = self.__map_tables(df_catalog, df_summary)
        sql_ddl_list.extend(sqllist)

        if self._conf.get("report", False):
            self._build_report(df_catalog)

        return sql_ddl_list

    @staticmethod
    def __map_databases(databases) -> list:
        return [f"CREATE DATABASE IF NOT EXISTS {db}" for db in databases]

    @staticmethod
    def __map_schemas(database, schemas) -> list:
        return [f"CREATE SCHEMA IF NOT EXISTS {database}.{schema}" for schema in
                schemas]

    @staticmethod
    def __map_data_types(src_data_type: pd.Series) -> pd.Series:
        keep = "|".join(NetezzaToSnowflake.data_type_map.values())
        discard = f"(?!{keep})"
        supported_data_types = src_data_type.str.match(keep)
        unsupported_data_types = src_data_type.str.match(discard)
        target_data_type = src_data_type[supported_data_types]
        for target_type, source_type in NetezzaToSnowflake.data_type_map.items():
            target_data_type = target_data_type.str.replace(source_type, target_type, case=False)

        return pd.concat([
            target_data_type,
            src_data_type[unsupported_data_types].str.replace('.*', '-', regex=True)
        ])

    @staticmethod
    def __map_null_clause(src_null_clause: pd.Series) -> pd.Series:
        return src_null_clause.map(lambda not_null: "NOT NULL" if not_null == 'YES' else "") 

    @staticmethod
    def __map_comments(src_comment_string: pd.Series) -> pd.Series:
        return src_comment_string.map(lambda comment: f" COMMENT '{comment}'" if comment != None else "")

    @staticmethod
    def __map_default_values(src_default_clause: pd.Series) -> pd.Series:
        return src_default_clause.map(lambda defaultvalue: f" DEFAULT {NetezzaToSnowflake.default_values_mapping.get(defaultvalue, defaultvalue)} " if defaultvalue != None else "")

    def __map_tables(self, df: pd.DataFrame, df_primarykeys: pd.DataFrame) -> list:
        sql_ddl = []
        df['COLUMN_TYPE'] = df['COLUMN_TYPE'].apply(lambda x: x.upper()) #MRD making the data types upper case
        df["COLUMN_NAME"] = df['COLUMN_NAME'].apply(lambda x: '"' + x + '"')
        df['TARGET_COLUMN_TYPE'] = self.__map_data_types(df['COLUMN_TYPE'])
        df['TARGET_DEFAULT_VALUE'] = self.__map_default_values(df['DEFAULT_VALUE'])
        df['TARGET_COMMENTS_VALUE'] = self.__map_comments(df['COMMENT_STRING'])
        df["TARGET_COLUMN_TYPE"] = df[["TARGET_COLUMN_TYPE", "COLUMN_SIZE"]].apply(lambda x: ''.join(x), axis=1)
        df['TARGET_COLUMN_TYPE'] = df['TARGET_COLUMN_TYPE'].apply(lambda x: x.upper())
        df["TARGET_COLUMN_TYPE"] = df[["TARGET_COLUMN_TYPE", "TARGET_DEFAULT_VALUE"]].apply(lambda x: ''.join(x), axis=1)
        df["TARGET_COLUMN_TYPE"] = df[["TARGET_COLUMN_TYPE", "TARGET_COMMENTS_VALUE"]].apply(lambda x: ''.join(x), axis=1)
        df['TARGET_NOT_NULL'] = self.__map_null_clause(df['NOT_NULL'])
        df['COLUMN_DESC'] = df['COLUMN_NAME'] \
                                    + ' ' \
                                    + df['TARGET_COLUMN_TYPE'] \
                                    + ' ' \
                                    + df['TARGET_NOT_NULL']

        # df_catalog['TARGET_COLUMN_TYPE'] = self.__map_data_types(df_catalog['COLUMN_TYPE'])
        # df_catalog['TARGET_NOT_NULL'] = self.__map_null_clause(df_catalog['NOT_NULL'])
        # df_catalog['COLUMN_DESC'] = df_catalog['COLUMN_NAME'] \
        #                             + ' ' \
        #                             + df_catalog['TARGET_COLUMN_TYPE'] \
        #                             + ' ' \
        #                             + df_catalog['TARGET_NOT_NULL']

        # df_table_group = df_catalog[
        #     ['DATABASE_NAME', 'SCHEMA_NAME', 'TABLE_NAME', 'TARGET_COLUMN_TYPE', 'COLUMN_DESC']].groupby(
        #     ['DATABASE_NAME', 'SCHEMA_NAME', 'TABLE_NAME'])
        create_or_replace_not_exists = "CREATE TABLE"
        if self._conf.get("recreate", True):
            create_or_replace_not_exists = "CREATE OR REPLACE TABLE"
        else:
            create_or_replace_not_exists = "CREATE TABLE IF NOT EXISTS"

        df_table_group = df[
            ['DATABASE_NAME', 'SCHEMA_NAME', 'TABLE_NAME', 'TARGET_COLUMN_TYPE', 'COLUMN_DESC']].groupby(
            ['DATABASE_NAME', 'SCHEMA_NAME', 'TABLE_NAME'])

        for name, group in df_table_group:
            primarykey = ""
            query = ""
            tablename = name[2]
            databasename = name[0]
            schemaname = name[1]
            if len(df_primarykeys[(df_primarykeys['TABLENAME'] == tablename) & (df_primarykeys['DATABASENAME'] == databasename) & (df_primarykeys['SCHEMANAME'] == schemaname)]['PRIMARYKEY'].iloc[0]) > 0:                                                         
                primarykey = df_primarykeys[(df_primarykeys['TABLENAME'] == tablename) & (df_primarykeys['DATABASENAME'] == databasename) & (df_primarykeys['SCHEMANAME'] == schemaname)]['PRIMARYKEY'].iloc[0]
            
            query = f"{create_or_replace_not_exists} {'.'.join(name).upper()} " \
                    f"(" \
                    f"{','.join(list(group[~group['TARGET_COLUMN_TYPE'].str.contains('-')]['COLUMN_DESC']))}"
            
            if not primarykey:
                query = query + f")"
            else:
                primarykey = ','.join(['"' + elem.strip() + '"' for elem in primarykey.split(',')])
                query = query + f", PRIMARY KEY ({primarykey}))"

            sql_ddl.append(query)        
    
        return sql_ddl, df

        # for name, group in df_table_group:
        #     sql_ddl.append(f"CREATE OR REPLACE TABLE {'.'.join(name).upper()} "
        #                    f"("
        #                    f"{','.join(list(group[~group['TARGET_COLUMN_TYPE'].str.contains('-')]['COLUMN_DESC'])).upper()}"
        #                    f", CK_SUM VARCHAR"
        #                    f")")

        # return sql_ddl
