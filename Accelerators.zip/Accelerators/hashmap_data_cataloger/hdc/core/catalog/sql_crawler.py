#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
"""
#TODO: Module description
"""

from string import Template

import pandas as pd
from providah.factories.package_factory import PackageFactory as providah_pkg_factory

from hdc.core.catalog.rdbms_crawler import RdbmsCrawler
from hdc.core.dao.rdbms_dao import RdbmsDAO


class SQLCrawler(RdbmsCrawler):
    __template_select_all_tables = Template("""
                                                select 
                                                    ic.TABLE_CATALOG AS DATABASE_NAME,
                                                    ic.TABLE_SCHEMA AS SCHEMA_NAME,
                                                    ic.TABLE_NAME, 
                                                    ic.COLUMN_NAME, 
                                                    ic.DATA_TYPE AS COLUMN_TYPE,
                                                    CASE
                                                        WHEN ic.numeric_precision IS NOT NULL AND ISNULL(ic.NUMERIC_SCALE, 0) > 0 THEN '(' + ltrim(str(ic.numeric_precision)) + ',' + ltrim(str(ic.NUMERIC_SCALE)) + ')'
                                                        WHEN ic.numeric_precision IS NOT NULL AND ISNULL(ic.NUMERIC_SCALE, 0) = 0 THEN '(' + ltrim(str(ic.numeric_precision)) + ')' 
                                                        WHEN ic.CHARACTER_MAXIMUM_LENGTH IS NOT NULL THEN '(' + ltrim(str(ic.CHARACTER_MAXIMUM_LENGTH)) + ')'
                                                        ELSE ''
                                                    END AS COLUMN_SIZE,
                                                    ic.IS_NULLABLE as NOT_NULL,
                                                    convert(varchar(1000), ic.COLUMN_DEFAULT) as DEFAULT_VALUE,
                                                    convert(varchar(1000), ep.value) as COMMENT_STRING,
                                                    COALESCE(ic.CHARACTER_SET_NAME, ic.CHARACTER_SET_SCHEMA, ic.CHARACTER_SET_CATALOG) as CHARACTER_SET_NAME,
                                                    COALESCE(ic.COLLATION_NAME, ic.COLLATION_SCHEMA, ic.COLLATION_CATALOG) as COLLATION_NAME
                                                FROM INFORMATION_SCHEMA.COLUMNS ic
                                                LEFT JOIN sys.tables t
                                                    on ic.TABLE_NAME = t.name
                                                LEFT JOIN sys.columns c
                                                    on t.object_id = c.object_id
                                                    and ic.ORDINAL_POSITION = c.column_id
                                                LEFT JOIN sys.extended_properties ep
                                                    on c.object_id = ep.major_id
                                                    and c.column_id = ep.minor_id
                                                where t.is_ms_shipped = 0	
                                                ORDER BY ic.TABLE_NAME, ic.ORDINAL_POSITION;
                                            """)
    
    __template_select_summary = Template("""
                                            with tablemetrics as
                                            (
                                                SELECT
                                                    DB_NAME() as DatabaseName,
                                                    s.Name AS SchemaName,
                                                    t.Name AS TableName,
                                                    p.rows AS RowCounts,
                                                    CAST(ROUND((SUM(a.total_pages) / 128.00), 2) AS NUMERIC(36, 2)) AS Total_MB,
                                                    t.object_id,
                                                    t.modify_date,
                                                    t.type_desc as TableType
                                                FROM sys.tables t
                                                INNER JOIN sys.indexes i 
                                                    ON t.OBJECT_ID = i.object_id
                                                INNER JOIN sys.partitions p 
                                                    ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
                                                INNER JOIN sys.allocation_units a 
                                                    ON p.partition_id = a.container_id
                                                INNER JOIN sys.schemas s 
                                                    ON t.schema_id = s.schema_id
                                                WHERE t.is_ms_shipped = 0	
                                                GROUP BY t.Name, s.Name, p.Rows, t.object_id, t.modify_date, t.type_desc
                                            ),
                                            primarykeys as 
                                            (
                                                select distinct 
                                                    C1.TABLE_CATALOG, 
                                                    C1.TABLE_SCHEMA, 
                                                    C1.TABLE_NAME,
                                                    TRIM(stuff(
                                                            (
                                                                select 
                                                                    ', ' + C.COLUMN_NAME
                                                                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS T  
                                                                JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C  
                                                                    ON C.CONSTRAINT_NAME=T.CONSTRAINT_NAME  
                                                                WHERE C.TABLE_NAME=c1.TABLE_NAME
                                                                and T.CONSTRAINT_TYPE='PRIMARY KEY'  						
                                                                FOR XML PATH('')
                                                            ), 1, 1, ''
                                                        )) as PK
                                                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS T1  
                                                JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C1  
                                                    ON C1.CONSTRAINT_NAME=T1.CONSTRAINT_NAME  
                                                WHERE T1.CONSTRAINT_TYPE='PRIMARY KEY'
                                            ),
                                            foreignkeys as 
                                            (
                                                select distinct  
                                                    u1.TABLE_CATALOG,
                                                    u1.TABLE_SCHEMA,
                                                    u1.TABLE_NAME,
                                                    stuff((
                                                        select ' # ' + u.FK
                                                        from (
                                                                select distinct 
                                                                    C1.TABLE_CATALOG, 
                                                                    C1.TABLE_SCHEMA, 
                                                                    C1.TABLE_NAME,
                                                                    C1.CONSTRAINT_NAME + ' - ' + 
                                                                    TRIM(stuff(
                                                                            (
                                                                                select 
                                                                                    ', ' + C.COLUMN_NAME
                                                                                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS T  
                                                                                JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C  
                                                                                    ON C.CONSTRAINT_NAME=T.CONSTRAINT_NAME  
                                                                                WHERE C.TABLE_NAME=c1.TABLE_NAME
                                                                                and T.CONSTRAINT_TYPE='FOREIGN KEY'  
                                                                                and T.CONSTRAINT_NAME = T1.CONSTRAINT_NAME
                                                                                FOR XML PATH('')
                                                                            ), 1, 1, ''
                                                                        )) as FK
                                                                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS T1  
                                                                JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C1  
                                                                    ON C1.CONSTRAINT_NAME=T1.CONSTRAINT_NAME  
                                                                WHERE T1.CONSTRAINT_TYPE='FOREIGN KEY'
                                                        ) u
                                                        where u.TABLE_CATALOG = u1.TABLE_CATALOG
                                                        and u.TABLE_NAME = u1.TABLE_NAME
                                                        and u.TABLE_SCHEMA = u1.TABLE_SCHEMA        
                                                        for xml path('')
                                                    ),1,1,'') as ForeignKey
                                                from (
                                                        select distinct 
                                                            C1.TABLE_CATALOG, 
                                                            C1.TABLE_SCHEMA, 
                                                            C1.TABLE_NAME,
                                                            C1.CONSTRAINT_NAME,
                                                            TRIM(stuff(
                                                                    (
                                                                        select 
                                                                            ', ' + C.COLUMN_NAME
                                                                        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS T  
                                                                        JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C  
                                                                            ON C.CONSTRAINT_NAME=T.CONSTRAINT_NAME  
                                                                        WHERE C.TABLE_NAME=c1.TABLE_NAME
                                                                        and T.CONSTRAINT_TYPE='FOREIGN KEY'  
                                                                        and T.CONSTRAINT_NAME = T1.CONSTRAINT_NAME
                                                                        FOR XML PATH('')
                                                                    ), 1, 1, ''
                                                                )) as FK
                                                        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS T1  
                                                        JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C1  
                                                            ON C1.CONSTRAINT_NAME=T1.CONSTRAINT_NAME  
                                                        WHERE T1.CONSTRAINT_TYPE='FOREIGN KEY'
                                                ) u1
                                                group by TABLE_CATALOG, TABLE_NAME, TABLE_SCHEMA, FK, CONSTRAINT_NAME
                                            ),
                                            tablecomments as 
                                            (
                                                select 
                                                    major_id as object_id,
                                                    convert(varchar(1000), value) as COMMENT_STRING
                                                from sys.extended_properties
                                                where minor_id = 0
                                            ),
                                            lastaccess as 
                                            (
                                                select 
                                                    DB_NAME() as DatabaseName,
                                                    [schema_name], 
                                                    table_name, 
                                                    max(last_access) as last_access 
                                                    from(
                                                            select 
                                                                schema_name(schema_id) as schema_name,
                                                                name as table_name,
                                                                (
                                                                    select 
                                                                        max(last_access) 
                                                                    from (values(last_user_seek), (last_user_scan), (last_user_lookup), (last_user_update)) as tmp(last_access)
                                                                ) as last_access
                                                            from sys.dm_db_index_usage_stats sta
                                                            join sys.objects obj
                                                                on obj.object_id = sta.object_id
                                                                and obj.type = 'U'
                                                                and sta.database_id = DB_ID()
                                                        ) usage
                                                group by schema_name, table_name
                                            ),
                                            columncounts as 
                                            (
                                                select 
                                                    TABLE_CATALOG,
                                                    TABLE_SCHEMA,
                                                    TABLE_NAME,
                                                    count(*) as ColumnCount
                                                from INFORMATION_SCHEMA.COLUMNS
                                                group by TABLE_CATALOG,	TABLE_SCHEMA, TABLE_NAME
                                            ),
                                            probablewatermarks as
                                            (
                                                select distinct C1.TABLE_CATALOG, C1.TABLE_SCHEMA, C1.TABLE_NAME,
                                                TRIM(stuff(
                                                                    (
                                                                        select 
                                                                            ', ' + C.COLUMN_NAME
                                                                        FROM INFORMATION_SCHEMA.Columns C
                                                                        WHERE C.TABLE_NAME = c1.TABLE_NAME
                                                                        AND  C.TABLE_SCHEMA = C1.TABLE_SCHEMA
                                                                        AND C.TABLE_CATALOG = C1.TABLE_CATALOG
                                                                        and C.DATA_TYPE in ('smalldatetime','datetime', 'datetime2', 'datetimeoffset')  						
                                                                        FOR XML PATH('')
                                                                    ), 1, 1, ''
                                                                )) as watermarkcolumns
                                                FROM INFORMATION_SCHEMA.Columns C1  
                                                where C1.DATA_TYPE in ('smalldatetime','datetime', 'datetime2', 'datetimeoffset')
                                            ),
                                            indexcolumns as 
                                            (
                                                select distinct  
                                                u1.object_id,
                                                stuff((
                                                        select ' # ' + u.IndexColumns
                                                        from (
                                                                select distinct 
                                                                i.object_id, i.name + ' - '  +
                                                                TRIM(stuff(
                                                                                (
                                                                                    select 
                                                                                        ', ' + c1.name
                                                                                    from sys.indexes i1
                                                                                    inner join sys.index_columns ic1
                                                                                        on i1.object_id = ic1.object_id
                                                                                        and i1.index_id = ic1.index_id
                                                                                    inner join sys.columns c1
                                                                                        on c1.object_id = i1.object_id
                                                                                        and c1.column_id = ic1.column_id	
                                                                                    where i.object_id = i1.object_id
                                                                                    and ic1.object_id = ic.object_id
                                                                                    and ic1.index_id = ic.index_id
                                                                                    FOR XML PATH('')
                                                                                ), 1, 1, ''
                                                                            )) as IndexColumns
                                                                from sys.indexes i
                                                                inner join sys.index_columns ic
                                                                    on i.object_id = ic.object_id
                                                                    and i.index_id = ic.index_id
                                                                where i.is_primary_key = 0
                                                            ) u
                                                        where u.object_id = u1.object_id
                                                        for xml path('')
                                                    ),1,1,'') as IndexColumns
                                                from (
                                                        select distinct 
                                                            i.object_id, i.name + ' - '  +
                                                            TRIM(stuff(
                                                                            (
                                                                                select 
                                                                                    ', ' + c1.name
                                                                                from sys.indexes i1
                                                                                inner join sys.index_columns ic1
                                                                                    on i1.object_id = ic1.object_id
                                                                                    and i1.index_id = ic1.index_id
                                                                                inner join sys.columns c1
                                                                                    on c1.object_id = i1.object_id
                                                                                    and c1.column_id = ic1.column_id	
                                                                                where i.object_id = i1.object_id
                                                                                and ic1.object_id = ic.object_id
                                                                                and ic1.index_id = ic.index_id
                                                                                FOR XML PATH('')
                                                                            ), 1, 1, ''
                                                                        )) as IndexColumns
                                                            from sys.indexes i
                                                            inner join sys.index_columns ic
                                                                on i.object_id = ic.object_id
                                                                and i.index_id = ic.index_id
                                                            where i.is_primary_key = 0
                                                    ) u1
                                                group by u1.object_id
                                            ),
                                            triggerspresent as 
                                            (
                                                select 
                                                    'Y' as TriggerPresent,
                                                    parent_id
                                                from sys.triggers
                                            ),
                                            partitioncolumns as 
                                            (
                                                SELECT 
                                                    t.object_id, 
                                                    c.name AS PartitionColumn		
                                                FROM sys.tables AS t   
                                                JOIN sys.indexes AS i   
                                                    ON t.[object_id] = i.[object_id]   
                                                    AND i.[type] <= 1
                                                JOIN sys.partition_schemes AS ps   
                                                    ON ps.data_space_id = i.data_space_id   
                                                JOIN sys.index_columns AS ic   
                                                    ON ic.[object_id] = i.[object_id]   
                                                    AND ic.index_id = i.index_id   
                                                    AND ic.partition_ordinal >= 1 
                                                JOIN sys.columns AS c   
                                                    ON t.[object_id] = c.[object_id]   
                                                    AND ic.column_id = c.column_id 
                                            )
                                            select
                                                t.DatabaseName,
                                                t.SchemaName,
                                                t.TableName,
                                                t.TableType,
                                                p.PK as PrimaryKey,
                                                f.ForeignKey,
                                                i.IndexColumns,
                                                t.RowCounts,
                                                cc.ColumnCount as ColumnCount,
                                                t.Total_MB as TableSizeInMb,
                                                c.COMMENT_STRING as Comments,
                                                w.watermarkcolumns as ProabableWatermarkColumns,
                                                COALESCE(tr.TriggerPresent, 'N') as TriggerPresent,
                                                pc.PartitionColumn,
                                                l.last_access as LastAccessed,
                                                t.modify_date as LastModified	
                                            from tablemetrics t
                                            left join tablecomments c
                                                on t.object_id = c.object_id
                                            left join primarykeys p
                                                on p.TABLE_CATALOG = t.DatabaseName
                                                and p.TABLE_SCHEMA = t.SchemaName
                                                and p.TABLE_NAME = t.TableName
                                            left join foreignkeys f
                                                on f.TABLE_CATALOG = t.DatabaseName
                                                and f.TABLE_SCHEMA = t.SchemaName
                                                and f.TABLE_NAME = t.TableName
                                            left join lastaccess l
                                                on t.DatabaseName = l.DatabaseName
                                                and t.SchemaName = l.schema_name
                                                and t.TableName = l.table_name
                                            left join columncounts cc
                                                on cc.TABLE_CATALOG = t.DatabaseName
                                                and cc.TABLE_SCHEMA = t.SchemaName
                                                and cc.TABLE_NAME = t.TableName 
                                            left join probablewatermarks w
                                                on w.TABLE_CATALOG = t.DatabaseName
                                                and w.TABLE_SCHEMA = t.SchemaName
                                                and w.TABLE_NAME = t.TableName  
                                            left join indexcolumns i
                                                on i.object_id = t.object_id
                                            left join triggerspresent tr
                                                on tr.parent_id = t.object_id
                                            left join partitioncolumns pc
                                                on t.object_id = pc.object_id
    """
    )

    __template_get_all_databases = Template("""
                                                SELECT name 
                                                FROM master.sys.sysdatabases
                                                WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb')
                                                and name = ISNULL(NULLIF(convert(varchar(1000),'$db'),''),name);
                                            """)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def obtain_catalog(self) -> pd.DataFrame:
        try:                                   
            df_table_catalog = pd.DataFrame()
            df_table_summary = pd.DataFrame() 
            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile'], 'database': "master"})
            
            # Extract the table metadata/catalog from connected SQL source
            sql_database = dao.get_conn_profile_key("sid") if dao.get_conn_profile_key("sid") is not None \
                else dao.get_conn_profile_key("database")
            if sql_database == None:
                sql_database = ""
            databases: pd.DataFrame = self._fetch_all(dao, query_string=SQLCrawler.__template_get_all_databases.substitute(db=sql_database))
            
            databaselist = [x for x in databases['name']]
            for database in databaselist:
                dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile'], 'database': database})
                df_table_details: pd.DataFrame = self._fetch_all(dao,
                                                             query_string=SQLCrawler.__template_select_all_tables.substitute(
                                                                 db=database,
                                                                 user=dao.get_conn_profile_key("user")
                                                             ))
                df_table_catalog = pd.concat([df_table_catalog, df_table_details])

                df_table_summ: pd.DataFrame = self._fetch_all(dao,
                                                             query_string=SQLCrawler.__template_select_summary.substitute(
                                                                 db=database,
                                                                 user=dao.get_conn_profile_key("user")
                                                             ))
                df_table_summary = pd.concat([df_table_summary, df_table_summ])
            
            return [df_table_catalog, df_table_summary]

        except Exception as e:
            raise e

        return None
