# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
#TODO: Module description
"""

from string import Template

import pandas as pd
from providah.factories.package_factory import PackageFactory as providah_pkg_factory

from hdc.core.catalog.rdbms_crawler import RdbmsCrawler
from hdc.core.dao.rdbms_dao import RdbmsDAO


class NetezzaCrawler(RdbmsCrawler):
    #__select_all_databases = "SELECT DATABASE FROM _V_DATABASE WHERE DATABASE <> 'SYSTEM' "
    __template_select_all_schemas_in_database = Template("SELECT DISTINCT SCHEMA FROM $db_name.._V_SCHEMA;")
    __template_select_all_tables = Template("""
                                                SELECT 
                                                    c.DATABASE as DATABASE_NAME, 
                                                    c.SCHEMA as SCHEMA_NAME, 
                                                    c.NAME as TABLE_NAME, 
                                                    c.ATTNAME as COLUMN_NAME, 
                                                    CASE 
                                                        WHEN INSTR(c.FORMAT_TYPE,'(') > 0 THEN SUBSTRING(c.FORMAT_TYPE, 1, INSTR(c.FORMAT_TYPE,'(') - 1) 
                                                        ELSE c.FORMAT_TYPE
                                                    END as COLUMN_TYPE, 
                                                    CASE 
                                                        WHEN c.FORMAT_TYPE = 'INTERVAL' THEN '(200)'
                                                        WHEN INSTR(c.FORMAT_TYPE,'(') > 0 THEN SUBSTRING(c.FORMAT_TYPE, INSTR(c.FORMAT_TYPE,'('), INSTR(c.FORMAT_TYPE,')')) 
                                                        ELSE '(' || c.ATTCOLLENG || ')' 
                                                    end as COLUMN_SIZE, 
                                                    case
                                                        when c.ATTNOTNULL IN ('f', 'FALSE') then 'NO'
                                                        else 'YES'
                                                    end as NOT_NULL, 
                                                    c.COLDEFAULT as DEFAULT_VALUE,
                                                    c.DESCRIPTION AS COMMENT_STRING,
                                                    COALESCE(d.DB_CHARSET) AS CHARACTER_SET_NAME,
                                                    COALESCE(d.DB_COLLATION) AS COLLATION_NAME
                                                FROM _V_RELATION_COLUMN c
                                                LEFT JOIN _v_database d 
                                                    ON d.DATABASE = c.DATABASE	
                                                WHERE c.DATABASE <> 'SYSTEM' 
                                                AND TYPE = 'TABLE' 
                                                ORDER BY SCHEMA, NAME, ATTNUM ASC;
    """)
    
    __template_get_all_databases = Template("""
                                                SELECT 
                                                    DATABASE AS NAME
                                                FROM _v_database
                                                WHERE DATABASE = COALESCE(NULLIF('$db',''), DATABASE)
                                                ORDER BY DATABASE;
    """)

    __template_select_summary = Template("""
                                            WITH tablesummary AS (
                                                SELECT 
                                                    DATABASE AS DatabaseName,
                                                    SCHEMA AS SchemaName,
                                                    TABLENAME AS TableName,
                                                    OBJTYPE AS TableType,
                                                    DESCRIPTION  AS Comments,
                                                    CASE 
                                                        WHEN RELTRIGGERS > 0 THEN 'Y'
                                                        ELSE 'N'
                                                    END AS TriggerPresent,
                                                    RELTUPLES As RowCounts
                                                FROM _V_TABLE 
                                                WHERE OBJTYPE = 'TABLE'
                                                AND DATABASE = '$db' 
                                            ),
                                            tablesize AS (
                                                SELECT 
                                                    TABLENAME AS TableName,
                                                    used_bytes/pow(1024,2) AS TableSizeInMb
                                                FROM _v_table_storage_stat
                                            ),
                                            columncount AS (
                                                SELECT 
                                                    DATABASE AS DatabaseName,
                                                    SCHEMA AS SchemaName,
                                                    name AS TableName,
                                                    count(*) AS ColumnCount
                                                FROM _V_RELATION_COLUMN
                                                WHERE TYPE = 'TABLE'
                                                AND DATABASE = '$db' 
                                                GROUP BY DATABASE, SCHEMA, name 
                                            )
                                            SELECT 
                                                summ.DatabaseName,
                                                summ.SchemaName,
                                                summ.TableName,
                                                summ.TableType,
                                                '' AS PrimaryKey,
                                                '' AS ForeignKey,
                                                '' AS Indexes,
                                                summ.RowCounts,
                                                cc.ColumnCount,
                                                s.TableSizeInMb,
                                                summ.Comments,
                                                '' AS ProbableWatermarkColumns,
                                                summ.TriggerPresent,
                                                '' AS PartitionColumn,
                                                '' AS LastAccessed,
                                                '' AS LastModified
                                            FROM tablesummary summ
                                            LEFT JOIN tablesize s
                                                ON s.tablename = summ.tablename 
                                            LEFT JOIN columncount cc
                                                ON summ.DatabaseName  = cc.DatabaseName 
                                                AND summ.SchemaName = cc.SchemaName 
                                                AND summ.TableName = cc.TableName;
    """)

    __template_select_probable_watermarks = Template("""
                                                        SELECT 
                                                            DATABASE AS DatabaseName,
                                                            SCHEMA AS SchemaName,
                                                            name AS TableName,
                                                            ATTNAME AS ProbableWatermarkColumns
                                                        FROM _V_RELATION_COLUMN c
                                                        WHERE atttypid IN (1082 , 1184)
                                                        AND TYPE = 'TABLE'
                                                        AND DATABASE = '$db'
    """)

    __template_get_primary_keys = Template("""
                                                SELECT
                                                    DATABASE AS DatabaseName,
                                                    SCHEMA AS SchemaName,
                                                    Relation AS TableName,
                                                    CONSTRAINTNAME,
                                                    ATTNAME AS PK,
                                                    conseq as seq
                                                FROM _v_relation_keydata
                                                WHERE CONTYPE = 'p';                                            
    """)

    __template_get_foreign_keys = Template("""
                                                SELECT
                                                    DATABASE AS DatabaseName,
                                                    SCHEMA AS SchemaName,
                                                    Relation AS TableName,
                                                    CONSTRAINTNAME,
                                                    ATTNAME AS FK,
                                                    conseq as seq
                                                FROM _v_relation_keydata
                                                WHERE CONTYPE = 'f';                                            
    """)

    __template_get_organized_by = Template("""
                                            SELECT
                                                TABLE_CAT as DatabaseName,
                                                TABLE_SCHEM as SchemaName,
                                                TABLE_NAME as TableName,
                                                COLUMN_NAME as OrganizedBy
                                            FROM _v_odbc_columns1 
                                            WHERE TABLE_CAT <> 'SYSTEM'
                                            AND ORGSEQNO IS NOT NULL
    """)

    __template_get_distributed_by = Template("""
                                            SELECT
                                                TABLE_CAT as DatabaseName,
                                                TABLE_SCHEM as SchemaName,
                                                TABLE_NAME as TableName,
                                                COLUMN_NAME as DistributedBy
                                            FROM _v_odbc_columns1 
                                            WHERE TABLE_CAT <> 'SYSTEM'
                                            AND DISTSEQNO IS NOT NULL
    """)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def obtain_catalog(self) -> pd.DataFrame:
        try:
            df_table_catalog = pd.DataFrame()
            df_table_summary = pd.DataFrame()
            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})

            netezza_database = dao.get_conn_profile_key("database") if dao.get_conn_profile_key("database") is not None \
                else dao.get_conn_profile_key("service_name")

            if netezza_database == None:
                netezza_database = ""

            databases = self._fetch_all(dao, NetezzaCrawler.__template_get_all_databases.substitute(db=netezza_database))
            databaselist = [x for x in databases['NAME']]
            for database in databaselist:
                dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})
                
                df_table_details: pd.DataFrame = self._fetch_all(dao, query_string=NetezzaCrawler.__template_select_all_tables.substitute(db=database))
                df_table_catalog = pd.concat([df_table_catalog, df_table_details])

                df_table_summ: pd.DataFrame = self._fetch_all(dao, query_string=NetezzaCrawler.__template_select_summary.substitute(db=database))
                df_watermarks: pd.DataFrame = self._fetch_all(dao, query_string=NetezzaCrawler.__template_select_probable_watermarks.substitute(db=database))
                if not df_watermarks.empty:
                    df_watermarks_group = df_watermarks[["DATABASENAME", "SCHEMANAME", "TABLENAME", "PROBABLEWATERMARKCOLUMNS"]].groupby(["DATABASENAME", "SCHEMANAME", "TABLENAME"])
                    for name, group in df_watermarks_group:
                        key_list = ','.join(group["PROBABLEWATERMARKCOLUMNS"].to_list())
                        df_table_summ.loc[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2]), "PROBABLEWATERMARKCOLUMNS"] = key_list
                
                df_primary_keys: pd.DataFrame = self._fetch_all(dao, query_string=NetezzaCrawler.__template_get_primary_keys.substitute(db=database))
                if not df_primary_keys.empty:
                    df_primary_keys_group = df_primary_keys[["DATABASENAME", "SCHEMANAME", "TABLENAME", "CONSTRAINTNAME", "PK"]].groupby(["DATABASENAME", "SCHEMANAME", "TABLENAME", "CONSTRAINTNAME"])
                    for name, group in df_primary_keys_group:
                        key_list = ','.join(group["PK"].to_list())
                        df_table_summ.loc[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2]), "PRIMARYKEY"] = key_list
                    
                df_foreign_keys: pd.DataFrame = self._fetch_all(dao, query_string=NetezzaCrawler.__template_get_foreign_keys.substitute(db=database))
                if not df_foreign_keys.empty:
                    df_foreign_keys_group = df_foreign_keys[["DATABASENAME", "SCHEMANAME", "TABLENAME", "CONSTRAINTNAME", "FK"]].groupby(["DATABASENAME", "SCHEMANAME", "TABLENAME", "CONSTRAINTNAME"])
                    for name, group in df_foreign_keys_group:
                        key_list = name[3] + " - " + ','.join(group["FK"].to_list())
                        df_table_summ.loc[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2]), "FOREIGNKEY"] = \
                            df_table_summ[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2])]["FOREIGNKEY"] + " # " + key_list
                
                df_organized_by: pd.DataFrame = self._fetch_all(dao, query_string=NetezzaCrawler.__template_get_organized_by.substitute(db=database))
                if not df_organized_by.empty:
                    df_organized_by_group = df_organized_by[["DATABASENAME", "SCHEMANAME", "TABLENAME", "ORGANIZEDBY"]].groupby(["DATABASENAME", "SCHEMANAME", "TABLENAME"])
                    for name, group in df_organized_by_group:
                        key_list =  "Organized by - " + ','.join(group["ORGANIZEDBY"].to_list())
                        df_table_summ.loc[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2]), "PARTITIONCOLUMN"] = \
                            df_table_summ[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2])]["PARTITIONCOLUMN"] + " # " + key_list
                    
                df_distributed_by: pd.DataFrame = self._fetch_all(dao, query_string=NetezzaCrawler.__template_get_distributed_by.substitute(db=database))
                if not df_distributed_by.empty:
                    df_distributed_by_group = df_distributed_by[["DATABASENAME", "SCHEMANAME", "TABLENAME", "DISTRIBUTEDBY"]].groupby(["DATABASENAME", "SCHEMANAME", "TABLENAME"])
                    for name, group in df_distributed_by_group:
                        key_list = "Distributed by - " + ','.join(group["DISTRIBUTEDBY"].to_list())
                        df_table_summ.loc[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2]), "PARTITIONCOLUMN"] = \
                            df_table_summ[(df_table_summ["DATABASENAME"] == name[0]) & (df_table_summ["SCHEMANAME"] == name[1]) & (df_table_summ["TABLENAME"] == name[2])]["PARTITIONCOLUMN"] + " # " + key_list                    

                df_table_summary = pd.concat([df_table_summary, df_table_summ])

            # for db in df_databases['DATABASE'].to_list():
            #     df_table_catalog.extend(self._fetch_all_list(dao,
            #                                                  query_string=NetezzaCrawler.__template_select_all_tables
            #                                                  .substitute(db_name=db)))

            return [df_table_catalog, df_table_summary]
        except:
            raise    