#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
"""
#TODO: Module description
"""

from string import Template

import pandas as pd
from providah.factories.package_factory import PackageFactory as providah_pkg_factory

from hdc.core.catalog.rdbms_crawler import RdbmsCrawler
from hdc.core.dao.rdbms_dao import RdbmsDAO


class TeradataCrawler(RdbmsCrawler): 
    #Change for Teradata
    __template_select_all_tables = Template("""
                                                with sesscoll as (
                                                    select top 1
                                                            case
                                                                    when CurrentCollation = 'A' then 'ASCII'
                                                                    when CurrentCollation = 'E' then 'EBCDIC'
                                                                    when CurrentCollation = 'H' then 'Host'
                                                                    when CurrentCollation = 'M' then 'MultiNational'
                                                                    when CurrentCollation = 'C' then 'CharSet_Coll'
                                                                    when CurrentCollation = 'J' then 'JIS_Coll'
                                                            end as COLLATION_NAME
                                                    from dbc.SessionInfo 
                                                    where upper(username) = upper('$userid')
                                                    order by SessionNo desc
                                                )
                                                SELECT DISTINCT
                                                    T.DatabaseName as DATABASE_NAME,
                                                    T.DatabaseName as SCHEMA_NAME,
                                                    T.TableName as TABLE_NAME,             
                                                    C.ColumnName as COLUMN_NAME,
                                                    case
                                                        WHEN ColumnType = 'I1' THEN 'BYTEINT'
                                                        WHEN ColumnType = 'I2' THEN 'SMALLINT'
                                                        WHEN ColumnType = 'I8' THEN 'BIGINT'
                                                        WHEN ColumnType = 'I' THEN 'INTEGER'
                                                        WHEN ColumnType = 'D' THEN 'DECIMAL'
                                                        WHEN ColumnType = 'F' THEN 'FLOAT'
                                                        WHEN ColumnType = 'N' THEN 'NUMBER'
                                                        WHEN ColumnType = 'CF' THEN 'CHAR'
                                                        WHEN ColumnType = 'CV' THEN 'VARCHAR'
                                                        WHEN ColumnType = 'DA' THEN 'DATE'                                                        
                                                        WHEN ColumnType = 'AT' THEN 'TIME' 
                                                        WHEN ColumnType = 'TZ' THEN 'TIME WITH TIMEZONE'
                                                        WHEN ColumnType = 'TS' THEN 'TIMESTAMP'
                                                        WHEN ColumnType = 'SZ' THEN 'TIMESTAMP WITH TIME ZONE'
                                                        WHEN ColumnType = 'PS' THEN 'PERIOD(TIMESTAMP)'
                                                        WHEN ColumnType = 'PD' THEN 'PERIOD(DATE)'
                                                        WHEN ColumnType = 'PM' THEN 'PERIOD(TIMESTAMP WITH TIME ZONE)'
                                                        WHEN ColumnType = 'PT' THEN 'PERIOD(TIME)'
                                                        WHEN ColumnType = 'PZ' THEN 'PERIOD(TIME WITH TIME ZONE)'
                                                        WHEN ColumnType = 'BO' THEN 'BLOB'
                                                        WHEN ColumnType = 'CO' THEN 'CLOB'
                                                        WHEN ColumnType = 'BF' THEN 'BYTE'
                                                        WHEN ColumnType = 'BV' THEN 'VARBYTE'
                                                        WHEN ColumnType in ('A1','AN') THEN 'ARRAY'
                                                        WHEN ColumnType = 'JN' THEN 'JSON'
                                                        WHEN ColumnType = 'XM' THEN 'XML'
                                                        WHEN ColumnType = 'DY' THEN 'INTERVAL DAY'
                                                        WHEN ColumnType = 'DH' THEN 'INTERVAL DAY TO HOUR'
                                                        WHEN ColumnType = 'DM' THEN 'INTERVAL DAY TO MINUTE'
                                                        WHEN ColumnType = 'DS' THEN 'INTERVAL DAY TO SECOND'
                                                        WHEN ColumnType = 'YR' THEN 'INTERVAL YEAR'
                                                        WHEN ColumnType = 'YM' THEN 'INTERVAL YEAR TO MONTH'
                                                        WHEN ColumnType = 'SC' THEN 'INTERVAL SECOND'
                                                        WHEN ColumnType = 'MI' THEN 'INTERVAL MINUTE'
                                                        WHEN ColumnType = 'MS' THEN 'INTERVAL MINUTE TO SECOND'
                                                        WHEN ColumnType = 'MO' THEN 'INTERVAL MONTH'                                                        
                                                        WHEN ColumnType = 'HR' THEN 'INTERVAL HOUR'
                                                        WHEN ColumnType = 'HM' THEN 'INTERVAL HOUR TO MINUTE'
                                                        WHEN ColumnType = 'HS' THEN 'INTERVAL HOUR TO SECOND'
                                                    end as COLUMN_TYPE,
                                                    case
                                                        WHEN ColumnType = 'D' THEN '(' || TO_CHAR(C.DecimalTotalDigits) || ',' || TO_CHAR(C.DecimalFractionalDigits) || ')'
                                                        WHEN ColumnType = 'N' and C.DecimalTotalDigits = -128 THEN '(38,18)'
                                                        WHEN ColumnType = 'N' and C.DecimalTotalDigits <> -128 THEN '(' || TO_CHAR(C.DecimalTotalDigits) || ',' || TO_CHAR(C.DecimalFractionalDigits) || ')'
                                                        WHEN ColumnType = 'CF' THEN '(' || TO_CHAR(C.ColumnLength) || ')'
                                                        WHEN ColumnType = 'CV' THEN '(' || TO_CHAR(C.ColumnLength) || ')'
                                                        WHEN ColumnType = 'AT' and DecimalFractionalDigits is not null THEN '(' || TO_CHAR(C.DecimalFractionalDigits) || ')'
                                                        WHEN ColumnType = 'TS' and DecimalFractionalDigits is not null THEN '(' || TO_CHAR(C.DecimalFractionalDigits) || ')'
                                                        WHEN ColumnType = 'SZ' and DecimalFractionalDigits is not null THEN '(' || TO_CHAR(C.DecimalFractionalDigits) || ')'
                                                        WHEN ColumnType = 'PS' THEN '(' || TO_CHAR(((C.ColumnLength + C.DecimalFractionalDigits)*2)+8) || ')'
                                                        WHEN ColumnType = 'BF' THEN '(' || TO_CHAR(C.ColumnLength) || ')'
                                                        WHEN ColumnType = 'BV' THEN '(' || TO_CHAR(C.ColumnLength) || ')'
                                                        WHEN ColumnType = 'TZ' THEN '(' || TO_CHAR(C.DecimalFractionalDigits) || ')'                                                                                                                
                                                        WHEN ColumnType = 'DH' THEN '(' || TO_CHAR(C.DecimalTotalDigits + 6) || ')'
                                                        WHEN ColumnType = 'DM' THEN '(' || TO_CHAR(C.DecimalTotalDigits + 9) || ')'
                                                        WHEN ColumnType = 'DS' and C.DecimalFractionalDigits is null THEN '(' || TO_CHAR(C.DecimalTotalDigits + 12) || ')'
                                                        WHEN ColumnType = 'DS' and C.DecimalFractionalDigits is not null THEN '(' || TO_CHAR(C.DecimalTotalDigits + 13 + C.DecimalFractionalDigits) || ')'
                                                        WHEN ColumnType = 'YM' THEN '(' || TO_CHAR(C.DecimalTotalDigits + 6) || ')'                                                                                    
                                                        WHEN ColumnType = 'MS' and C.DecimalFractionalDigits is null THEN '(' || TO_CHAR(C.DecimalTotalDigits + 6) || ')'
                                                        WHEN ColumnType = 'MS' and C.DecimalFractionalDigits is not null THEN '(' || TO_CHAR(C.DecimalTotalDigits + 7 + C.DecimalFractionalDigits) || ')'                                                                                               
                                                        WHEN ColumnType = 'HM' THEN '(' || TO_CHAR(C.DecimalTotalDigits + 6) || ')'                                                                                    
                                                        WHEN ColumnType = 'HS' and C.DecimalFractionalDigits is null THEN '(' || TO_CHAR(C.DecimalTotalDigits + 9) || ')'
                                                        WHEN ColumnType = 'HS' and C.DecimalFractionalDigits is not null THEN '(' || TO_CHAR(C.DecimalTotalDigits + 10 + C.DecimalFractionalDigits ) || ')'
                                                        ELSE ''
                                                    end as COLUMN_SIZE,
                                                    C.Nullable as NOT_NULL,
                                                    case 
                                                    when left(defaultvalue,1) = '''' and  right(defaultvalue,1)= '''' then '''' || trim(oreplace(defaultvalue,'''','')) || '''' 
                                                        else defaultvalue 
                                                    end  as DEFAULT_VALUE,
                                                    C.CommentString as COMMENT_STRING,
                                                    case
                                                            WHEN CharType = 1 THEN 'Latin'
                                                            WHEN CharType = 2 THEN 'Unicode'
                                                            WHEN CharType = 3 THEN 'KanjiSJIS'
                                                            WHEN CharType = 4 THEN 'Graphic'
                                                            WHEN CharType = 5 THEN 'Kanji1'
                                                            ELSE ''
                                                    end as CHARACTER_SET_NAME,
                                                    case 
                                                            WHEN ColumnType in ('CF', 'CV') THEN sc.COLLATION_NAME                                                                                 
                                                            else ''
                                                    end as COLLATION_NAME
                                                FROM  DBC.ColumnsV C
                                                INNER JOIN DBC.TablesV T
                                                    ON C.TableName = T.TableName
                                                    AND C.DatabaseName = T.DatabaseName
                                                    AND T.TableKind in ('T','O')
                                                CROSS JOIN sesscoll sc
                                                where T.DatabaseName = '$db'                                                                                                                                      
                                                order by 1,3,C.ColumnId;

    """)

    # __template_select_all_views = Template("""
    #                                             select
    #                                                 'NEXGEN_TD_MIGR' as DATABASE_NAME,
    #                                                 DatabaseName as SCHEMA_NAME,
    #                                                 TableName as TABLE_NAME, 
    #                                                 NULL as COLUMN_NAME,
    #                                                 NULL as COLUMN_TYPE,
    #                                                 NULL as COLUMN_SIZE,
    #                                                 NULL as NOT_NULL,
    #                                                 NULL as DEFAULT_VALUE,
    #                                                 NULL as COMMENT_STRING,
    #                                                 RequestText as ViewDefinition,
    #                                                 TRIM(TableKind) as ObjectType
    #                                             from DBC.TablesV 
    #                                             where TableKind = 'V' 
    #                                             and DatabaseName = '$db';
    # """)

    # __template_select_primary_keys = Template("""
    #                                                 select 
    #                                                     'NEXGEN_TD_MIGR' as DATABASE_NAME,
    #                                                     DatabaseName as SCHEMA_NAME,
    #                                                     TableName as TABLE_NAME,                 
    #                                                     TRIM(TRAILING ',' FROM (XMLAGG(TRIM(Columnname)|| ',' ORDER BY ColumnPosition) (VARCHAR(10000)))) as COLUMN_NAME,
    #                                                     NULL as COLUMN_TYPE,
    #                                                     NULL as COLUMN_SIZE,
    #                                                     NULL as NOT_NULL,
    #                                                     NULL as DEFAULT_VALUE,
    #                                                     NULL as COMMENT_STRING,
    #                                                     NULL as ViewDefinition,
    #                                                     TRIM(IndexType) as ObjectType
    #                                                 from DBC.IndicesV
    #                                                 where IndexType = 'K'
    #                                                 and DatabaseName = '$db'
    #                                                 group by 1,2,3,5,6,7,8,9,10,11
    # """)

    __template_select_summary = Template("""
                                                with tablesummary as (
                                                    select 
                                                            T.DatabaseName,
                                                            T.DatabaseName as SchemaName,
                                                            T.TableName,
                                                            T.TableKind as TableType,
                                                            coalesce(T.CommentString,'') as Comments,
                                                            T.LastAlterTimestamp as LastModified,
                                                            T.LastAccessTimeStamp as LastAccessed
                                                    FROM  DBC.TablesV T
                                                    where T.TableKind in ('T','O')
                                                    and T.DatabaseName = '$db'                                                                                                                                      
                                                ),
                                                triggers as (
                                                    select 
                                                            T.DatabaseName,
                                                            T.TableName,
                                                            'Y' as TriggerPresent
                                                    FROM  DBC.triggers T
                                                    where T.EnabledFlag = 'Y'
                                                    and T.DatabaseName = '$db'
                                                ),
                                                foreignkeys as (
                                                    select 
                                                            DatabaseName,
                                                            TableName, 
                                                            TRIM(TRAILING '#' FROM (XMLAGG(TRIM(IndexName || ' - ' || ForeignKey)|| '#' ) (VARCHAR(10000)))) as ForeignKey 
                                                    from (
                                                                        select 
                                                                                ChildDB as DatabaseName,
                                                                                ChildTable as TableName,         
                                                                                IndexName,
                                                                                TRIM(TRAILING ',' FROM (XMLAGG(TRIM(ChildKeyColumn)|| ',' ) (VARCHAR(10000)))) as ForeignKey
                                                                        from DBC.All_RI_ChildrenV
                                                                        where ChildDb = '$db'
                                                                        group by 1,2,3
                                                            ) as t
                                                    group by 1,2
                                                ),
                                                columncounts as (
                                                    select 
                                                            DatabaseName,
                                                            TableName,
                                                            count(*) as ColumnCount
                                                    from DBC.ColumnsV
                                                    where DatabaseName = '$db'
                                                    group by 1,2
                                                ),
                                                sizes as (
                                                    SELECT 
                                                            DatabaseName,
                                                            TableName, 
                                                            CAST(SUM(CurrentPerm) AS DECIMAL(18,5))/(1024*1024) AS TableSizeInMb
                                                    FROM dbc.tablesize 
                                                    WHERE databasename = '$db' 
                                                    group by 1,2
                                                ),
                                                probablewatermarks as (
                                                    select 
                                                            DatabaseName,
                                                            TableName,
                                                            TRIM(TRAILING ',' FROM (XMLAGG(TRIM(ColumnName)|| ',' ) (VARCHAR(10000)))) as ProbableWatermark
                                                    from DBC.ColumnsV
                                                    where DatabaseName = '$db'
                                                    and ColumnType in ('DA','TS','SZ')
                                                    group by 1,2
                                                ),
                                                indexessuperset as (
                                                    select 
                                                            DatabaseName,
                                                            TableName,
                                                            IndexName,
                                                            case
                                                                    when IndexType = 'P' then 'Non Partitioned Primary Index'
                                                                    when IndexType = 'Q' then 'Partitioned Primary Index'
                                                                    when IndexType = 'A' then 'Primary Amp Index'
                                                                    when IndexType = 'S' then 'Secondary Index'
                                                                    when IndexType = 'J' then 'Join Index'
                                                                    when IndexType = 'N' then 'Hash Index'
                                                                    when IndexType = 'K' then 'Primary Key'
                                                                    when IndexType = 'U' then 'Unique Constraint'
                                                                    when IndexType = 'V' then 'Value Ordered Secondary Index'
                                                                    when IndexType = 'H' then 'Hash-ordered ALL covering secondary index'
                                                                    when IndexType = 'O' then 'Valued-ordered ALL covering secondary index'
                                                                    when IndexType = 'G' then 'Geospatial nonunique secondary index'
                                                            end as IndexDesc,
                                                            IndexType,
                                                            TRIM(TRAILING ',' FROM (XMLAGG(TRIM(Columnname)|| ',' ORDER BY ColumnPosition) (VARCHAR(10000)))) as IndexColumn
                                                    from dbc.indicesv
                                                    where DatabaseName = '$db'
                                                    group by 1,2,3,4,5
                                                ),
                                                primarykeys as (
                                                    select 
                                                            DatabaseName,
                                                            TableName,
                                                            IndexColumn as PrimaryKey
                                                    from indexessuperset
                                                    where DatabaseName = '$db'
                                                    and IndexType = 'K'
                                                ),
                                                otherindexes as (
                                                    select 
                                                            DatabaseName,
                                                            TableName,
                                                            TRIM(TRAILING '#' FROM (XMLAGG(TRIM(IndexName || ' - ' || IndexDesc || '-' || IndexColumn)|| ' #' ) (VARCHAR(10000)))) as IndexColumns
                                                    from indexessuperset
                                                    where IndexType <> 'K'
                                                    and DatabaseName = '$db'
                                                    group by 1,2
                                                ),
                                                partitionvalues as (
                                                    select 
                                                            DatabaseName, 
                                                            TableName, 
                                                            TRIM(TRAILING ',' FROM (XMLAGG(TRIM(ColumnName)|| ',' order by ColumnPartitionNumber) (VARCHAR(10000))))  as PartitionColumn
                                                    from dbc.columnsv 
                                                    where partitioningcolumn <> 'N'
                                                    and DatabaseName = '$db'
                                                    group by 1,2
                                                ),
                                                lastaccessed as (
                                                    select
                                                            DatabaseName, 
                                                            TableName,
                                                            max(LastAccessTimeStamp) as LastAccessed
                                                    from dbc.columnsv 
                                                    where DatabaseName = '$db'
                                                    group by 1,2
                                                )

                                                select 
                                                    summ.DatabaseName as DatabaseName,
                                                    summ.SchemaName,
                                                    summ.TableName,
                                                    summ.TableType,
                                                    coalesce(pk.PrimaryKey,'') as PrimaryKey,
                                                    coalesce(f.ForeignKey,'') as ForeignKey,
                                                    oi.IndexColumns,
                                                    0 as RowCounts,
                                                    c.ColumnCount,
                                                    ts.TableSizeInMb,
                                                    summ.Comments,
                                                    coalesce(pw.ProbableWatermark,'') as ProbableWatermarkColumns,
                                                    coalesce(tr.TriggerPresent, 'N') as TriggerPresent,
                                                    pv.PartitionColumn,
                                                    summ.LastModified,
                                                    coalesce(summ.LastAccessed,la.LastAccessed) as LastAccessed
                                                from tablesummary summ
                                                left join triggers tr
                                                    on tr.DatabaseName = summ.DatabaseName
                                                    and tr.TableName = summ.TableName
                                                left join foreignkeys f
                                                    on f.DatabaseName = summ.DatabaseName
                                                    and f.TableName = summ.TableName
                                                left join columncounts c
                                                    on c.DatabaseName = summ.DatabaseName
                                                    and c.TableName = summ.TableName
                                                left join sizes ts
                                                    on ts.DatabaseName = summ.DatabaseName
                                                    and ts.TableName = summ.TableName
                                                left join probablewatermarks pw
                                                    on pw.DatabaseName = summ.DatabaseName
                                                    and pw.TableName = summ.TableName
                                                left join primarykeys pk
                                                    on pk.DatabaseName = summ.DatabaseName
                                                    and pk.TableName = summ.TableName
                                                left join otherindexes oi
                                                    on oi.DatabaseName = summ.DatabaseName
                                                    and oi.TableName = summ.TableName
                                                left join partitionvalues pv
                                                    on pv.DatabaseName = summ.DatabaseName
                                                    and pv.TableName = summ.TableName
                                                left join lastaccessed la
                                                    on la.DatabaseName = summ.DatabaseName
                                                    and la.TableName = summ.TableName;

    """)

    __template_get_all_databases = Template("""
                                                select DatabaseName as name
                                                from dbc.databases
                                                where DatabaseName = COALESCE(NULLIF('$db',''),DatabaseName);
    """)
    

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()
    
    # def __get_view_definition(self, view_name, dao):
    #     df_view_definiton = self._fetch_all(dao, query_string=f"SHOW VIEW {view_name}")
    #     return df_view_definiton.iloc[0,0]

    def obtain_catalog(self) -> pd.DataFrame:
        try:
            df_table_catalog = pd.DataFrame()
            df_table_summary = pd.DataFrame()
            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})

            # Extract the table metadata/catalog from connected Teradata source
            teradata_database = dao.get_conn_profile_key("database") if dao.get_conn_profile_key("database") is not None \
                else dao.get_conn_profile_key("service_name")

            userid = dao.get_conn_profile_key("user")

            if teradata_database == None:
                teradata_database = ""

            databases: pd.DataFrame = self._fetch_all(dao, query_string=TeradataCrawler.__template_get_all_databases.substitute(db=teradata_database))
            
            databaselist = [x for x in databases['name']]
            for database in databaselist:
                dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})
                df_table_details: pd.DataFrame = self._fetch_all(dao,
                                                             query_string=TeradataCrawler.__template_select_all_tables.substitute(
                                                                 db=database, userid=userid
                                                             ))
                df_table_catalog = pd.concat([df_table_catalog, df_table_details])

                df_table_summ: pd.DataFrame = self._fetch_all(dao,
                                                             query_string=TeradataCrawler.__template_select_summary.substitute(
                                                                 db=database
                                                             ))
                df_table_summary = pd.concat([df_table_summary, df_table_summ])
                # df_table_catalog: pd.DataFrame = self._fetch_all(dao, 
                #                                                 query_string=TeradataCrawler.__template_select_all_tables.substitute(
                #                                                 db = teradata_database
                #                                                 ))
            
            # df_view_catalog: pd.DataFrame = self._fetch_all(dao, 
            #                                                 query_string=TeradataCrawler.__template_select_all_views.substitute(
            #                                                 db = teradata_database
            #                                                 ))
            # for i in range(0, df_view_catalog.shape[0]):
            #     if df_view_catalog.iloc[i, 7][-1] != ';':
            #         df_view_catalog.iloc[i, 7] = self.__get_view_definition(f"{df_view_catalog.iloc[i,1]}.{df_view_catalog.iloc[i,2]}", dao)    
            
            # df_primarykeys_catalog = self._fetch_all(dao, 
            #                                                  query_string=TeradataCrawler.__template_select_primary_keys.substitute(
            #                                                  db = teradata_database
            #                                                  ))       
                
            # df = pd.concat([df_table_catalog, df_view_catalog, df_primarykeys_catalog])
            #df = df_table_catalog
            #return df
            return [df_table_catalog, df_table_summary]

        except Exception as e:
            raise e

        return None

        
