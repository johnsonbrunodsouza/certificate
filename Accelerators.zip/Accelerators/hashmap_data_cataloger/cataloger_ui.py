#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import streamlit as st
import ast
import _ast
import os
import glob
import platform
import yaml
import datetime 
import shutil
import subprocess
import logging.config
import warnings
from argparse import ArgumentParser, ArgumentTypeError
import sys
sys.path[0] = r'C:\NTTDATA\Accelerators\hashmap_data_cataloger'
from providah.factories.package_factory import PackageFactory as providah_pkg_factory
from hdc.core.asset_mapper import AssetMapper
from hdc.core.cataloger import Cataloger
from hdc.core.exceptions.hdc_error import HdcError
from hdc.utils import file_utils
import altair as alt

conn_params = {
    "BigQuery": {"params": [{"param_name": "client_service_json", "widget_name": "Client Service JSON Path", "widget_type": "text_input", "disabled": False, "default": ""}]},
    "Hdfs": {"params": [
                        {"param_name": "dir", "widget_name": "Directory", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "user", "widget_name": "User", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "file_format", "widget_name": "File Format", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "partition_depth", "widget_name": "Partition Depth", "widget_type": "text_input", "disabled": False, "default": ""},
                       ]
            },
    "Hive": {"params": [
                        {"param_name": "protocol", "widget_name": "Protocol", "widget_type": "text_input", "disabled": True, "default": "jdbc"},
                        {"param_name": "user", "widget_name": "User", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "password", "widget_name": "Password", "widget_type": "password", "disabled": False, "default": ""},
                        {"param_name": "connectionurl", "widget_name": "Connection URL", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "database", "widget_name": "Database", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "drivername", "widget_name": "Driver Name", "widget_type": "text_input", "disabled": True, "default": "com.mysql.jdbc.Driver"},
                        {"param_name": "driverpath", "widget_name": "Driver Path", "widget_type": "text_input", "disabled": False, "default": ""}
                       ]
            },
    "Netezza": {"params": [
                            {"param_name": "protocol", "widget_name": "Protocol", "widget_type": "selectbox", "disabled": False, "options": ['jdbc','odbc'], "default": 0},
                            {"param_name": "drivername", "widget_name": "Driver Name", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "driverpath", "widget_name": "Driver Path", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "user", "widget_name": "User", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "password", "widget_name": "Password", "widget_type": "password", "disabled": False, "default": ""},
                            {"param_name": "host", "widget_name": "Host", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "port", "widget_name": "Port", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "database", "widget_name": "Database", "widget_type": "text_input", "disabled": False, "default": ""}
                          ]

               },
    "Oracle": {"params": [
                            {"param_name": "protocol", "widget_name": "Protocol", "widget_type": "selectbox", "disabled": False, "options": ['cx_oracle','jdbc','odbc'], "default": 0},
                            {"param_name": "drivername", "widget_name": "Driver Name", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "driverpath", "widget_name": "Driver Path", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "user", "widget_name": "User", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "password", "widget_name": "Password", "widget_type": "password", "disabled": False, "default": ""},
                            {"param_name": "host", "widget_name": "Host", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "port", "widget_name": "Port", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "database", "widget_name": "Database", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "schema", "widget_name": "Schema", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "sid", "widget_name": "Sid", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "client_library_dir", "widget_name": "Client Library Directory", "widget_type": "text_input", "disabled": False, "default": ""},
                          ]

               },
    "SQL": {"params": [                        
                        {"param_name": "drivername", "widget_name": "Driver Name", "widget_type": "text_input", "disabled": True, "default": "SQL Server"},                        
                        {"param_name": "user", "widget_name": "User", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "password", "widget_name": "Password", "widget_type": "password", "disabled": False, "default": ""},
                        {"param_name": "host", "widget_name": "Host", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "port", "widget_name": "Port", "widget_type": "text_input", "disabled": False, "default": ""},
                        {"param_name": "database", "widget_name": "Database", "widget_type": "text_input", "disabled": False, "default": ""}
                      ]

               },
    "Teradata": {"params": [                                                    
                            {"param_name": "user", "widget_name": "User", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "password", "widget_name": "Password", "widget_type": "password", "disabled": False, "default": ""},
                            {"param_name": "host", "widget_name": "Host", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "port", "widget_name": "Port", "widget_type": "text_input", "disabled": False, "default": ""},
                            {"param_name": "database", "widget_name": "Database", "widget_type": "text_input", "disabled": False, "default": ""}
                           ]

               },
    "Snowflake": {"params": [                                                    
                             {"param_name": "account", "widget_name": "Account", "widget_type": "text_input", "disabled": False, "default": ""},
                             {"param_name": "role", "widget_name": "Role", "widget_type": "text_input", "disabled": False, "default": ""},
                             {"param_name": "warehouse", "widget_name": "Warehouse", "widget_type": "text_input", "disabled": False, "default": ""},                             
                             {"param_name": "database", "widget_name": "Database", "widget_type": "text_input", "disabled": False, "default": ""},
                             {"param_name": "user", "widget_name": "User", "widget_type": "text_input", "disabled": False, "default": ""},
                             {"param_name": "password", "widget_name": "Password", "widget_type": "password", "disabled": False, "default": ""},
                             {"param_name": "schema", "widget_name": "Schema", "widget_type": "text_input", "disabled": False, "default": ""}
                           ] 

               },
    "Databricks": {"params": [{"param_name": "comingup", "widget_name": "On the roadmap. Stay tuned!", "widget_type": "text"}]}
}

def create_widgets(connection_key):
    connection_profile = {}
    for widget in conn_params[connection_key]['params']:
        if widget['widget_type'] == "text_input":
            if 'driver' not in widget['param_name']:
                connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=widget['disabled'], key=f"{connection_key}_{widget['widget_name']}"))
            else:
                if 'driver' not in connection_profile:
                    connection_profile['driver'] = {}
                connection_profile['driver'][widget['param_name'].replace('driver','')] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=widget['disabled'], key=f"{connection_key}_{widget['widget_name']}"))
        elif widget['widget_type'] == "password":
            connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=widget['disabled'], key=f"{connection_key}_{widget['widget_name']}", type="password"))
        elif widget['widget_type'] == "selectbox":
            connection_profile[widget['param_name']] = str(st.selectbox(label=widget['widget_name'], options=widget['options'], disabled=widget['disabled'], index=widget['default'], key=f"{connection_key}_{widget['widget_name']}"))
        elif widget['widget_type'] == "text":
            connection_profile[widget['param_name']] = str(st.text(body=widget['widget_name']))
    return connection_profile

def inspect_module(module_path, replace_text):
    returnlist = []
    for file in glob.glob(os.path.join(module_path,"[a-z]*.py")):
        with open(file) as mf:
            tree = ast.parse(mf.read())
        module_classes = [c.name.replace(replace_text,'') for c in [_ for _ in tree.body if isinstance(_, _ast.ClassDef)]]  
        returnlist.append(module_classes[0])
    
    if '' in returnlist:
        returnlist.pop(returnlist.index(''))
    if 'Rdbms' in returnlist:
        returnlist.pop(returnlist.index('Rdbms'))    
    return returnlist

def user_home_directory():
    userhome = ""
    if platform.system().lower() != 'windows':
        userhome = os.getenv('HOME')
    else:
        userhome = os.getenv('USERPROFILE')
    return userhome

def check_for_empty_params(config):
    missingconfigs = []
    for key in config.keys():
        if config[key] == "" and key != 'database':
            missingconfigs.append(f"Missing config for {key}.")
    return missingconfigs

def start_here(app_configuration, source, destination, log_settings, run):
    try:
        app_config: dict = file_utils.get_app_config(app_configuration)

        if log_settings is not None:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=log_settings))
        else:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=file_utils.get_default_log_config_path()))

        if app_config is not None:
            if run.lower() == 'map':
                try:
                    asset_mapper: AssetMapper = providah_pkg_factory.create(key='AssetMapper',
                                                                            library='hdc',
                                                                            configuration={
                                                                                'source': source,
                                                                                'destination': destination,
                                                                                'app_config': app_configuration
                                                                            })

                    if asset_mapper.map_assets():
                        print(
                            f"Successfully mapped the source '{source}' to destination '{destination}'")
                    return f"Successfully mapped the source '{source}' to destination '{destination}'"

                except HdcError as hde:
                    print(hde)

            elif run.lower() == 'catalog':
                try:
                    cataloger: Cataloger = providah_pkg_factory.create(key='Cataloger',
                                                                       library='hdc',
                                                                       configuration={
                                                                           'source': source,
                                                                           'app_config': app_configuration})
                    df_catalog = cataloger.obtain_catalog()

                    cataloger.pretty_print(df_catalog)
                    st.info("Generated Insights")
                    return df_catalog
                except HdcError as hde:
                     print(hde)
                    # raise HdcError(message=hde)
        else:
            raise HdcError(message=f"Could not find file {app_config}")

    except ArgumentTypeError as err:
        # hdc_parser.print_usage()
        raise HdcError(message=err)

    except RuntimeError as err:
        raise HdcError(message=err)

def generatechart(returnstatus, x, y, color, header):    
    if color:
        chart = alt.Chart(returnstatus).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(x=x, y=y, color=color)                
    else:
        chart = alt.Chart(returnstatus).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(x=x, y=y)
        
    st.subheader(header)
    st.altair_chart(chart, use_container_width=True, theme=None)


def generateslidechart(returnstatus):
    colcountsmalllow,colcountsmallhigh  = st.select_slider('Small',  options=range(0, 100, 10), value=(0,50))
    colcountmedlow,colcountmedhigh  = st.select_slider('Small',  options=range(100, 200, 10), value=(100,150))
    #colcountlargelow,colcountlargehigh  = st.select_slider('Small',  options=range(200, 1000, 100), value=(200,500))
    colcountsgrouping = alt.Chart(returnstatus[1]).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
                                                                                x='ColumnSize:N',                                                                                           
                                                                                y='count()'                                                                                                
                                                                            ).transform_calculate(
                                                                                "ColumnSize", alt.expr.if_(alt.datum.RowCounts <= colcountsmalllow, "Small", alt.expr.if_(alt.datum.RowCounts < colcountmedlow, "Medium", "Large"))
                                                                            )                            
    st.subheader("Distribution by Column Counts")                                                                                           
    st.altair_chart(colcountsgrouping, use_container_width=True, theme=None)


def generateresultsfordatatab(returnstatus):
    with dataanalyzer:
        with st.expander("Table Summary", expanded=True):
            st.dataframe(data=returnstatus[1], use_container_width=True)
        with st.expander("Table Details", expanded=True):
            st.dataframe(data=returnstatus[0], use_container_width=True)
    # st.dataframe(returnstatus[1].style.format({'TableSizeInMb': '{:.2f}'})

def generatechartforrowcount(returnstatus):
    rowcountsgrouping = alt.Chart(returnstatus[1]).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
                                                                                                x='RowCount:O',                                                                                           
                                                                                                y='count()'                                                                                                
                                                                                           ).transform_calculate(
                                                                                                "RowCount", alt.expr.if_(alt.datum.RowCounts <= 50000, "Small", alt.expr.if_(alt.datum.RowCounts < 100000, "Medium", "Large"))
                                                                                           )                            
    st.subheader("Distribution by Row Counts")                                                                                           
    st.altair_chart(rowcountsgrouping, use_container_width=True, theme=None)

def generatechartfortablesize(returnstatus):
    tablesize = alt.Chart(returnstatus[1]).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
                                                                                                x='TableSize:O',                                                                                           
                                                                                                y='count()'                                                                                                
                                                                                            ).transform_calculate(
                                                                                                "TableSize", alt.expr.if_(alt.datum.TableSizeInMb <= 10.0, "Small", "Large")
                                                                                            )                            
    st.subheader("Distribution by table size")                                                                                           
    st.altair_chart(tablesize, use_container_width=True, theme=None)

def generatechartforcolumncount(returnstatus):
    # colcountsmalllow,colcountsmallhigh  = st.select_slider('Small',  options=range(0, 100, 10), value=(0,50))
    # colcountmedlow,colcountmedhigh  = st.select_slider('Small',  options=range(100, 200, 10), value=(colcountsmalllow,150))
    colcountsgrouping = alt.Chart(returnstatus[1]).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
                                                                                                x='ColumnSize:O',                                                                                           
                                                                                                y='count()'                                                                                                
                                                                                           ).transform_calculate(
                                                                                                "ColumnSize", alt.expr.if_(alt.datum.RowCounts <= 100, "Small", alt.expr.if_(alt.datum.RowCounts <= 200, "Medium", "Large"))
                                                                                           )                            
    st.subheader("Distribution by Column Counts")                                                                                           
    st.altair_chart(colcountsgrouping, use_container_width=True, theme=None)

def generatechartfornopkorwatermark(returnstatus):
    nopkorwatermarks = alt.Chart(returnstatus[1]).mark_bar(cornerRadiusTopLeft=3, 
                                                           cornerRadiusTopRight=3).encode(
                                                                                                x='DatabaseName',
                                                                                                y='count()',
                                                                                                color='SchemaName'
                                                                                        ).transform_filter(                                                                                          
                                                                                                            {"and": [alt.FieldEqualPredicate(field='ProabableWatermarkColumns', equal=""), alt.FieldEqualPredicate(field='PrimaryKey', equal="")]}                                                                                                            
                                                                                                        )  
    st.subheader("Count of tables without PK or watermarks")
    st.altair_chart(nopkorwatermarks, use_container_width=True, theme=None)

def generateresultsforanalysistab(returnstatus):
    with analysis:
        with st.expander("Table Summary", expanded=True):
            col1, col2 = st.columns(2)     
            with col1:  
                generatechart(returnstatus[1], 'DatabaseName', 'count()', 'SchemaName', "Count of tables by DB & Schemas")
                generatechartforrowcount(returnstatus)                    
                generatechart(returnstatus[1], 'year(LastModified)', 'count()', '', "Count of tables by last DDL")
                
            with col2:
                generatechartfortablesize(returnstatus)                    
                generatechartforcolumncount(returnstatus)                    
            
            col5, col6, col7 = st.columns(3)    
            with col5:
                st.metric("Triggers", returnstatus[1].loc[(returnstatus[1].TriggerPresent == "Y")].shape[0])
            with col6:
                st.metric("Partitions", returnstatus[1].loc[(returnstatus[1].PartitionColumn != "")].shape[0])
            with col7:
                st.metric("Indexes", returnstatus[1].loc[(returnstatus[1].IndexColumns != "")].shape[0])
        
        with st.expander("Table Details", expanded=True):
            col3, col4 = st.columns(2)
            with col3:
                generatechart(returnstatus[0], 'COLUMN_TYPE', 'count()', '', "Count of columns by DataType")
                generatechart(returnstatus[0], 'CHARACTER_SET_NAME', 'count()', '', "Count of columns by Character Set")
            with col4:
                generatechartfornopkorwatermark(returnstatus)           
                generatechart(returnstatus[0], 'COLLATION_NAME', 'count()', '', "Count of columns by Collation")

def generateresults(returnstatus):
    if type(returnstatus) == list:
        returnstatus[0].fillna('', inplace=True)
        returnstatus[1].fillna('', inplace=True)
        generateresultsfordatatab(returnstatus)
        generateresultsforanalysistab(returnstatus)  
    else:
        st.text(returnstatus)

def initiate_cataloger(run_mode, source, target, recreate, source_connection, target_connection, placeholder):
    createconfig = True
    with placeholder.container():
        try:
            st.info("Validating inputs.")
            for missing_config in check_for_empty_params(source_connection):        
                st.error(missing_config)
                createconfig = False
            if target != "":
                for missing_config in check_for_empty_params(target_connection):        
                    st.error(missing_config)
                    createconfig = False
            if createconfig:
                st.info("Creating Configurations...")
                create_manifest(source, target, recreate)
                create_profile(source, target, source_connection, target_connection)
                st.info("Configurations created...")
                st.info("Initiating Process...")                
                
                app_config = os.path.join(user_home_directory(), ".hdc", "hdc.yml")                
                returnstatus = start_here(app_config, source.lower(), target.lower(), os.path.join(os.path.split(os.path.split(os.path.split(os.path.abspath(__file__))[0])[0])[0], "resources", "log_settings.yml"), run_mode)
                print(returnstatus[1]['TableSizeInMb'])
                # st.write(returnstatus[1])
                generateresults(returnstatus)
                
        except Exception as e:
            st.exception(str(e))

def create_profile(source, target, source_connection, target_connection):
    profile = {}
    hdc_dir = os.path.join(user_home_directory(), ".hdc")
    hdc_archive = os.path.join(user_home_directory(), ".hdc", "Archive")
    if not os.path.isdir(hdc_dir):
        os.makedirs(hdc_dir) 
    if not os.path.isdir(hdc_archive):
        os.makedirs(hdc_archive)

    profile[source.lower()] = source_connection
    if target != "":
        profile[target.lower()] = target_connection
    
    current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
    if os.path.exists(os.path.join(hdc_dir, 'profile.yml')):
        shutil.move(os.path.join(hdc_dir, 'profile.yml'), os.path.join(hdc_archive, f"profile_{current_timestamp}.yml"))
    
    with open(os.path.join(hdc_dir, 'profile.yml'), 'w') as outfile:
        yaml.dump(profile, outfile, default_flow_style=False)
    

def create_manifest(source, target, recreate):
    manifest = {}
    hdc_dir = os.path.join(user_home_directory(), ".hdc")
    hdc_archive = os.path.join(user_home_directory(), ".hdc", "Archive")
    if not os.path.isdir(hdc_dir):
        os.makedirs(hdc_dir) 
    if not os.path.isdir(hdc_archive):
        os.makedirs(hdc_archive) 


    manifest['sources'] = {}
    manifest['sources'][source.lower()] = {}
    manifest['sources'][source.lower()]['type'] = f"{source}Crawler"
    manifest['sources'][source.lower()]['conf'] = {}
    manifest['sources'][source.lower()]['conf']['type'] = source
    manifest['sources'][source.lower()]['conf']['profile'] = source.lower()
    
    if target != "":
        manifest['destinations'] = {}
        manifest['destinations'][target.lower()] = {}
        manifest['destinations'][target.lower()]['type'] = f"{target}Creator"
        manifest['destinations'][target.lower()]['conf'] = {}
        manifest['destinations'][target.lower()]['conf']['type'] = f"{target}DAO"
        manifest['destinations'][target.lower()]['conf']['profile'] = target.lower()

        manifest['mappers'] = {}
        manifest['mappers'][source.lower()] = {}
        manifest['mappers'][source.lower()][target.lower()] = {}
        manifest['mappers'][source.lower()][target.lower()]['type'] = f"{source}To{target}"
        manifest['mappers'][source.lower()][target.lower()]['conf'] = {}
        manifest['mappers'][source.lower()][target.lower()]['conf']['report'] = False
        manifest['mappers'][source.lower()][target.lower()]['conf']['recreate'] = recreate

    current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
    if os.path.exists(os.path.join(hdc_dir, 'hdc.yml')):
        shutil.move(os.path.join(hdc_dir, 'hdc.yml'), os.path.join(hdc_archive, f"hdc_{current_timestamp}.yml"))
    
    with open(os.path.join(hdc_dir, 'hdc.yml'), 'w') as outfile:
        yaml.dump(manifest, outfile, default_flow_style=False)

st. set_page_config(layout="wide")
st.title("NTT Data Cataloguer")

option = st.sidebar.selectbox("Cataloguer Options", ["Analyzer", "Schema Migrator"], index=0)


if option == "Analyzer":
    connectionanalyzer, dataanalyzer, analysis  = st.tabs(["🔗 Connections", "🗃 Data", "📈 Analysis"])
    with connectionanalyzer:
        with st.expander("Source", expanded=True):
            source = st.selectbox("Source System", inspect_module(os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0], 'core','catalog'), 'Crawler'), key="AnalyzerSourceSystem")
            source_connection = create_widgets(source)

        if st.button("Get Insights"):
            placeholder = st.empty()
            initiate_cataloger('catalog', source, target="", recreate="", source_connection=source_connection, target_connection="", placeholder=placeholder)        
else:
    with st.expander("Source", expanded=True):
        source = st.selectbox("Source System", inspect_module(os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0],'core', 'catalog'), 'Crawler'), key="MigratorSourceSystem")
        source_connection = create_widgets(source)

    with st.expander("Target"):
        target = st.selectbox("Target System", inspect_module(os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0], 'core', 'create'), 'Creator'), index=1, key="MigratorTargetSystem")
        target_connection = create_widgets(target)
        recreate = st.checkbox(label="Re-Create structures",key=f"RecreateStructures")

    if st.button("Migrate"):
        placeholder = st.empty()
        initiate_cataloger('map', source, target=target, recreate=recreate, source_connection=source_connection, target_connection=target_connection, placeholder=placeholder)

if __name__ == '__main__':
    # start_here(r'C:\Users\jbrun\.hdc\hdc.yml', 'oracle', '',
    #  r'C:\NTTDATA\ProjectConfigs\HDC\log_settings.yml', 
    #  'catalog')            
    a=100
    print(inspect_module(os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0], 'core','catalog'), 'Crawler'))
    print( os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0]))
            



