# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from contextlib import contextmanager

from hdv.dao.dao import DAO
from hdv.utils.parse_config import ParseConfig
from hdv.utils.project_config import ProjectConfig


class Fs_DAO(DAO):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._connection_name = kwargs.get('connection')
        if not self._validate_configuration(dict_of_keys=ParseConfig.parse(config_path=f"{ProjectConfig.hdv_home()}/{ProjectConfig.profile_path()}")[self._connection_name],
                                            required_keys=['dir']):
            raise ConnectionError(f'Missing Configuration key for {type(self).__name__}. Please check profile.yml file.'
                                  f'The list of required keys can be found in dao/{type(self).__name__}.py in _validate_configuration method.')

    def get_directory_listing(self):
        """returns a connection for the DB object being called"""
        profile_yaml = ParseConfig.parse(config_path=f"{ProjectConfig.hdv_home()}/{ProjectConfig.profile_path()}")
        conn_conf = profile_yaml[self._connection_name]

        dir_list = self._attempt_get_directory_list(conn_conf)

        return dir_list

    def _validate_configuration(self, dict_of_keys, required_keys) -> bool:
        return all([key in dict_of_keys.keys() for key in required_keys])

    def _attempt_get_directory_list(self, conn_conf):
        raise NotImplementedError(f'Method not implemented for {type(self).__name__}.')

