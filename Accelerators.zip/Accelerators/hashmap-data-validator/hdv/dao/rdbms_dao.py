# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import time
import traceback
from contextlib import contextmanager

from hdv.dao.dao import DAO
from hdv.utils.parse_config import ParseConfig
from hdv.utils.project_config import ProjectConfig
from hdv.vault.aws_secrets_manager import AWSSecretsManager
from hdv.vault.azure_key_vault import AzureKeyVault


class RdbmsDAO(DAO):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._max_attempts = 3
        self._timeout_seconds = 10
        self._connection_name = kwargs.get('connection')
        #if not self._validate_configuration(dict_of_keys=ParseConfig.parse(config_path=f"{ProjectConfig.hdv_home()}/{ProjectConfig.profile_path()}")[self._connection_name],
        #                                    required_keys=['user', 'password', 'host', 'port', 'database', 'driver']):
        #    raise ConnectionError(f'Missing Configuration key for {type(self).__name__}. Please check profile.yml file.'
        #                          f'The list of required keys can be found in dao/{type(self).__name__}.py in _validate_configuration method.')

    @property
    def connection(self):
        return self.get_connection()

    @contextmanager
    def get_connection(self):
        """returns a connection for the DB object being called"""
        # Check if connection is valid, and if it isn't, then attempt create it with exponential fall of up to 3 times.
        connection_established = False
        connection_attempts = 0
        timeout = self._timeout_seconds
        connection = None

        profile_yaml = ParseConfig.parse(config_path=f"{ProjectConfig.hdv_home()}/{ProjectConfig.profile_path()}")
        #conn_conf = profile_yaml[self._connection_name]
        conn_conf = self._get_connection_config(profile_yaml[self._connection_name])
        if not self._validate_configuration(dict_of_keys=conn_conf,
                                            required_keys=['user', 'password', 'host', 'port', 'database', 'driver']):
            raise ConnectionError(f'Missing Configuration key for {type(self).__name__}. Please check profile.yml file/vault.'
                                  f'The list of required keys can be found in dao/{type(self).__name__}.py in _validate_configuration method.')

        while connection_attempts < self._max_attempts:
            try:
                connection = self._attempt_to_connect(conn_conf)

                # Test if connection has been established and break
                if self._test_connection(connection):
                    connection_established = True
                    break

                # If not, re-attempt to connect after a brief sleep
                timeout, connection_attempts = self._sleep_and_increment_counter(timeout, connection_attempts)

            except Exception:
                connection_attempts, connection_established = self._manage_exception(timeout,
                                                                                     connection_attempts,
                                                                                     connection_established)

        if not connection_established:
            raise ConnectionError('Could not connect to the database; Exhausted connection attempts!')

        yield connection

        connection.close()

    def _get_connection_config(self, config):
        conn_conf = {}
        if config.get('secretname',''):
            if config.get('secretsplatform','').lower() == 'aws':
                secrets_obj = AWSSecretsManager(secretname=config.get('secretname',''))                
            elif config.get('secretsplatform','').lower() == 'azure':
                secrets_obj = AzureKeyVault(secretname=config.get('secretname',''))
            secret = secrets_obj.get_secret()
            for key in secret.keys():
                config[key] = secret[key]
            
        conn_conf = config
        return conn_conf


    def _test_connection(self, connection) -> bool:
        """
        Validate that the connection is valid to Snowflake instance

        Returns: True if connection is valid, False otherwise

        """
        if not connection:
            return False

        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            if not len(cursor.fetchone()) > 0:
                return False

            return True

    def _sleep_and_increment_counter(self, timeout, connection_attempt_count):
        connection_attempt_count += 1
        if connection_attempt_count < self._max_attempts:
            time.sleep(self._timeout_seconds)
            timeout *= self._timeout_seconds
        return timeout, connection_attempt_count

    def _manage_exception(self, timeout, connection_attempt_count, connection_established):
        if connection_attempt_count < self._max_attempts:
            error_message = f'Failed to connect to database; Caught exception: ' \
                            f'{traceback.format_exc()}' \
                            f'Re-attempting to connect ...'
            self._logger.error(error_message)
            connection_attempt_count = self._sleep_and_increment_counter(timeout, connection_attempt_count)
        else:
            connection_established = True
        return connection_attempt_count, connection_established

    def _validate_configuration(self, dict_of_keys, required_keys) -> bool:
        return all([key in dict_of_keys.keys() for key in required_keys])

    def _attempt_to_connect(self, conn_conf):
        raise NotImplementedError(f'Method not implemented for {type(self).__name__}.')
