# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from google.cloud import bigquery
from google.oauth2 import service_account
from hdv.dao.rdbms_dao import RdbmsDAO

class BigQueryDAO(RdbmsDAO):

    def _attempt_to_connect(self, connection_profile):
        return self.__biq_query_connector(connection_profile) 

    def _test_connection(self, connection) -> bool:
        result = False
        if connection:
            try:
                result = bool(connection.project)
            except Exception:
                return False

        return result
    
    def _validate_configuration(self, dict_of_keys, required_keys) -> bool:
        return super()._validate_configuration(dict_of_keys, ['service_json'])

    def __biq_query_connector(self, connection_profile):
        # base_keys_validation_output = RdbmsDAO._validate_connection_profile(connection_profile, ['service_json'])
        
        # if not base_keys_validation_output[0]:
        #     raise KeyError(
        #         f'One or more of {base_keys_validation_output[1]} keys not configured in profile')

        credentials = service_account.Credentials.from_service_account_file(connection_profile['service_json'])
        connection = bigquery.Client(credentials=credentials)
        # if not self._test_connection(connection):
        #     raise ConnectionError('Unable to connect to BigQuery. Please check configuration key values in profile.yml or try again.')
        return connection          
