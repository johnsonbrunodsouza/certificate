# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pyhive import hive

from hdv.dao.rdbms_dao import RdbmsDAO
from hdv.dao.jdbc_dao import JdbcConnector


class Hive(RdbmsDAO):

    def _attempt_to_connect(self, conn_conf):
        if 'database' in conn_conf and conn_conf['database'] != 'hive':
            return hive.connect(
                host=conn_conf['host'],
                port=conn_conf['port'],
                username=conn_conf['user']
            )
        else:
            return self._jdbc_connector(conn_conf)

    def _validate_configuration(self, dict_of_keys, required_keys) -> bool:
        return super()._validate_configuration(dict_of_keys, ['host', 'port', 'user'])
    
    def _jdbc_connector(self, conn_conf):
        # If all required properties are available, get a new connection to the Hive metastore MySQL database
        return JdbcConnector.connection({
            "jclassname": conn_conf['driver']['name'],
            "jars": conn_conf['driver']['path'],
            "url": f"jdbc:mysql://{conn_conf['host']}:{conn_conf['port']}/{conn_conf['database']}",
            "user": conn_conf['user'],
            "password": conn_conf['password']
        })