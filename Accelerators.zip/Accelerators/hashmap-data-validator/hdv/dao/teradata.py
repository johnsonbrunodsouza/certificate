# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from hdv.dao.rdbms_dao import RdbmsDAO
from hdv.utils.project_config import ProjectConfig
from sqlalchemy import create_engine, engine, exc
import teradatasql
from hdv.dao.odbc_dao import OdbcConnector

class Teradata(RdbmsDAO):

    def _attempt_to_connect(self, conn_conf):
        
        #return teradatasql.connect(host=conn_conf['host'], user=conn_conf['user'], password=conn_conf['password'])
        return OdbcConnector.connection({
            "driver": conn_conf['driver_name'],
            "connection_string": f"DRIVER={conn_conf['driver_name']};SERVER={conn_conf['host']};"
                                 f"PORT={conn_conf['port']};DATABASE={conn_conf['database']};"
                                 f"UID={conn_conf['user']};PWD={conn_conf['password']};"
        })

    def _validate_configuration(self, dict_of_keys, required_keys) -> bool:
        return super()._validate_configuration(dict_of_keys, ['host', 'port', 'user', 'password', 'database']
                                               )

    def _test_connection(self, connection) -> bool:
        """
        Validate that the connection is valid to Snowflake instance

        Returns: True if connection is valid, False otherwise

        """
        if not connection:
            return False

        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            if not len(cursor.fetchone()) > 0:
                return False

            return True
