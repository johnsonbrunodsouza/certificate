# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pandas as pd

from hdv.resources.rdbms_resource import RDBMSResource
from hdv.dao.hive import Hive
from hdv.query_templates.query_templates import QueryTemplate
from jinjasql import JinjaSql


class HiveResource(RDBMSResource):
    """Base class for Hive Object.
    This object holds the methods needed to connect to Snowflake and configure Snowflake credentials."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__connection_choice = kwargs['env']
        self.__connection_choice_hivemetastore = "hivemetastore"
        self.__table = kwargs['table_name']
        self.__chunk_size = kwargs['chunk_size']
        self.__offset = kwargs['offset']
        self.__orderby_clause = kwargs.get('orderby','')
        self.__hash = kwargs.get('hash','')

    def retrieve_dataframe(self) -> pd.DataFrame:
        """Reads data from a Hive table as a pandas dataframe."""
        try:
            if self.__hash:
                with Hive(connection=self.__connection_choice_hivemetastore).connection as conn:
                    hashquery = self._generate_query_for_hash()
                    df = pd.read_sql_query(sql=hashquery, con=conn)
                    query = df.iloc[0,0]
            else:
                query = f"select * from {self.__table}"

            with Hive(connection=self.__connection_choice).connection as conn:

                if self.__chunk_size and self.__offset:
                    df = pd.concat((self._generate_df(query, connection=conn)))

                else:
                    df = pd.read_sql_query(query, con=conn)

                #for col in df.columns:
                #    df = df.rename(columns={col: col.split(".", 1)[1]})

                return df
        except Exception as e:
            self._logger.error(e)

    def _generate_query_for_hash(self):
        query_template = QueryTemplate.get_hive_hash_query
        params = {
            'hash_function': self.__hash,            
            'table_name': self.__table.split('.')[1],
            'database_name': self.__table.split('.')[0]
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        return(query % bind_params)

    def _generate_df(self, query, connection):
        """grabs samples from the snowflake table and returns sample as a generator object"""

        # original offset value
        original = self.__offset

        # query the length of the Snowflake table
        check_df = pd.read_sql_query(
            sql=f"select count(*) from {self.__table}",
            con=connection)

        # check that the chunk_size and offset fit within the dataframe
        if int(check_df.iloc[0] / 2) <= self.__chunk_size + self.__offset:
            log_message = f"Please ensure the Snowflake table row count is at least 2x larger than the sum of the" \
                               f" given chunk_size and offset values. Or, enter smaller chunk_size and offset values."
            self._logger.error(log_message)
            return False

        while True:

            # generate a generator object of df batch
            p_df = pd.read_sql_query(
                sql=f"{query} ORDER BY {self.__orderby_clause} limit {self.__chunk_size} offset {self.__offset}",
                con=connection)

            # if empty, break
            if not len(p_df.index):
                break

            # yield generator object
            yield p_df

            # breaks if at the end of the table
            if len(p_df.index) < self.__chunk_size:
                break

            # set offset to grab next batch from df
            self.__offset += self.__chunk_size + original

            # the last batch of the table is grabbed to ensure row count integrity
            if self.__offset > int(check_df.iloc[0]):
                self.__offset -= original
                self.__chunk_size = int(check_df.iloc[0]) - self.__offset