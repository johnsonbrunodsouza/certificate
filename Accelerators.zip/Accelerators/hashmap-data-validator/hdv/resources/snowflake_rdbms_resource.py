# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from distutils.sysconfig import customize_compiler
import pandas as pd

from hdv.resources.rdbms_resource import RDBMSResource
from hdv.dao.db_snowflake import Snowflake
from hdv.query_templates.query_templates import QueryTemplate
from jinjasql import JinjaSql


class SnowflakeResource(RDBMSResource):
    """Base class for all Snowflake Object types.
    This object holds the methods needed to connect to Snowflake and configure Snowflake credentials."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__connection_choice = kwargs['env']
        self.__table = kwargs['table_name']
        self.__chunk_size = kwargs['chunk_size']
        self.__offset = kwargs['offset']
        self.__primary_key = kwargs.get('primarykey', '')
        self.__orderby_clause = kwargs.get('sink_orderby', '')        
        self.__hash = kwargs.get('hash','')
        if '.' in self.__table:
            splits = self.__table.split('.')
        self.__table = splits[len(splits)-1]
        self.__base_query = kwargs.get('basequery', '')
        if self.__orderby_clause == None:
            if kwargs.get('orderby','') != None:
                self.__orderby_clause = kwargs.get('orderby','')
            elif self.__primary_key:
                self.__orderby_clause = self.__primary_key
        

    def retrieve_dataframe(self) -> pd.DataFrame:
        """Reads data from a Snowflake table as a pandas dataframe."""
        try:
            query = ""
            if self.__hash:      
                with Snowflake(connection=self.__connection_choice).connection as conn:    
                    cursor = conn.cursor()  
                    hashquery = self._generate_query_for_hash()
                    cursor.execute(f'show columns in table {self.__table}')
                    cursor.execute(hashquery)
                    query = cursor.fetchone()[0]
                    cursor.close()
            else:
                query = f"select * from {self.__table}"

            with Snowflake(connection=self.__connection_choice).connection as conn:
                cursor = conn.cursor()

                if self.__chunk_size and self.__orderby_clause:
                    df = pd.concat((self._generate_df(query, connection=conn)))

                else:
                    # select the sf table
                    #cursor.execute(f"select * from {self.__table};")
                    cursor.execute(query)

                    # fetch sf table as pandas dataframe
                    df = cursor.fetch_pandas_all()

                return df

        except Exception as e:
            raise e

    def _generate_query_for_hash(self, sourcetype):
        query_template = self._fetch_snowflake_hash_query(sourcetype)
        params = {
            'hash_function': self.__hash,            
            'table_name': self.__table
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        return(query % bind_params)

    def _generate_df(self, query, connection):
        """grabs samples from the snowflake table and returns sample as a generator object"""

        # original offset value
        original = self.__offset

        # query the length of the Snowflake table
        check_df = pd.read_sql_query(
            sql=f"select count(*) from {self.__table};",
            con=connection)

        # check that the chunk_size and offset fit within the dataframe
        if int(check_df.iloc[0] / 2) <= self.__chunk_size + self.__offset:
            log_message = f"Please ensure the Snowflake table row count is at least 2x larger than the sum of the" \
                               f" given chunk_size and offset values. Or, enter smaller chunk_size and offset values."
            self._logger.error(log_message)
            return False

        while True:

            # generate a generator object of df batch
            p_df = pd.read_sql_query(
                #sql=f"select * from {self.__table} limit {self.__chunk_size} offset {self.__offset};",
                sql=f"{query} order by {self.__orderby_clause} limit {self.__chunk_size} offset {self.__offset};",
                con=connection)

            # if empty, break
            if not len(p_df.index):
                break

            # yield generator object
            yield p_df

            # breaks if at the end of the table
            if len(p_df.index) < self.__chunk_size:
                break

            # set offset to grab next batch from df
            self.__offset += self.__chunk_size + original

            # the last batch of the table is grabbed to ensure row count integrity
            if self.__offset > int(check_df.iloc[0]):
                self.__offset -= original
                self.__chunk_size = int(check_df.iloc[0]) - self.__offset

    def retrieve_table_count(self):
        try:
            with Snowflake(connection=self.__connection_choice).connection as conn:
                check_df = pd.read_sql_query(sql=f"select count(*) from {self.__table}", con=conn)
        except Exception as e:
            raise e
        return int(check_df.iloc[0, 0])

    def retrieve_base_query(self, sourcetype):
        query = ""
        if self.__hash:
            with Snowflake(connection=self.__connection_choice).connection as conn:    
                cursor = conn.cursor()  
                hashquery = self._generate_query_for_hash(sourcetype)
                cursor.execute(f'show columns in table {self.__table}')
                cursor.execute(hashquery)
                query = cursor.fetchone()[0]
                cursor.close()
        else:
            query = f"select *"
        return query

    def retrieve_data(self) -> pd.DataFrame:  
        query = self.__base_query
        if self.__hash and self.__primary_key:
            query = f"{query}, {self.__primary_key}"
        
        query = f"{query} FROM {self.__table}"

        if self.__chunk_size and self.__offset:
            self.__orderby_clause = ','.join('"{}"'.format(col) for col in self.__orderby_clause.split(','))
            query = f"{query} ORDER BY {self.__orderby_clause} " \
                    f"LIMIT {self.__chunk_size} " \
                    f"OFFSET {self.__offset};"

        #if self.__chunk_size and (self.__orderby_clause or self.__primary_key):
        #    query = f"{self.__base_query}"
        #    if self.__primary_key:
        #        query = f" {query}, {self.__primary_key} FROM {self.__table} ORDER BY {self.__primary_key}"
        #    else:
        #        query = f" {query} FROM {self.__table} ORDER BY {self.__orderby_clause}"

        #    query = f"{query} LIMIT {self.__chunk_size} " \
        #            f"OFFSET {self.__offset}; "
        #else:
        #    query = f"{self.__base_query} FROM {self.__table};"
        
        with Snowflake(connection=self.__connection_choice).connection as conn:
            return pd.read_sql_query(sql=query, con=conn)
    
    def _fetch_snowflake_hash_query(self, sourcetype):
        hashquery = ""
        if sourcetype == "TeradataResource":
            hashquery = QueryTemplate.get_teradata_snowflake_hash_query
        elif sourcetype == "BigQueryResource":
            hashquery = QueryTemplate.get_bigquery_snowflake_hash_query
        else: 
            hashquery = QueryTemplate.get_snowflake_hash_query
        
        return hashquery