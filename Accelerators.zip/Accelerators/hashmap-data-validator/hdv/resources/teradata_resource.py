# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pandas as pd

from hdv.dao.oracle import Oracle
from hdv.dao.teradata import Teradata
from hdv.resources.rdbms_resource import RDBMSResource
from hdv.query_templates.query_templates import QueryTemplate
from jinjasql import JinjaSql


class TeradataResource(RDBMSResource):
    """Base class for all JDBC Object types.
    This object holds the methods needed to connect to JDBC and configure JDBC credentials."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__connection_choice = kwargs['env']
        self.__table = kwargs['table_name']
        self.__chunk_size = kwargs['chunk_size']
        self.__offset = kwargs['offset']
        self.__primary_key = kwargs.get('primarykey', '')
        self.__orderby_clause = kwargs.get('orderby', '') 
        self.__hash = kwargs.get('hash','')
        self.__base_query = kwargs.get('basequery', '')
        if self.__orderby_clause == None and self.__primary_key:
            self.__orderby_clause = self.__primary_key
        self.__database_name = kwargs.get('database','')

    def retrieve_dataframe(self) -> pd.DataFrame:
        """Reads data from a JDBC table as a pandas dataframe."""

        # connect to oracle db and retrieve dataframe
        with Teradata(connection=self.__connection_choice).connection as conn:

            if self.__chunk_size and self.__offset:
                return pd.concat((self._generate_df(connection=conn)))

            # run default query
            else:
                return pd.read_sql_query(sql=f"select * from {self.__table}", con=conn)

    def _generate_df(self, connection=None):
        """grabs samples from the jdbc table and returns sample as a generator object"""

        # original offset value
        original = self.__offset

        # query the row length of the JDBC table
        check_df = pd.read_sql_query(
            sql=f"select count(*) from {self.__table}",
            con=connection)

        # check that the chunk_size and offset fit within the dataframe
        if int(check_df.iloc[0] / 2) <= self.__chunk_size + self.__offset:
            log_message = f"Please ensure the JDBC table row count is at least 2x larger than the sum of the " \
                               f"given chunk_size and offset values. Or, enter smaller chunk_size and offset values."
            self._logger.error(log_message)
            return False

        while True:

            # generate a generator object of df batch
            # order by to ensure integrity of validation
            p_df = pd.read_sql_query(
                sql=f"select * from {self.__table} limit {self.__chunk_size} offset {self.__offset};",
                con=connection)

            # if batch is empty, break
            if not len(p_df.index):
                break

            # yield generator object
            yield p_df

            # breaks if at the end of the table
            if len(p_df.index) < self.__chunk_size:
                break

            # set offset to grab next batch from df
            self.__offset += self.__chunk_size + original

            # the last batch of the table is grabbed to ensure row count integrity
            if self.__offset > int(check_df.iloc[0]):
                self.__offset -= original
                self.__chunk_size = int(check_df.iloc[0]) - self.__offset

    def _generate_query_for_hash(self):
        query_template = QueryTemplate.get_teradata_hash_query
        params = {
            'hash_function': self.__hash,            
            'table_name': self.__table.split('.')[1],
            'database_name': self.__database_name
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        return(query % bind_params)

    def _generate_query_for_pk(self):
        query_template = QueryTemplate.get_teradata_primary_key
        params = {                    
            'table_name': self.__table.split('.')[1],
            'database_name': self.__database_name
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        return(query % bind_params)

    def retrieve_table_count(self):
        with Teradata(connection=self.__connection_choice).connection as conn:
            check_df = pd.read_sql_query(sql=f"select count(*) from {self.__table}", con=conn)

        return int(check_df.iloc[0, 0])
    
    def retrieve_base_query(self):
        query = ""
        if self.__hash:
            with Teradata(connection=self.__connection_choice).connection as conn:      
                hashquery = self._generate_query_for_hash()
                df = pd.read_sql_query(sql=hashquery, con=conn)
                query = df.iloc[0,0]
        else:
            query = f"select *"
        
        return query

    def retrieve_primary_key(self):
        pk = ""
        with Teradata(connection=self.__connection_choice).connection as conn:   
            pkquery = self._generate_query_for_pk()
            df = pd.read_sql_query(sql=pkquery, con=conn)
            pk = df.iloc[0,0]
        return pk
    

    def retrieve_data(self) -> pd.DataFrame:
        query = self.__base_query
        if self.__hash and self.__primary_key:
            query = f"{query}, {self.__primary_key}"

        if self.__chunk_size and self.__offset:
            query = f"{query}, ROW_NUMBER() over (order by {self.__orderby_clause}) as Rownum_ " \
                    f"from {self.__table} " \
                    f"QUALIFY RowNum_ BETWEEN {self.__offset} and {self.__offset + self.__chunk_size};"
            # query = f"{query} ORDER BY {self.__orderby_clause} " \
            #         f"OFFSET {self.__offset} ROWS " \
            #         f"FETCH NEXT {self.__chunk_size} ROWS ONLY;"
        else:
            query = f"{query} FROM {self.__table}"
        
        with Teradata(connection=self.__connection_choice).connection as conn:
            return pd.read_sql_query(sql=query, con=conn)