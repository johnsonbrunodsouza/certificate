# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pandas as pd

from hdv.resources.fs_resource import FsResource
from hdv.dao.hdfs_dao import HDFS


class HDFSResource(FsResource):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__connection_choice = kwargs['env']

    def retrieve_dataframe(self) -> pd.DataFrame:
        """construct a dataframe from the csv list to run validation on"""
        try:
            csv_list = HDFS(connection=self.__connection_choice).get_directory_listing()
            aggregated_df = pd.concat((self._read_csv_files(csv_list)), axis=0, ignore_index=True)
            return aggregated_df

        except Exception as e:
            self._logger.error(e)

    def _read_csv_files(self, csv_list) -> list:
        """read each csv in the csv list as a pandas dataframe"""
        for csv_file in csv_list:
            pd_df = pd.read_csv("hdfs://"+csv_file)
            yield pd_df
