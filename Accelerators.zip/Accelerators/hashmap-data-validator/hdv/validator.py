# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import chunk
import webbrowser
import os
import logging
import logging.config

import great_expectations as ge
import pandas as pd
from json2html import Json2Html

from providah.factories.package_factory import PackageFactory as pf
from hdv.utils.parse_config import ParseConfig
import datetime

from hdv.utils.project_config import ProjectConfig 
import math
import json
from hdv.query_templates.query_templates import QueryTemplate
from jinjasql import JinjaSql
from hdv.dao.db_snowflake import Snowflake
from snowflake.connector.pandas_tools import write_pandas

class Validator:
    """Class that holds the validate method"""

    @classmethod
    def _get_logger(cls):
        return logging.getLogger(cls.__name__)

    def __init__(self, configuration, run_id):        
        #logging.config.dictConfig(log_setting_values)
        #self._logger = self._get_logger()
        # row count validation
        self.row_count_valid = ""
        # row hash validation
        self.row_hash_valid = ""
        # hash df
        self.hash_df = None
        # json string to generate html report
        self.json_str = str

        self._run_id = run_id
        self.__profile = ParseConfig.parse(config_path=f"{ProjectConfig.hdv_home()}/{ProjectConfig.profile_path()}")[configuration['resources'][configuration['validations']['from']]['conf'].get('env','')]
        self._source_hash = configuration['resources'][configuration['validations']['from']]['conf'].get('hash','')
        self._sink_hash = configuration['resources'][configuration['validations']['to']]['conf'].get('hash','')
        self._table_name = configuration['resources'][configuration['validations']['from']]['conf'].get('table_name','')
        self._reporting_env = configuration['resources']['reporting']['env']
        self._failure_threshold = configuration['resources'][configuration['validations']['from']]['conf'].get('failure_threshold', ProjectConfig.failure_threshold())
        if self._failure_threshold == None:
            self._failure_threshold = ProjectConfig.failure_threshold()

        self._current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
        self._log_setting_values = ParseConfig.parse(config_path=os.getenv('LOG_SETTINGS'))
        self._logpath = os.path.join(configuration['logfolder'], ProjectConfig.table_to_folder(self._table_name), self._table_name[len(self._table_name.split('.')[0]) + 1:] + '_' + self._current_timestamp + "_Process.log")

        if not os.path.isdir(os.path.dirname(self._logpath)):
            os.makedirs(os.path.dirname(self._logpath))  

        self._log_setting_values['handlers']['file']['filename'] = self._logpath
        logging.config.dictConfig(self._log_setting_values)
        self._logger = self._get_logger()
        self._logger.disabled = False

        self._htmloutput = configuration.get('htmloutput', False)

        # initiate source and sink objects
        # specific objects initialized depending on config values
        #self.__sink = pf.create(key=configuration['resources'][configuration['validations']['to']]['type'], configuration=configuration['resources'][configuration['validations']['to']]['conf'])
        #self.__source = pf.create(key=configuration['resources'][configuration['validations']['from']]['type'], configuration=configuration['resources'][configuration['validations']['from']]['conf'])

        # retrieve source and sink dataframes to run validations
        #self._logger.info(f"Retrieving hashes from {configuration['validations']['to']} for table {self._table_name}")
        #self.__sink_df = self.__sink.retrieve_dataframe()
        #self._logger.info(f"Retrieving hashes from {configuration['validations']['from']} for table {self._table_name}")
        #self.__source_df = self.__source.retrieve_dataframe()    
        self.__sink_df = pd.DataFrame
        self.__source_df = pd.DataFrame

    def run(self, configuration):
        """validation method: runs expectations on row count and row hash values between source and target tables"""
        try:
            original_offset = 0
            iCounter = 0
            planned_iterations = 1
            iteration_success_flag = 'Success'
            source_base_query = ""
            source_primary_key = ""
            sink_base_query= ""
            # Get count of records from source
            configuration['resources'][configuration['validations']['from']]['conf']['database'] = self.__profile.get('database','')
            self.__source_obj = pf.create(key=configuration['resources'][configuration['validations']['from']]['type'], configuration=configuration['resources'][configuration['validations']['from']]['conf'])
            self._logger.info(f"Retrieving count from {configuration['validations']['from']} for table {self._table_name}")
            record_count = self.__source_obj.retrieve_table_count()

            self.__sink_obj = pf.create(key=configuration['resources'][configuration['validations']['to']]['type'], configuration=configuration['resources'][configuration['validations']['to']]['conf'])
            self._logger.info(f"Retrieving count from {configuration['validations']['to']} for table {self._table_name}")
            sink_record_count = self.__sink_obj.retrieve_table_count()

            self._insert_hdv_summary_record("NULL", "NULL")
            
            if self.count_df_rows(record_count, sink_record_count):
                source_base_query = self.__source_obj.retrieve_base_query()
                source_primary_key = self.__source_obj.retrieve_primary_key()
                sink_base_query = self.__sink_obj.retrieve_base_query(configuration['resources'][configuration['validations']['from']]['type'])

                # Determine chunk size and offset based on sampling percentage
                chunk_size, offset, planned_iterations = self._generate_iteration_parameters(configuration, record_count)
                
                original_offset = offset
                original_chunk_size = chunk_size
                
                # Validate inputs needed for iterations
                if not self._validate_inputs_for_iterations(configuration, source_primary_key, planned_iterations, chunk_size):
                    return

                self._logger.info(f"Total planned iterations for hash validation: {planned_iterations}")
                self._update_summary_record(planned_iterations, 0, 'Success', 'In Progress')

                while True:   
                    configuration['resources'][configuration['validations']['from']]['conf']['chunk_size'] = chunk_size
                    configuration['resources'][configuration['validations']['from']]['conf']['offset'] = offset
                    configuration['resources'][configuration['validations']['to']]['conf']['chunk_size'] = chunk_size
                    configuration['resources'][configuration['validations']['to']]['conf']['offset'] = offset
                    configuration['resources'][configuration['validations']['from']]['conf']['basequery'] = source_base_query
                    configuration['resources'][configuration['validations']['to']]['conf']['basequery'] = sink_base_query
                    configuration['resources'][configuration['validations']['from']]['conf']['primarykey'] = source_primary_key
                    configuration['resources'][configuration['validations']['to']]['conf']['primarykey'] = source_primary_key
                    
                    self.__source = None
                    self.__sink = None

                    self.__source = pf.create(key=configuration['resources'][configuration['validations']['from']]['type'], configuration=configuration['resources'][configuration['validations']['from']]['conf'])
                    self.__sink = pf.create(key=configuration['resources'][configuration['validations']['to']]['type'], configuration=configuration['resources'][configuration['validations']['to']]['conf'])
                    
                    self._logger.info(f"Initiaiting hash comparison for iteration {iCounter + 1}")

                    self._logger.info(f"Retrieving hashes from {configuration['validations']['from']} for table {self._table_name} with chunk_size: {str(chunk_size)} and offset: {str(offset)}")
                    self.__source_df = self.__source.retrieve_data()

                    self._logger.info(f"Retrieving hashes from {configuration['validations']['to']} for table {self._table_name} with chunk_size: {str(chunk_size)} and offset: {str(offset)}")
                    self.__sink_df = self.__sink.retrieve_data()

                    if not configuration['resources'][configuration['validations']['from']]['conf']['hash'] or configuration['resources'][configuration['validations']['from']]['conf']['hash'] == None:
                        self.order_columns()

                    # run row hash comparison expectation on dataframes
                    self.compare_row_hashes()

                    hash_response = json.loads(self.row_hash_valid)

                    if not hash_response['success']:
                        iteration_success_flag = 'Failure'
                        self._logger.info(f"Hash check failed for iteration {iCounter + 1}")
                        #self._update_summary_record(planned_iterations, iCounter + 1, 'Success', 'Failure')
                        if source_primary_key:
                            failed_df = self._setup_failed_records_for_logging(hash_response, source_primary_key, iCounter)                            
                            self._write_failure_dataframe(failed_df)

                            # Exit the iterations if the failure percentage is more than the threshold    
                            if hash_response['result']['unexpected_percent'] > self._failure_threshold:
                                self._logger.info(f"Percentage failure {hash_response['result']['unexpected_percent']} is greater than the threshold of {self._failure_threshold}, so skipping the current table.")
                                self._update_summary_record(planned_iterations, iCounter + 1, 'Success', iteration_success_flag)
                                break
                        else:
                            self._logger.info(f"Not updating HDV_FAILURE_DETAILS table as there are no primary keys.")
                    else:
                        self._logger.info(f"Hash check succeeded for iteration {iCounter + 1}")
                        if iCounter == planned_iterations - 1:
                            self._update_summary_record(planned_iterations, iCounter + 1, 'Success', iteration_success_flag)
                        else:
                            self._update_summary_record(planned_iterations, iCounter + 1, 'Success', 'In Progress')
                        

                    # create a json string from validation results
                    #self.json_str = '{"row_count_expectation": ' + self.row_count_valid + ', "row_hash_expectation": ' + self.row_hash_valid + "}"                

                    # generate html report from json string (.html file gets created from directory where the method is run)
                    #if self._htmloutput:
                    #    self.generate_html_report(iCounter)

                    iCounter += 1

                    if original_chunk_size == None or not len(self.__source_df.index) or len(self.__source_df.index) < original_chunk_size or iCounter == planned_iterations:
                        break
                    
                    # set offset to grab next batch from df
                    offset += chunk_size + original_offset

                    # the last batch of the table is grabbed to ensure row count integrity
                    if offset > int(record_count):
                        offset -= original_offset
                        chunk_size = int(record_count) - offset
            else:
                self._logger.info("Skipping hash check as ROW_COUNT check failed.")
                               
            # open the .html report
            #return webbrowser.open('file://' + os.path.realpath(f"{self._table_name[len(self._table_name.split('.')[0]) + 1:]}_validation_report_{self._current_timestamp}.html"))

        except Exception as e:
            self._logger.error(e)
            return False

    def _validate_inputs_for_iterations(self, configuration, source_primary_key, planned_iterations, chunk_size):
        successflag = True
        if planned_iterations > 1:
            if (not source_primary_key or source_primary_key == None) and (not configuration['resources'][configuration['validations']['from']]['conf'].get('orderby','') or 
                configuration['resources'][configuration['validations']['from']]['conf'].get('orderby','') == None):                
                self._logger.info(f"Number of planned iterations is {planned_iterations}. Either primary key or an order by clause is needed to build iterations. ")
                successflag = False

        if chunk_size == 0:
            self._logger.info(f"Chunk size determined is {chunk_size}. Increase the % of records to be fetched.")
            successflag = False
        
        if not successflag:
            self._update_summary_record(planned_iterations, 0, 'Success', 'Failure')
        return successflag

    def _setup_failed_records_for_logging(self, hash_response, source_primary_key, iCounter):
        failed_df = self.__source_df[self.__source_df.index.isin(hash_response['result']['unexpected_index_list'])]    
        failed_df.columns = failed_df.columns.str.lower()      
        primary_key_list = [x.strip().lower() for x in source_primary_key.split(',')]
        failed_df = failed_df[primary_key_list]
        failed_df_columns = failed_df.columns
        for column in failed_df_columns:                        
            failed_df[column] = column + '=' + failed_df[column].astype(str)

        if failed_df.shape[1] > 0:
            failed = pd.DataFrame(index=range(failed_df.shape[0]))
            failed['RUN_ID'] = self._run_id
            failed['TABLE_NAME'] = self._table_name
            failed['CHECK_TYPE'] = 'HASH_CHECK'
            failed['ITERATION_NUMBER'] = iCounter + 1
            failed['RECORD_IDENTIFIER'] =  pd.Series(failed_df.fillna('').values.tolist()).map(lambda x: ','.join(map(str,x)))                                           
            failed['SOURCE_VALUE'] = ''
            failed['TARGET_VALUE'] = ''
        
        return failed

    def _write_failure_dataframe(self, failed_df):
        with Snowflake(connection=self._reporting_env).connection as conn:    
            success, nchunks, nrows, output = write_pandas(conn=conn, df=failed_df, table_name='HDV_FAILURE_DETAILS')
            self._logger.info(f"Failure details insertion status success_flag: {str(success)}, Chunks inserted: {str(nchunks)}, Rows Inserted: {str(nrows)}, Copy command output: {output}")
            if not success:
                raise output


    def _insert_hdv_summary_record(self, planned_iterations, iterations_completed):
        query_template = QueryTemplate.get_reporting_insert_summary_template
        params = {
            'run_id': self._run_id,            
            'table_name': self._table_name,
            'manifest_name': os.getenv('HDV_MANIFEST'),
            'planned_iterations': planned_iterations,
            'iterations_completed': iterations_completed,
            'row_count_check': 'In Progress',
            'hash_check': 'Not Started',
            'create_date': str(datetime.datetime.now()),
            'update_date': str(datetime.datetime.now())
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        query = query % bind_params

        with Snowflake(connection=self._reporting_env).connection as conn:    
            cursor = conn.cursor()
            cursor.execute(query)
            cursor.close()
    
    def _update_summary_record(self, planned_iterations, iterations_completed, row_count_check, hash_check):
        query_template = QueryTemplate.get_reporting_update_summary_template
        params = {
            'run_id': self._run_id,            
            'table_name': self._table_name,
            'planned_iterations': planned_iterations,
            'iterations_completed': iterations_completed,
            'row_count_check': row_count_check,
            'hash_check': hash_check,            
            'update_date': str(datetime.datetime.now())
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        query = query % bind_params

        with Snowflake(connection=self._reporting_env).connection as conn:    
            cursor = conn.cursor()
            cursor.execute(query)
            cursor.close()
    
    def _insert_failure_details(self, source_value, target_value, check_type):
        query_template = QueryTemplate.get_reporting_insert_failure_detail_template
        params = {
            'run_id': self._run_id,            
            'table_name': self._table_name,
            'check_type': check_type,        
            'source_value': str(source_value),
            'target_value': str(target_value)
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        query = query % bind_params

        with Snowflake(connection=self._reporting_env).connection as conn:    
            cursor = conn.cursor()
            cursor.execute(query)
            cursor.close()

    def _generate_iteration_parameters(self, configuration, record_count):
        samplingpercentage = configuration['resources'][configuration['validations']['from']]['conf'].get('samplingpercentage', 100)
        planned_iterations = 1
        if samplingpercentage == None:
            samplingpercentage = 100
        if samplingpercentage != 100 or record_count > ProjectConfig.force_iterations_max_record_count():
            #samplingpercentage = configuration['resources'][configuration['validations']['from']]['conf'].get('samplingpercentage', 100)
            chunk_size = math.floor((record_count*samplingpercentage)/(ProjectConfig.sampling_factor()*100))
            offset = math.floor((record_count/ProjectConfig.sampling_factor()) - chunk_size)
            planned_iterations = ProjectConfig.sampling_factor() + 1              
        else:
            chunk_size = configuration['resources'][configuration['validations']['from']]['conf']['chunk_size']
            offset = configuration['resources'][configuration['validations']['from']]['conf']['offset']
            if chunk_size != None:
                planned_iterations = math.floor(record_count/(chunk_size + offset))
        
        if offset == 0:
            planned_iterations = 1
        return chunk_size, offset, planned_iterations

    def generate_hash_list(self, df: pd.DataFrame):
        """generates a list of hash tuples over the rows in a dataframe"""
        df = df.applymap(str)
        hash_list = df.apply(lambda x: hash(tuple(x)), axis=1).tolist()
        return hash_list

    def order_columns(self):
        """order columns for hash comparison"""
        # assumes column names in both dataframes the same
        # upper the column name to ensure it matches with Snowflake's naming convention
        self.__sink_df = self.__sink_df.sort_index(axis=1)
        self.__source_df.columns = self.__source_df.columns.str.upper() #MRD - Change for converting columns names to upper case
        self.__source_df = self.__source_df.sort_index(axis=1)
        return

    def count_df_rows(self, source_record_count, target_record_count):
        """expectation to count dataframe rows"""
        successflag = True
        # create a great expectations dataframe from the snowflake dataframe for row count expectation
        #ge_df = ge.from_pandas(self.__sink_df)

        # run row count expectation
        #self.row_count_valid = str(ge_df.expect_table_row_count_to_equal(len(self.__source_df.index)))
        if source_record_count == target_record_count:
            self._logger.info("Record count check successful.")
            self._update_summary_record("NULL", "NULL", 'Success', 'Not Started')
        else:
            successflag = False
            self._logger.info("Record count check failed.")
            self._update_summary_record("NULL", "NULL", 'Failure', 'Not Started')
            self._insert_failure_details(source_record_count, target_record_count, 'ROW_COUNT')
            
        return successflag

    def compare_row_hashes(self):
        """expectation to compare row hash strings"""

        # construct df from source hash list
        if not self._source_hash:
            source_df = pd.DataFrame(pd.Series(self.generate_hash_list(self.__source_df), name='hashes'))            
        else:
            self.__source_df.columns = self.__source_df.columns.str.lower() 
            source_df = pd.DataFrame(self.__source_df['hashes'])
            source_df.columns = source_df.columns.str.lower() 
        # create a placeholder column to validate
        source_df['source_true'] = source_df['hashes'].apply(lambda x: True)

        # construct df from sink hash list
        if not self._sink_hash:
            sink_df = pd.DataFrame(pd.Series(self.generate_hash_list(self.__sink_df), name='hashes'))
        else:
            sink_df = pd.DataFrame(self.__sink_df['HASHES'])
            sink_df.columns = sink_df.columns.str.lower() 
        # create a placeholder column to validate
        sink_df['sink_true'] = sink_df['hashes'].apply(lambda x: True)

        # merge dataframes based on hash values
        # get length of dataframe so merge keeps NaN values for accurate validation
        if len(sink_df.index) > len(source_df.index):
            merged_df = sink_df.merge(source_df, how="left",
                                        left_on=['hashes', 'sink_true'],
                                        right_on=['hashes', 'source_true'])

        else:
            merged_df = source_df.merge(sink_df, how="left",
                                        left_on=['hashes', 'source_true'],
                                        right_on=['hashes', 'sink_true']
                                        )

        # create the hash dataframe to be used in the hash expectation through concatenation and convert pandas dataframe to a great expectations dataframe
        self.hash_df = ge.from_pandas(merged_df)

        # run hash comparison expectation
        self.row_hash_valid = str(self.hash_df.expect_column_pair_values_to_be_equal(column_A='source_true',
                                                                                     column_B='sink_true',
                                                                                     ignore_row_if='both_values_are_missing',
                                                                                     result_format='COMPLETE',
                                                                                     include_config=True))
                                                                                       
        return True

    def generate_html_report(self, counter):
        """converts json string to html and writes to html file"""

        # initiate json2html object
        j2h = Json2Html()

        # convert json to html
        table_str = j2h.convert(json=self.json_str, table_attributes="class=\"table table-bordered table-hover\"")

        # insert table string into html string
        html_str = f'<!doctype html><html lang="en"><head><!-- Required meta tags --><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- Bootstrap CSS -->' \
                    '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><title>Hashmap-Data-Validator</title></head>' \
                    '<header class="navbar navbar-expand-lg navbar-dark bg-dark"><div class="collapse navbar-collapse"><div class="mx-auto my-2 text-white"><h3>Hashmap Data Validator</h3></div></div></header>' \
                    f'<body>{table_str}<!-- Optional JavaScript --><!-- jQuery first, then Popper.js, then Bootstrap JS -->' \
                    f'<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>' \
                    f'<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>' \
                    f'<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>' \
                    f'</body></html>'

        if "<tr><th>success</th><td>True</td></tr>" in html_str:
            html_str = html_str.replace("<tr><th>success</th><td>True</td></tr>", "<tr ><th>success</th><td style='background-color:rgb(112,209,115)'>True</td></tr>")
        if "<tr><th>success</th><td>False</td></tr>" in html_str:
            html_str = html_str.replace("<tr><th>success</th><td>False</td></tr>", "<tr><th>success</th><td style='background-color:rgb(253,135,135)'>False</td></tr>")

        # write html string to file
        #with open(os.path.realpath(f"{self._table_name}_validation_report_{self._current_timestamp}.html"), "w") as html_report:        
        with open(os.path.join(os.path.dirname(self._logpath), f"{self._table_name[len(self._table_name.split('.')[0]) + 1:]}_validation_report_{self._current_timestamp}_Iteration_{str(counter)}.html"), "w") as html_report:
            html_report.write(html_str)
            html_report.close()
        return html_str
