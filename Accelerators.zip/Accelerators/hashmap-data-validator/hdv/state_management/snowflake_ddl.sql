--Copyright © 2020 Hashmap, Inc
--Licensed under the Apache License, Version 2.0 (the "License");
--you may not use this file except in compliance with the License.
--You may obtain a copy of the License a
--http://www.apache.org/licenses/LICENSE-2.
--Unless required by applicable law or agreed to in writing, software
--distributed under the License is distributed on an "AS IS" BASIS,
--WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--See the License for the specific language governing permissions and
--limitations under the License.

CREATE DATABASE IF NOT EXISTS HASHMAP_DATA_VALIDATOR;
USE DATABASE HASHMAP_DATA_VALIDATOR;

CREATE SCHEMA IF NOT EXISTS HDV;
USE SCHEMA HDV;

CREATE TABLE IF NOT EXISTS HDV_SUMMARY
(
    RUN_ID VARCHAR(32),
    TABLE_NAME VARCHAR(100),
    MANIFEST_NAME VARCHAR(200),
    PLANNED_ITERATIONS NUMBER(10),
    ITERATIONS_COMPLETED NUMBER(10),
    ROW_COUNT_CHECK VARCHAR(100),
    HASH_CHECK VARCHAR(100),
    CREATE_DATE TIMESTAMP_NTZ,
    UPDATE_DATE TIMESTAMP_NTZ
);

CREATE TABLE IF NOT EXISTS HDV_FAILURE_DETAILS
(
    RUN_ID VARCHAR(32),
    TABLE_NAME VARCHAR(100),
    CHECK_TYPE VARCHAR(100),
    ITERATION_NUMBER NUMBER(10),
    RECORD_IDENTIFIER VARCHAR,
    SOURCE_VALUE VARCHAR,
    TARGET_VALUE VARCHAR
);

--Grant priviliges if a different id is used to create the tables