# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import click
import sys
sys.path.append(r'C:\NTTDATA\Accelerators\hashmap-data-validator')
from hdv.utils.parse_config import ParseConfig
from hdv.utils.project_config import ProjectConfig
from hdv.validator import Validator
import uuid


@click.command()
def cli_validate():
    """ - makes hdv method callable via cli
        - configured in setup.py to be callable with 'hdv' command """

    # Validator instance
    os.environ['HDV_MANIFEST'] = f"{ProjectConfig.hdv_home()}/{ProjectConfig.configuration_path()}" 
    os.environ['LOG_SETTINGS'] = f"{ProjectConfig.hdv_home()}/{ProjectConfig.log_configuration_path()}" 
    baseconfig = ParseConfig.parse(config_path=os.getenv('HDV_MANIFEST')) 
    run_id = uuid.uuid4().hex
    for table in baseconfig['resources'][baseconfig['validations']['from']]['tables']:
        configuration = generate_configuration(baseconfig, table)
    
    #cli_validation = Validator(configuration=ParseConfig.parse(config_path=os.getenv('HDV_MANIFEST')))
        cli_validation = Validator(configuration, run_id)

    # calls hdv method from cli
        cli_validation.run(configuration)

def generate_configuration(config, table):
    configuration = {}
    for key in config.keys():
        if key != 'resources':
            configuration[key] = config[key]
        else:
            configuration[key] = {}
            configuration[key][config['validations']['from']] = {}
            configuration[key][config['validations']['from']]['type'] = config[key][config['validations']['from']]['type']
            configuration[key][config['validations']['from']]['conf'] = {}
            configuration[key][config['validations']['from']]['conf']['env'] = config[key][config['validations']['from']]['env']
            configuration[key][config['validations']['from']]['conf']['hash'] = config[key][config['validations']['from']]['hash']            

            configuration[key][config['validations']['to']] = {}
            configuration[key][config['validations']['to']]['type'] = config[key][config['validations']['to']]['type']
            configuration[key][config['validations']['to']]['conf'] = {}
            configuration[key][config['validations']['to']]['conf']['env'] = config[key][config['validations']['to']]['env']
            configuration[key][config['validations']['to']]['conf']['hash'] = config[key][config['validations']['to']]['hash']

            for tablekey in table.keys():
                configuration[key][config['validations']['from']]['conf'][tablekey] = table[tablekey]
                configuration[key][config['validations']['to']]['conf'][tablekey] = table[tablekey]
        
            configuration[key]['reporting'] = config[key]['reporting']
    return configuration

cli_validate()
