# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import platform
import os


class ProjectConfig:
    @classmethod
    def hdv_home(cls):
        if not os.getenv('HDV_HOME'):
            if platform.system().lower() != 'windows':
                os.environ['HDV_HOME'] = os.getenv('HOME')
            else:
                os.environ['HDV_HOME'] = os.getenv('USERPROFILE')
        return os.getenv('HDV_HOME')

    @classmethod
    def profile_path(cls):
        return ".hds/profiles.yaml"

    @classmethod
    def configuration_path(cls):
        return ".hds/hdv.yaml"

    @classmethod
    def connection_max_attempts(cls):
        return 3

    @classmethod
    def connection_timeout(cls):
        return 3

    @classmethod
    def log_configuration_path(cls):
        return ".hds/log_settings.yaml"

    @classmethod
    def table_to_folder(cls, name):
        # the below is for Hive as data source. Hive don't have schemas
        if name.find(".") < 0:
            name = "DEFAULT." + name
        return name.replace(".", "__")

    @classmethod
    def sampling_factor(cls):
        return 4

    @classmethod
    def force_iterations_max_record_count(cls):
        return 1000000
    
    @classmethod
    def failure_threshold(cls):
        return 10

