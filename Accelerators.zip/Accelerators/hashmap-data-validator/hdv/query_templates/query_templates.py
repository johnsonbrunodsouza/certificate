# Copyright © 2021 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

class QueryTemplate:
    get_sql_hash_query = """
        select 
            'select convert(varchar(1000),HASHBYTES(
                                ''{{hash_function}}'', 
                                concat(' + STUFF(
                                                    (
                                                        SELECT 
                                                            ', ' + 'isnull(cast(' + COLUMN_NAME + ' as varchar(1000)),'''')'
                                                        FROM INFORMATION_SCHEMA.COLUMNS
                                                        WHERE TABLE_SCHEMA = '{{schema_name}}'
                                                        AND TABLE_NAME = '{{table_name}}'
                                                        AND TABLE_CATALOG = '{{database_name}}'
                                                        FOR XML PATH('')
                                                    ), 1, 1, ''
                                                )  + ')),2) as hashes' 
    """

    get_sql_primary_key = """
        select 
            stuff(
                    (
                        select 
                            ', ' + C.COLUMN_NAME 
                        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS T  
                        JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C  
                            ON C.CONSTRAINT_NAME=T.CONSTRAINT_NAME  
                        WHERE C.TABLE_NAME='{{table_name}}'  
                        AND C.TABLE_SCHEMA = '{{schema_name}}'
                        AND C.CONSTRAINT_CATALOG = '{{database_name}}'
                        and T.CONSTRAINT_TYPE='PRIMARY KEY'  
                        FOR XML PATH('')
                    ), 1, 1, ''
                )  
    """

    get_snowflake_hash_query = """
        select 
            concat('select upper({{hash_function}}(concat(', a.*,'))) as hashes') 
        from (
                select 
                    listagg(concat('coalesce("',$3,'"::varchar(1000)',','''')'), ', ') 
                from table(result_scan(last_query_id()))
            ) a;
    """

    get_teradata_hash_query = """
        select
            'select {{hash_function}}(concat(' ||
            TRIM(TRAILING ',' FROM (XMLAGG(   
                    case
                        when TRIM(ColumnType) = 'DA' then 'COALESCE(CAST(("' || ColumnName || '" (FORMAT ''MM/DD/YYYY''))' || ' as  varchar(10)),'''')'
                        when TRIM(ColumnType) = 'AT' then 'COALESCE(CAST(("' || ColumnName || '" (FORMAT ''HH:MI:SS''))' || ' as  varchar(10)),'''')'                                                               
                        when TRIM(ColumnType) in ('TS','SZ') then 'COALESCE(CAST(("' || ColumnName || '"(FORMAT ''YYYY-MM-DD HH:MI:SS''))' || ' as  varchar(20)),'''')'
                        when TRIM(ColumnType) = 'PS' then 'TRIM(COALESCE(CAST("' || ColumnName || '" as varchar(' || TO_CHAR(((ColumnLength + DecimalFractionalDigits)*2)+8) || ')),''''))'
                        WHEN TRIM(ColumnType) = 'YR' then
                                                        'CASE
                                                            WHEN SUBSTRING(COALESCE(CAST("' || ColumnName || '" as varchar(10)),''''), 3,1) = 0 THEN TRIM(SUBSTRING(COALESCE(CAST("' || ColumnName || '" as varchar(10)),''''), 4,2))
                                                            WHEN SUBSTRING(COALESCE(CAST("' || ColumnName || '" as varchar(10)),''''), 3,1) <> 0 THEN TRIM(SUBSTRING(COALESCE(CAST("' || ColumnName || '" as varchar(10)),''''), 3,3))
                                                        END'                                                                            
                        when TRIM(ColumnType) in ('CV','CF') then  'TRIM(COALESCE(CAST("' || ColumnName || '" as varchar(' || TO_CHAR(ColumnLength) || ')),''''))'                      
                        when TRIM(ColumnType) in ('F','I','D','N','I2') then
                                                                            'CASE
                                                                                WHEN CAST(("' || ColumnName || '") AS DECIMAL(30, 5)) > 0 AND CAST(("' || ColumnName || '") AS DECIMAL(30, 5)) < 1 THEN ''0'' || COALESCE(RTRIM(RTRIM(CAST(ROUND(CAST(("' || ColumnName || '") AS DECIMAL(30,10)),5)AS VARCHAR(40)),''0''),''.''),'''')
                                                                                WHEN CAST(("' || ColumnName || '") AS DECIMAL(30, 5)) = 0 THEN ''0''
                                                                                WHEN CAST(("' || ColumnName || '") AS DECIMAL(30, 5)) = 1 THEN ''1.00000''
                                                                                ELSE COALESCE(RTRIM(RTRIM(CAST(ROUND(CAST(("' || ColumnName || '") AS DECIMAL(30,10)),5)AS VARCHAR(40)),''0'' ),''.''),'''')
                                                                            END'
                        else 'TRIM(COALESCE(CAST("' || ColumnName || '" as varchar(' || TO_CHAR(ColumnLength*4) || ')),''''))'
                    end  || ',' order by ColumnId) (VARCHAR(16000)))) || ')) as hashes'
        from dbc.columnsv  
        where lower(tablename) = lower('{{table_name}}')
        and lower(databasename) = lower('{{database_name}}');
    """

    get_teradata_primary_key = """
        select
            TRIM(TRAILING ',' FROM (XMLAGG(TRIM(Columnname)|| ',' ORDER BY ColumnPosition) (VARCHAR(10000))))
        from dbc.indicesv
        where lower(tablename) = lower('{{table_name}}')
        and lower(databasename) = lower('{{database_name}}')
        and IndexType = 'K';
    """
    
    get_bigquery_hash_query = """
        select 
            'SELECT UPPER(TO_HEX(SHA1(CONCAT(' || STRING_AGG( case 
                                                                when data_type not in ('NUMERIC','BIGNUMERIC','DECIMAL','BIGDECIMAL') then 'COALESCE(CAST(' || column_name || ' AS STRING),\\'\\')'
                                                                when data_type  in ('NUMERIC','BIGNUMERIC','DECIMAL','BIGDECIMAL') then 'case when ' || column_name || ' is null then \\'\\' ' ||
                                                                                                                                              'when ' || column_name || ' = trunc(' || column_name ||') then cast(DIV(cast(' || column_name || ' as BIGNUMERIC),cast(1.0 as BIGNUMERIC)) as STRING)' ||
                                                                                                                                              'else COALESCE(RTRIM(CAST(' || column_name || ' AS STRING),\\'0\\'),\\'\\') end'
                                                end) || ')))) as hashes'
        from {{dataset}}.INFORMATION_SCHEMA.COLUMNS
        where lower(table_name) = lower('{{table_name}}');
    """
    get_bigquery_snowflake_hash_query = """
        select 
            concat('select upper({{hash_function}}(concat(', a.*,'))) as hashes') 
        from (
                select 
                    listagg(
                               case
                                    when parse_json($4):type <> 'FIXED' then concat('coalesce("',$3,'"::varchar(1000)',','''')')
                                    when parse_json($4):type = 'FIXED' then ' case                                                                                 
                                                                                when "' || $3 || '" is null then ''''                                                                                
                                                                                when "' || $3 || '" = TRUNCATE("' || $3 || '") then TRUNCATE("' || $3 || '")::varchar(1000)  
                                                                                else RTRIM("' || $3 || '",''0'')
                                                                              end'
                                end, ', ') 
                from table(result_scan(last_query_id()))
            ) a;
    """

    get_databricks_hash_query = """
        DESCRIBE TABLE {{table_name}}
    """
    
    get_oracle_hash_query = """
        SELECT 
            'SELECT RAWTOHEX(STANDARD_HASH(' || LISTAGG('COALESCE(TO_CHAR(' || COLUMN_NAME || '),'''')', ' || ')  || ',''{{hash_function}}'')) as hashes'
        FROM ALL_TAB_COLUMNS 
        WHERE TABLE_NAME = '{{table_name}}'
        AND OWNER = '{{owner}}' 
    """

    get_oracle_primary_key = """
        SELECT
            LISTAGG(cols.COLUMN_NAME, ', ') WITHIN GROUP (ORDER BY cols.position) AS PrimaryKey
        FROM all_constraints cons
        inner join all_cons_columns cols
            on cons.constraint_name = cols.constraint_name
            AND cons.owner = cols.owner
        WHERE cons.constraint_type = 'P'
        AND cons.OWNER = '{{owner}}'
        AND cols.TABLE_NAME = '{{table_name}}'
    """
    
    get_hive_hash_query ="""
        select 
            concat('select upper({{hash_function}}(CONCAT(',group_concat(concat('COALESCE(CAST(',c.COLUMN_NAME,' as string),'''')') order by c.INTEGER_IDX SEPARATOR ','),'))) as hashes from {{database_name}}.{{table_name}}')
        from hive.TBLS t
        inner join hive.DBS d
            on t.db_id = t.db_id
        inner join  hive.SDS s
            ON t.SD_ID = s.SD_ID 
        inner join hive.COLUMNS_V2 c
            on s.CD_ID = c.CD_ID
        where d.Name = '{{database_name}}'
        and t.tbl_name = '{{table_name}}';

    """

    get_netezza_hash_query = """
        SELECT HASH (CONCAT({{column_list}}), {{hash_function}}) as hashes from {{table_name}}
    """

    get_reporting_insert_summary_template = """
        insert into HDV_SUMMARY
        values (
                    '{{run_id}}',
                    '{{table_name}}',
                    '{{manifest_name}}',
                    {{planned_iterations}},
                    {{iterations_completed}},
                    '{{row_count_check}}',
                    '{{hash_check}}',
                    '{{create_date}}',
                    '{{update_date}}'
        )
    """

    get_reporting_update_summary_template = """
        update HDV_SUMMARY
            set iterations_completed = {{iterations_completed}},
            row_count_check = '{{row_count_check}}',
            planned_iterations = {{planned_iterations}},
            hash_check = '{{hash_check}}',
            update_date = '{{update_date}}'
        where run_id = '{{run_id}}'
        and table_name = '{{table_name}}'
    """

    get_reporting_insert_failure_detail_template= """
        insert into HDV_FAILURE_DETAILS
        (
            RUN_ID,
            TABLE_NAME,
            CHECK_TYPE,            
            SOURCE_VALUE,
            TARGET_VALUE
        )
        values
        (
            '{{run_id}}',
            '{{table_name}}',
            '{{check_type}}',
            '{{source_value}}',
            '{{target_value}}'
        )
    """